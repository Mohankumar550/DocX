import React, { useEffect, useState } from 'react'
import { exportData, importData } from '../utils/backup'
import { X, Download, Upload } from 'lucide-react'
import { loadDocsIndex } from '../utils/docsIndex'

function flatten(tree){
  const rows=[]
  const walk=(nodes, path=[])=>{
    for(const n of nodes){
      const p=[...path,n.title||n.id]
      rows.push({ id:n.id, type:n.type, path:p.join('/') })
      if(n.children) walk(n.children,p)
    }
  }
  walk(tree)
  return rows
}

export default function BackupPanel({ open, onClose }) {
  const [data,setData]=useState(null)
  const [importText,setImportText]=useState('')
  useEffect(()=>{ if(open){ setData(exportData()) } },[open])
  if(!open) return null
  const rows = flatten(data?.index || [])
  const doExportDownload = () => {
    const blob = new Blob([JSON.stringify(data,null,2)],{type:'application/json'})
    const url=URL.createObjectURL(blob)
    const a=document.createElement('a'); a.href=url; a.download='backup.json'; a.click()
  }
  const doImport = () => {
    try{
      const obj = JSON.parse(importText)
      importData(obj)
      setData(exportData())
      setImportText('')
      alert('Import complete.')
    }catch(e){ alert('Import failed: '+e.message) }
  }
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-[600px] h-full bg-white dark:bg-[#0F172A] border-l border-borderLight dark:border-[#1F2937] flex flex-col">
        <div className="px-5 py-4 border-b border-borderLight dark:border-[#1F2937] flex items-center justify-between">
          <h2 className="text-lg font-semibold">Backup / Export</h2>
          <button onClick={onClose} className="p-2 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828]"><X className="w-5 h-5"/></button>
        </div>
        <div className="px-5 py-4 flex-1 overflow-y-auto space-y-6">
          <div>
            <h3 className="text-sm font-semibold mb-2">Hierarchy</h3>
            <table className="w-full text-left text-xs border border-borderLight dark:border-[#1F2937] rounded overflow-hidden">
              <thead className="bg-[#F4F5F7] dark:bg-[#101828]">
                <tr>
                  <th className="py-2 px-2 font-medium w-24">Type</th>
                  <th className="py-2 px-2 font-medium">Path</th>
                </tr>
              </thead>
              <tbody>
                {rows.map(r=> (
                  <tr key={r.id} className="border-t border-borderLight dark:border-[#1F2937]">
                    <td className="py-1.5 px-2 text-[11px] uppercase text-textSecondary dark:text-gray-400">{r.type}</td>
                    <td className="py-1.5 px-2 text-[13px] truncate">{r.path}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-2">Export</h3>
            <pre className="text-[10px] bg-[#F4F5F7] dark:bg-[#101828] p-3 rounded max-h-56 overflow-auto border border-borderLight dark:border-[#1F2937]">{JSON.stringify(data,null,2)}</pre>
            <button onClick={doExportDownload} className="mt-2 px-3 py-1.5 text-sm rounded bg-atlassianBlue text-white flex items-center gap-2"><Download className="w-4 h-4"/>Download JSON</button>
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-2">Import</h3>
            <textarea value={importText} onChange={(e)=>setImportText(e.target.value)} placeholder="Paste backup JSON here" className="w-full h-32 text-xs bg-[#F4F5F7] dark:bg-[#101828] p-2 rounded border border-borderLight dark:border-[#1F2937]" />
            <div className="mt-2 flex gap-2">
              <button onClick={doImport} className="px-3 py-1.5 text-sm rounded bg-green-600 text-white flex items-center gap-2"><Upload className="w-4 h-4"/>Import</button>
              <button onClick={()=>setImportText('')} className="px-3 py-1.5 text-sm rounded border border-borderLight dark:border-[#1F2937]">Clear</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
