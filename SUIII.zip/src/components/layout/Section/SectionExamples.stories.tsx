import type { Meta, StoryObj } from '@storybook/react';
import { DXSection } from './Section';
import { DXContainer } from '../Container/Container';
import { DXSurface } from '../Surface/Surface';

const meta: Meta = {
  title: 'Layout/Section/Examples',
  parameters: { docs: { description: { component: 'DXSection standardizes vertical spacing between major page segments.' } } }
};
export default meta;

type Story = StoryObj;

export const Spacing: Story = {
  render: () => (
    <div>
      <DXSection style={{ background: 'var(--colors-neutral-50)' }}>
        <DXContainer>
          <DXSurface elevation="sm" style={{ marginBottom: 'var(--spacing-4)' }}>
            <strong>Section A</strong>
            <p style={{ fontSize: '0.75rem' }}>Uses token --layout-section-padding-y for vertical rhythm.</p>
          </DXSurface>
        </DXContainer>
      </DXSection>
      <DXSection style={{ background: 'var(--colors-neutral-100)' }}>
        <DXContainer>
          <DXSurface elevation="sm">
            <strong>Section B</strong>
            <p style={{ fontSize: '0.75rem' }}>Different background demonstrates segmentation.</p>
          </DXSurface>
        </DXContainer>
      </DXSection>
    </div>
  )
};
