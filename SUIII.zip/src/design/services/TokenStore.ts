import { checksum } from '../algorithms/checksum';

type Listener = (tokens: Record<string, unknown>) => void;

export class TokenStore {
  private tokens: Record<string, unknown> = {};
  private hash: string = '';
  private listeners: Set<Listener> = new Set();

  set(tokens: Record<string, unknown>): void {
    const nextHash = checksum(tokens);
    if (nextHash === this.hash) return; // no change
    this.tokens = tokens;
    this.hash = nextHash;
    for (const l of this.listeners) l(this.tokens);
  }

  get(): Record<string, unknown> { return this.tokens; }
  getHash(): string { return this.hash; }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
}
