import { exportData } from './backup'
import { saveJsonToGitHub } from './github'

const SYNC_META_KEY = 'syncMeta'

function getMeta(){
  return JSON.parse(localStorage.getItem(SYNC_META_KEY) || '{"lastSync":null,"dirty":false}')
}
function setMeta(p){
  localStorage.setItem(SYNC_META_KEY, JSON.stringify(p))
}

export async function performSync(){
  const payload = exportData()
  const meta = getMeta()
  try {
    await saveJsonToGitHub('full-backup.json', payload)
    const next = { lastSync: new Date().toISOString(), dirty: false }
    setMeta(next)
    return { ok: true, meta: next }
  } catch (e) {
    return { ok: false, error: e.message, meta }
  }
}

// Push tree.json, users.json, then each doc as docs/<id>.json
export async function performFileSync(){
  const all = exportData()
  const errors = []
  // tree
  try { await saveJsonToGitHub('tree.json', all.index) } catch(e){ errors.push({ path:'tree.json', error:e.message }) }
  // users
  try { await saveJsonToGitHub('users.json', all.users) } catch(e){ errors.push({ path:'users.json', error:e.message }) }
  // docs individually
  for (const d of all.docs) {
    try {
      await saveJsonToGitHub(`docs/${d.id}.json`, { id: d.id, title: d.title, content: d.data?.content || '', updatedAt: d.data?.updatedAt || null, lastEditedBy: d.data?.lastEditedBy || null })
    } catch(e){ errors.push({ path:`docs/${d.id}.json`, error:e.message }) }
  }
  const meta = getMeta()
  const next = { lastSync: new Date().toISOString(), dirty: errors.length>0 }
  setMeta(next)
  return { ok: errors.length===0, errors, meta: next }
}

// Mark data dirty whenever local changes occur
export function markDirty(){
  const meta = getMeta()
  if (!meta.dirty) setMeta({ ...meta, dirty: true })
}

export function getSyncMeta(){ return getMeta() }
