import { createContext } from 'react';
import type { ThemeName } from './themeManager';

export interface ThemeContextValue {
  theme: ThemeName;
  setThemeName: (name: ThemeName) => void;
  themes: ThemeName[];
}

export const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);
