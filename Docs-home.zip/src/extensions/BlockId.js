import { Extension } from '@tiptap/core'
import { nanoid } from 'nanoid'

export const BlockId = Extension.create({
  name: 'blockId',
  addGlobalAttributes() {
    return [{
      types: ['paragraph','heading','blockquote','codeBlock'],
      attributes: {
        'data-block-id': {
          default: null,
          rendered: true,
          parseHTML: el => el.getAttribute('data-block-id'),
          renderHTML: attrs => ({ 'data-block-id': attrs['data-block-id'] || nanoid(8) })
        }
      }
    }]
  }
})
