import type { Meta, StoryObj } from '@storybook/react';
import { DXSlider, DXRangeSlider } from '../Slider';

const meta: Meta<typeof DXSlider> = {
  title: 'Components/Slider',
  component: DXSlider,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component: 'DXSlider (single) & DXRangeSlider (dual handle) provide accessible value selection with custom track & handles.'
      }
    }
  },
  argTypes: {
    onChange: { action: 'change', description: 'Fires when slider value changes' },
    min: { control: { type: 'number' } },
    max: { control: { type: 'number' } },
    step: { control: { type: 'number' } },
    disabled: { control: { type: 'boolean' } },
    defaultValue: { control: { type: 'number' } },
    showRangeLabels: { control: { type: 'boolean' } }
  },
  args: {
    min: 0,
    max: 100,
    step: 1,
    defaultValue: 50,
    disabled: false,
    showRangeLabels: true,
    valueFormatter: (v: number) => String(v)
  }
};
export default meta;

type Story = StoryObj<typeof DXSlider>;

export const Playground: Story = {
  name: 'Playground',
  render: (args) => <DXSlider {...args} />
};

export const Default: Story = {
  args: {
    max: 1000,
    defaultValue: 5
  },

  render: () => (
    <div className='dx-slider-card'>
      <h4 style={{ margin: '0 0 .75rem', fontSize: '0.8rem', fontWeight: 600 }}>Default Slider</h4>
  <DXSlider defaultValue={60} valueFormatter={v => String(v)} onChange={() => {}} />
    </div>
  )
};

export const FocusState: Story = {
  render: () => (
    <div className='dx-slider-card'>
      <h4 style={{ margin: '0 0 .75rem', fontSize: '0.8rem', fontWeight: 600 }}>Focus Slider</h4>
  <DXSlider defaultValue={60} valueFormatter={v => String(v)} onChange={() => {}} />
      <p style={{ fontSize: 12, marginTop: '0.5rem', color: 'var(--colors-text-secondary,#667085)' }}>Tab to the handle to view focus ring.</p>
    </div>
  )
};

export const Disabled: Story = {
  render: () => (
    <div className='dx-slider-card'>
      <h4 style={{ margin: '0 0 .75rem', fontSize: '0.8rem', fontWeight: 600 }}>Disabled Slider</h4>
  <DXSlider defaultValue={60} disabled valueFormatter={v => String(v)} onChange={() => {}} />
    </div>
  )
};

export const Range: Story = {
  render: () => (
    <div className='dx-slider-card'>
      <h4 style={{ margin: '0 0 .75rem', fontSize: '0.8rem', fontWeight: 600 }}>Range Slider</h4>
  <DXRangeSlider defaultValues={[2500, 7500]} min={0} max={10000} step={500} valueFormatter={v => '$' + v.toLocaleString()} onChange={() => {}} />
    </div>
  )
};

export const RangeDisabled: Story = {
  render: () => (
    <div className='dx-slider-card'>
      <h4 style={{ margin: '0 0 .75rem', fontSize: '0.8rem', fontWeight: 600 }}>Range Slider Disabled</h4>
  <DXRangeSlider defaultValues={[2500, 7500]} min={0} max={10000} step={500} disabled valueFormatter={v => '$' + v.toLocaleString()} onChange={() => {}} />
    </div>
  )
};

// Range Playground with controls
export const RangePlayground: StoryObj = {
  name: 'Range Playground',
  args: {
    min: 0,
    max: 10000,
    step: 500,
    defaultValues: [2000, 8000],
    disabled: false,
    showRangeLabels: true,
    valueFormatter: (v: number) => '$' + v.toLocaleString()
  },
  render: (args: any) => <DXRangeSlider {...args} onChange={() => {}} />
};
