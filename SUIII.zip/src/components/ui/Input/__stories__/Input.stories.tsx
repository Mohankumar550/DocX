import type { Meta, StoryObj } from '@storybook/react';
import { DXInput } from '../Input';

const meta: Meta<typeof DXInput> = {
  title: 'Components/Input',
  component: DXInput,
  tags: ['autodocs'],
  argTypes: {
    status: { control: { type: 'select', options: ['default','success','warning','error'] } },
    size: { control: { type: 'select', options: ['default','sm'] } },
    required: { control: 'boolean' },
    disabled: { control: 'boolean' },
    placeholder: { control: 'text' },
    label: { control: 'text' },
    description: { control: 'text' },
    onChange: { action: 'change' }
  },
  args: {
    label: 'Application Name',
    placeholder: 'Enter application name',
    description: 'This field helps identify the application.',
    required: false,
    disabled: false,
    status: 'default',
    size: 'default'
  }
};
export default meta;

type Story = StoryObj<typeof DXInput>;

export const Playground: Story = { };

// Matrix of states (default size)
export const StatesDefault: Story = {
  render: () => (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(260px,1fr))', gap:'1rem' }}>
      <DXInput label='Application Name' placeholder='Placeholder' />
      <DXInput label='Application Name' required placeholder='Required (empty)' />
      <DXInput label='Application Name' required defaultValue='Filled value' placeholder='Placeholder' />
      <DXInput label='Application Name' status='success' defaultValue='Valid value' />
      <DXInput label='Application Name' status='warning' defaultValue='Needs review' />
      <DXInput label='Application Name' status='error' defaultValue='Bad value' />
      <DXInput label='Application Name' disabled placeholder='Disabled placeholder' />
      <DXInput label='Application Name' disabled defaultValue='Disabled filled' />
    </div>
  )
};

// Small size matrix
export const StatesSmall: Story = {
  render: () => (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(220px,1fr))', gap:'1rem' }}>
      <DXInput size='sm' label='App' placeholder='Placeholder' />
      <DXInput size='sm' label='App' required placeholder='Required (empty)' />
      <DXInput size='sm' label='App' required defaultValue='Filled value' placeholder='Placeholder' />
      <DXInput size='sm' label='App' status='success' defaultValue='Valid' />
      <DXInput size='sm' label='App' status='warning' defaultValue='Check' />
      <DXInput size='sm' label='App' status='error' defaultValue='Error' />
      <DXInput size='sm' label='App' disabled placeholder='Disabled' />
      <DXInput size='sm' label='App' disabled defaultValue='Disabled value' />
    </div>
  )
};

// Focus example
export const FocusExample: Story = {
  render: () => (
    <div style={{ maxWidth:300 }}>
      <DXInput label='Focus Me' defaultValue='Tab into me' description='Use Tab key to view focus ring.' />
    </div>
  )
};

// Visual matrix with simulated pseudo states (hover/focus) for quick comparison
export const StatesVisualMatrix: Story = {
  render: () => (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))', gap:'1rem' }}>
      <DXInput label='Normal' placeholder='Placeholder' />
      <DXInput className='dx-input--simulate-hover' label='Hover (simulated)' placeholder='Placeholder' />
      <DXInput className='dx-input--simulate-focus' label='Focus (simulated)' defaultValue='Focused value' />
      <DXInput className='dx-input--simulate-focus-filled' label='Focus + Filled' defaultValue='Filled value' />
      <DXInput disabled label='Disabled' placeholder='Disabled' />
    </div>
  )
};
