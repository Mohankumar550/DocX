import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { DXSlider, DXRangeSlider } from '../Slider';

describe('DXSlider', () => {
  it('renders with default value', () => {
    render(<DXSlider defaultValue={25} />);
    expect(screen.getByText('25')).toBeInTheDocument();
  });
  it('changes value with keyboard', () => {
    render(<DXSlider defaultValue={25} />);
    const handle = screen.getByRole('slider');
    fireEvent.keyDown(handle, { key: 'ArrowRight' });
    expect(screen.getByText('26')).toBeInTheDocument();
  });
});

describe('DXRangeSlider', () => {
  it('renders with default values', () => {
    render(<DXRangeSlider defaultValues={[2000, 8000]} />);
    expect(screen.getByText('$2,000')).toBeInTheDocument();
    expect(screen.getByText('$8,000')).toBeInTheDocument();
  });
});
