const key = (id) => `comments:${id}`
export const getComments = (docId) => JSON.parse(localStorage.getItem(key(docId)) || '{}')
export function addComment(docId, blockId, comment){
  const map = getComments(docId)
  map[blockId] = map[blockId] || []
  map[blockId].push({ id: Date.now().toString(), ts: Date.now(), ...comment })
  localStorage.setItem(key(docId), JSON.stringify(map))
}
