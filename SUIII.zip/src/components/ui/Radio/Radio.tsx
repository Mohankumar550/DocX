import React from 'react';

export type DXRadioTone = 'default' | 'error';
export type DXRadioSize = 'sm' | 'md';

export interface DXRadioProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'onChange'> {
  /** Name shared by a radio group */
  name: string;
  /** Value emitted on change */
  value: string;
  /** Visual label content */
  label: React.ReactNode;
  /** Optional secondary description text */
  description?: React.ReactNode;
  /** Controlled checked state */
  checked?: boolean;
  /** Uncontrolled initial checked state */
  defaultChecked?: boolean;
  /** Disabled state */
  disabled?: boolean;
  /** Size scale */
  size?: DXRadioSize;
  /** Semantic tone (e.g. error) */
  tone?: DXRadioTone;
  /** Change handler emitting value */
  onChange?: (value: string, e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Optional id (auto-generated if omitted) */
  id?: string;
  /** Custom class name merge */
  className?: string;
}

/** DXRadio – Accessible design-system radio button with custom visuals */
export const DXRadio: React.FC<DXRadioProps> = ({
  name,
  value,
  label,
  description,
  checked,
  defaultChecked,
  disabled,
  size = 'sm',
  tone = 'default',
  onChange,
  id,
  className,
  ...rest
}) => {
  const autoId = React.useId();
  const inputId = id || `dx-radio-${autoId}`;
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (onChange) onChange(e.target.value, e);
  };
  let classes = `dx-radio dx-radio--${size}`;
  if (tone === 'error') classes += ' dx-radio--error';
  if (disabled) classes += ' dx-radio--disabled';
  if (className) classes += ` ${className}`;

  return (
    <label className={classes} data-tone={tone} data-size={size}>
      <input
        id={inputId}
        className="dx-radio__input"
        type="radio"
        name={name}
        value={value}
        disabled={disabled}
        checked={checked}
        defaultChecked={defaultChecked}
        onChange={handleChange}
        aria-describedby={description ? `${inputId}-desc` : undefined}
        {...rest}
      />
      <span className="dx-radio__control" aria-hidden="true">
        <span className="dx-radio__dot" />
      </span>
      <span className="dx-radio__text">
        <span className="dx-radio__label">{label}</span>
        {description && (
          <span id={`${inputId}-desc`} className="dx-radio__description">{description}</span>
        )}
      </span>
    </label>
  );
};

DXRadio.displayName = 'DXRadio';

export interface DXRadioOption { value: string; label: React.ReactNode; description?: React.ReactNode; disabled?: boolean; }
export interface DXRadioGroupProps {
  name: string;
  value?: string; // controlled
  defaultValue?: string; // uncontrolled
  options: DXRadioOption[];
  onChange?: (value: string) => void;
  tone?: DXRadioTone;
  size?: DXRadioSize;
  disabled?: boolean;
  orientation?: 'vertical' | 'horizontal';
  className?: string;
  label?: React.ReactNode; // optional group label
  description?: React.ReactNode; // optional group description
}

/** DXRadioGroup – convenience wrapper mapping options to DXRadio instances */
export const DXRadioGroup: React.FC<DXRadioGroupProps> = ({
  name,
  value,
  defaultValue,
  options,
  onChange,
  tone = 'default',
  size = 'sm',
  disabled,
  orientation = 'vertical',
  className,
  label,
  description
}) => {
  const [internalValue, setInternalValue] = React.useState<string | undefined>(defaultValue);
  const isControlled = value !== undefined;
  const current = isControlled ? value : internalValue;
  const groupClasses = `dx-radio-group ${orientation === 'horizontal' ? 'dx-radio-group--horizontal' : ''}` + (className ? ` ${className}` : '');
  return (
    <fieldset className={groupClasses} disabled={disabled} style={{ border: 0, padding: 0, margin: 0 }}>
      {label && <legend style={{ fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.25rem' }}>{label}</legend>}
      {description && <div style={{ fontSize: '0.7rem', marginBottom: '0.5rem', color: 'var(--colors-text-secondary,#667085)' }}>{description}</div>}
      {options.map(opt => (
        <DXRadio
          key={opt.value}
          name={name}
          value={opt.value}
          label={opt.label}
            description={opt.description}
          size={size}
          tone={tone}
          disabled={disabled || opt.disabled}
          checked={current === opt.value}
          onChange={(val) => {
            if (!isControlled) setInternalValue(val);
            if (onChange) onChange(val);
          }}
        />
      ))}
    </fieldset>
  );
};

DXRadioGroup.displayName = 'DXRadioGroup';

export default DXRadio;
