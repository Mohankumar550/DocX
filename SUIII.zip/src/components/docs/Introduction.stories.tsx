import type { Meta, StoryObj } from '@storybook/react';

// Dux v1.00 – Design System Introduction
// This is a docs-only Storybook entry providing an overview of themes, tokens, and core components.

const meta: Meta = {
  title: 'Introduction',
  parameters: {
    docs: {
      description: {
        component: `# Dux v1.00 Design System\n\nWelcome to the Dux design system Storybook. This introduction page covers **themes**, **tokens**, and **core UI components**.\n\n## 🔑 Core Concepts\n\n- **Atomic Tokens**: JSON token sets under \`assets/styles/tokens/shared/*\` define color, typography, spacing, radius, shadow, motion, layout, and semantic palettes.\n- **Themes**: Composed from shared tokens + theme overrides under \`assets/styles/tokens/themes/{corporate, saasy}/*\`. Each theme id follows \`<family>-<mode>\` (e.g. \`corporate-light\`, \`saasy-dark\`).\n- **Reference Resolution**: Token values can reference other tokens using \`{path.to.token}\` syntax; resolved by the ThemeResolver after merging inheritance chains.\n- **CSS Variable Generation**: Tokens become CSS custom properties injected once per active theme, enabling runtime switching without recompilation.\n\n## 🎨 Themes\n\nFour shipped themes in v1.00:\n\n| Theme Id | Family | Mode | Notes |\n|----------|--------|------|-------|\n| corporate-light | corporate | light | Neutral, enterprise palette |\n| corporate-dark  | corporate | dark  | Inherits light, adjusts primary & neutral contrast |\n| saasy-light     | saasy     | light | Vibrant accent + refined light surfaces |\n| saasy-dark      | saasy     | dark  | Inherits saasy-light, deep backgrounds |\n\n### Theme Switching\nA dual toolbar is configured in Storybook (Top bar): **Theme Family** + **Mode**. The active theme id is composed and applied dynamically. Invalid combinations fall back intelligently (same family or same mode).\n\nProgrammatic switching in the app uses the \`useTheme()\` hook: \n\n\`const { setTheme } = useTheme(); setTheme('saasy-light');\`\n\n## 🧱 Tokens Overview\n\nShared token categories (location: \`assets/styles/tokens/shared\`):\n- **colors.json** – Primary & neutral scales + derived text colors\n- **typography.json** – Font families, size scale, weights, line heights\n- **spacing.json** – Consistent spacing scale (0–10)\n- **radius.json** – Corner radii including pill\n- **shadow.json** – Elevation & focus ring shadows\n- **motion.json** – Duration & easing curves\n- **layout.json** – Structural constraints (container, grid, surface mapping)\n- **semantic.json** – Status palettes (success, warning, error) used by tones\n\n## 🔧 Theme Architecture\n1. **ThemeLoader** dynamically imports theme JSON by id.\n2. **ThemeResolver** topologically merges inheritance chain and resolves token references.\n3. **TokenMerger** combines shared base tokens with theme overrides.\n4. **CSS Variable Generator** produces a flat map + text block inserted into a single \`<style id="theme-vars">\`.\n\n## 🧪 Component: DXButton\n\nVariants: contained|solid, outlined|outline, soft, tertiary, ghost.\nTones: default, error, success, warning.\nSizes: sm, md, lg.\nFeatures: loading state spinner, optional icons (left/right), full width, polymorphic (anchor or custom element with keyboard activation).\nClassnames generated via a builder ensuring consistent BEM-like prefix: \`.dx-button--<variant>\`, tone as modifier \`.dx-button--error\`.\n\n## 🌗 Styling System\nA single SCSS entry \`assets/styles/design-system.scss\` @use's partials: base root resets, app demo styles, component-level styles. Tokens remain pure JSON (not hard-coded in SCSS) – CSS vars allow live theme swaps.\n\n## 🚀 Getting Started\nImport once at application root: \n\n\`import './assets/styles/design-system.scss';\`\n\nWrap UI in ThemeProvider: \n\n\`<ThemeProvider><App /></ThemeProvider>\`\n\nSet a theme: \n\n\`setTheme('corporate-dark');\`\n\n## 🔄 Future Roadmap\n- Add accessibility color contrast tests.\n- Generate TypeScript types from token JSON automatically.\n- Provide a Theme Playground panel for real-time token editing.\n\n## 📘 Conventions\n- Keep component styles localized (e.g. \`_button.scss\`).\n- Avoid global element overrides in component partials.\n- Reference tokens via CSS variables rather than hard-coded hex values.\n\n## 🙌 Contribution\nAdd new tokens or themes under \`assets/styles/tokens\`; register theme ids in \`ThemeRegistry.ts\`. Follow naming pattern \`family-mode\`. Document changes in this introduction for visibility.\n\nEnjoy building with **Dux v1.00**!`
      }
    }
  }
};

export default meta;

type Story = StoryObj;

export const Overview: Story = {
  name: 'Introduction',
  render: () => (
    <div style={{ fontFamily: 'Inter, system-ui, sans-serif', lineHeight: 1.5, padding: '1rem', maxWidth: 860 }}>
      <h1>Dux v1.00 Design System</h1>
      <p>This page summarizes themes, tokens, and core components shipped with the initial release.</p>
      <h2>Quick Links</h2>
      <ul>
        <li><strong>DXButton</strong>: Variant, size and tone examples in its story.</li>
        <li><strong>ThemeSegmentedButton</strong>: Dual family/mode segmented control (optional usage).</li>
        <li><strong>Theme Toolbar</strong>: Use the top toolbar to switch family & mode.</li>
      </ul>
      <h2>Active Theme</h2>
      <p>The toolbar selects <code>themeFamily</code> and <code>themeMode</code> globals which compose an id like <code>corporate-light</code>.</p>
      <h2>Design Tokens</h2>
      <p>Tokens live in JSON, resolved into CSS variables; reference syntax like <code>{'{colors.primary.500}'}</code> is replaced at build runtime.</p>
      <h2>Next Steps</h2>
      <p>Extend the system by adding themes or generating docs for additional components.</p>
    </div>
  )
};
