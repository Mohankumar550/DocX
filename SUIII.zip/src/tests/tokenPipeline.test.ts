import { describe, it, expect } from 'vitest';
import { ThemeResolver } from '../design/services/ThemeResolver';
import { deepMerge } from '../design/algorithms/deepMerge';
import colors from '../design/tokens/shared/colors.json';
import typography from '../design/tokens/shared/typography.json';
import corporateLight from '../design/tokens/themes/corporate/light.json';

describe('token pipeline', () => {
  it('resolves references', () => {
    const base = deepMerge(colors as any, typography as any);
    const resolver = new ThemeResolver();
    const resolved = resolver.resolve([{ id: 'corporate-light', data: corporateLight as any, inherit: [] }], base as any);
    expect(resolved.colors.primary['500']).toBe('#3366FF');
    expect(resolved.button.variants.solid.bg.default).toBe('#3366FF');
  });
});
