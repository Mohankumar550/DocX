import type { Meta, StoryObj } from '@storybook/react';
import { DXContainer } from './Container';
import { DXSurface } from '../Surface/Surface';

interface Args { fluid: boolean; }

const meta: Meta<Args> = {
  title: 'Layout/Container/Examples',
  args: { fluid: false },
  argTypes: { fluid: { control: 'boolean' } },
  parameters: { docs: { description: { component: 'DXContainer centers content and constrains width. Toggle fluid for full-width.' } } }
};
export default meta;

type Story = StoryObj<Args>;

export const Default: Story = {
  render: (args) => (
    <DXContainer fluid={args.fluid}>
      <DXSurface elevation="sm">
        <h3 style={{ marginTop: 0 }}>Container {args.fluid ? 'Fluid' : 'Constrained'}</h3>
        <p style={{ fontSize: '0.85rem' }}>Resize viewport to observe max-width behavior.</p>
      </DXSurface>
    </DXContainer>
  )
};
