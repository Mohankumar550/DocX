import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { DXCheckbox, DXCheckboxGroup } from '../Checkbox';

describe('DXCheckbox', () => {
  it('renders and toggles (uncontrolled)', () => {
    render(<DXCheckbox label='Demo' />);
    const input = screen.getByLabelText('Demo') as HTMLInputElement;
    expect(input.checked).toBe(false);
    fireEvent.click(input);
    expect(input.checked).toBe(true);
  });

  it('indeterminate visual state', () => {
    render(<DXCheckbox label='Partial' indeterminate />);
    const input = screen.getByLabelText('Partial') as HTMLInputElement;
    // indeterminate does not set checked
    expect(input.checked).toBe(false);
  });
});

describe('DXCheckboxGroup', () => {
  it('selects defaults', () => {
    render(<DXCheckboxGroup name='g' defaultValues={['a']} options={[{ value: 'a', label: 'A' }, { value: 'b', label: 'B' }]} />);
    const a = screen.getByLabelText('A') as HTMLInputElement;
    expect(a.checked).toBe(true);
  });

  it('toggles values', () => {
    render(<DXCheckboxGroup name='g' defaultValues={[]} options={[{ value: 'a', label: 'A' }]} />);
    const a = screen.getByLabelText('A') as HTMLInputElement;
    fireEvent.click(a);
    expect(a.checked).toBe(true);
    fireEvent.click(a);
    expect(a.checked).toBe(false);
  });
});
