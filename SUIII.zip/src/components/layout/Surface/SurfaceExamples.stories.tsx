import type { Meta, StoryObj } from '@storybook/react';
import { DXSurface } from './Surface';

interface Args { elevation: 'sm' | 'md' | 'lg'; }

const meta: Meta<Args> = {
  title: 'Layout/Surface/Examples',
  args: { elevation: 'sm' },
  argTypes: { elevation: { control: 'radio', options: ['sm','md','lg'] } },
  parameters: { docs: { description: { component: 'DXSurface provides background, border, and shadow. Elevation communicates hierarchy.' } } }
};
export default meta;

type Story = StoryObj<Args>;

export const Playground: Story = {
  render: (args) => (
    <DXSurface elevation={args.elevation} style={{ maxWidth: 360 }}>
      <h4 style={{ marginTop: 0 }}>Elevation: {args.elevation}</h4>
      <p style={{ fontSize: '0.85rem' }}>Use md/lg sparingly for emphasis (dialogs, hero, focus panels).</p>
    </DXSurface>
  )
};

export const Comparison: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: 'var(--spacing-4)', flexWrap: 'wrap' }}>
      {(['sm','md','lg'] as const).map(e => (
        <DXSurface key={e} elevation={e} style={{ width: 200 }}>
          <strong>{e}</strong>
          <p style={{ fontSize: '0.7rem' }}>Shadow token: --shadow-{e}</p>
        </DXSurface>
      ))}
    </div>
  ),
  parameters: { docs: { description: { story: 'Side-by-side comparison of shadow tokens.' } } }
};
