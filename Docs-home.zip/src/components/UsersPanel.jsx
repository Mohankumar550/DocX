import React, { useEffect, useState } from 'react'
import { loadUsers, saveUsers, setCurrentUser, getCurrentUser } from '../utils/users'
import { X, Plus } from 'lucide-react'

export default function UsersPanel({ open, onClose }) {
  const [users, setUsers] = useState(loadUsers())
  const [current, setCurrent] = useState(getCurrentUser())
  const [newUser, setNewUser] = useState({ username:'', password:'', name:'', email:'' })

  useEffect(()=>{
    const onUpdate = () => { setUsers(loadUsers()); setCurrent(getCurrentUser()) }
    window.addEventListener('users-updated', onUpdate)
    window.addEventListener('current-user-updated', onUpdate)
    return ()=>{
      window.removeEventListener('users-updated', onUpdate)
      window.removeEventListener('current-user-updated', onUpdate)
    }
  },[])

  if (!open) return null

  const updateField = (username, field, value) => {
    const next = users.map(u=> u.username===username ? { ...u, [field]: value } : u)
    setUsers(next)
  }
  const persistAll = () => { saveUsers(users) }
  const switchUser = (u) => { setCurrentUser(u); setCurrent(u) }
  const addUser = () => {
    if(!newUser.username.trim()) return
    const exists = users.some(u=>u.username===newUser.username.trim())
    if (exists) return
    const next = [...users, { ...newUser }]
    setUsers(next)
    saveUsers(next)
    setNewUser({ username:'', password:'', name:'', email:'' })
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-[500px] h-full bg-white dark:bg-[#0F172A] border-l border-borderLight dark:border-[#1F2937] flex flex-col">
        <div className="px-5 py-4 border-b border-borderLight dark:border-[#1F2937] flex items-center justify-between">
          <h2 className="text-lg font-semibold">Users</h2>
          <button onClick={onClose} className="p-2 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828]"><X className="w-5 h-5"/></button>
        </div>
        <div className="px-5 py-4 flex-1 overflow-y-auto space-y-6">
          <div>
            <h3 className="text-sm font-semibold mb-2">Current User</h3>
            {current ? (
              <div className="text-xs text-textSecondary dark:text-gray-400">{current.name} ({current.username}) • {current.email}</div>
            ) : <div className="text-xs text-textSecondary dark:text-gray-400">None selected</div>}
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-2">All Users</h3>
            <table className="w-full text-left text-xs border border-borderLight dark:border-[#1F2937] rounded overflow-hidden">
              <thead className="bg-[#F4F5F7] dark:bg-[#101828]">
                <tr>
                  <th className="py-2 px-2 font-medium">Username</th>
                  <th className="py-2 px-2 font-medium">Name</th>
                  <th className="py-2 px-2 font-medium">Email</th>
                  <th className="py-2 px-2 font-medium">Password</th>
                  <th className="py-2 px-2 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.username} className="border-t border-borderLight dark:border-[#1F2937]">
                    <td className="py-1.5 px-2 text-[13px]">{u.username}</td>
                    <td className="py-1.5 px-2"><input value={u.name} onChange={(e)=>updateField(u.username,'name',e.target.value)} className="w-full bg-transparent outline-none"/></td>
                    <td className="py-1.5 px-2"><input value={u.email||''} onChange={(e)=>updateField(u.username,'email',e.target.value)} className="w-full bg-transparent outline-none"/></td>
                    <td className="py-1.5 px-2"><input type="password" value={u.password} onChange={(e)=>updateField(u.username,'password',e.target.value)} className="w-full bg-transparent outline-none"/></td>
                    <td className="py-1.5 px-2 flex gap-2">
                      <button onClick={()=>switchUser(u)} className="px-2 py-1 rounded border border-borderLight dark:border-[#1F2937] text-[11px] hover:bg-[#EBECF0] dark:hover:bg-[#101828]">Select</button>
                    </td>
                  </tr>
                ))}
                <tr className="border-t border-borderLight dark:border-[#1F2937] bg-[#F4F5F7] dark:bg-[#101828]">
                  <td className="py-1.5 px-2"><input placeholder="username" value={newUser.username} onChange={(e)=>setNewUser(n=>({...n,username:e.target.value}))} className="w-full bg-transparent outline-none"/></td>
                  <td className="py-1.5 px-2"><input placeholder="name" value={newUser.name} onChange={(e)=>setNewUser(n=>({...n,name:e.target.value}))} className="w-full bg-transparent outline-none"/></td>
                  <td className="py-1.5 px-2"><input placeholder="email" value={newUser.email} onChange={(e)=>setNewUser(n=>({...n,email:e.target.value}))} className="w-full bg-transparent outline-none"/></td>
                  <td className="py-1.5 px-2"><input placeholder="password" type="password" value={newUser.password} onChange={(e)=>setNewUser(n=>({...n,password:e.target.value}))} className="w-full bg-transparent outline-none"/></td>
                  <td className="py-1.5 px-2"><button onClick={addUser} className="px-2 py-1 rounded bg-atlassianBlue text-white text-[11px] flex items-center gap-1"><Plus className="w-3 h-3"/>Add</button></td>
                </tr>
              </tbody>
            </table>
            <div className="mt-3 flex justify-end">
              <button onClick={persistAll} className="px-3 py-1.5 text-sm rounded border border-borderLight dark:border-[#1F2937] hover:bg-[#EBECF0] dark:hover:bg-[#101828]">Save All Changes</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
