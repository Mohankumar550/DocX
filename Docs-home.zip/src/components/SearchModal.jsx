import { useEffect, useMemo, useState } from 'react'
import { loadDocsIndex } from '../utils/docsIndex'
import { useNavigate } from 'react-router-dom'

function collectDocs(tree, out=[]) {
  for (const n of tree){
    if (n.type==='doc') out.push(n)
    if (n.children) collectDocs(n.children,out)
  }
  return out
}
function strip(html){
  const tmp = document.createElement('div')
  tmp.innerHTML = html
  return tmp.textContent || tmp.innerText || ''
}

export default function SearchModal({ open, onClose }) {
  const [q,setQ]=useState('')
  const nav=useNavigate()
  const tree = loadDocsIndex()
  const docs = collectDocs(tree)
  const results = useMemo(()=>{
    if (!q.trim()) return []
    const needle = q.toLowerCase()
    return docs.map(d=>{
      const saved = JSON.parse(localStorage.getItem(`doc:${d.id}`) || '{}')
      const text = `${d.title} ${strip(saved.content || d.initial?.content || '')}`.toLowerCase()
      return text.includes(needle) ? { id:d.id, title: saved.title || d.title } : null
    }).filter(Boolean).slice(0,30)
  },[q])
  const openDoc = (id)=>{ onClose(); nav(`/docs/${id}`) }
  useEffect(()=> {
    const onKey = (e)=> { if (e.key==='Escape') onClose() }
    if (open) window.addEventListener('keydown',onKey)
    return ()=>window.removeEventListener('keydown',onKey)
  },[open])
  if (!open) return null
  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-start justify-center pt-24">
      <div className="w-[640px] bg-white dark:bg-[#0B0F1A] rounded border border-borderLight dark:border-[#1F2937] p-4">
        <input className="w-full border border-borderLight dark:border-[#1F2937] rounded px-3 py-2 mb-3 bg-white dark:bg-[#0F172A]" placeholder="Search pages and content…" value={q} onChange={e=>setQ(e.target.value)} autoFocus />
        <div className="max-h-[50vh] overflow-y-auto">
          {results.map(r=>(
            <div key={r.id} onClick={()=>openDoc(r.id)} className="px-2 py-2 rounded cursor-pointer hover:bg-[#F4F5F7] dark:hover:bg-[#101828]">
              {r.title}
            </div>
          ))}
          {q && results.length===0 && <div className="text-sm text-gray-500 px-2 py-2">No results</div>}
        </div>
      </div>
    </div>
  )
}
