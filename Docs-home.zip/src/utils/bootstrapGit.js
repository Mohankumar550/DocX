// bootstrapGit.js
// Hydrates localStorage with remote JSON (tree.json, users.json, individual docs optional lazy) if absent.
// It tries GitHub Pages first, then raw.githubusercontent.com.
// Environment variables (Vite): VITE_GH_OWNER, VITE_GH_REPO, VITE_GH_BRANCH, VITE_GH_BASEPATH, VITE_GH_TOKEN (write only).
// Token is NOT persisted here; only config for reading public content is set. Writes still require token via panel or env.

function readEnv(name, fallback = '') {
  return (import.meta.env && import.meta.env[name]) || fallback
}

// Reads config from Vite env OR falls back to baked defaults (without sensitive token).
function getConfigFromEnv() {
  // DEFAULT REPO (public read):
  const defaultOwner = 'Mohankumar550'
  const defaultRepo = 'Docx'
  const owner = readEnv('VITE_GH_OWNER', defaultOwner)
  const repo = readEnv('VITE_GH_REPO', defaultRepo)
  const branch = readEnv('VITE_GH_BRANCH', 'main')
  // basePath is a subfolder inside repo (NOT a full URL). Sanitize if user passed full URL accidentally.
  let basePath = readEnv('VITE_GH_BASEPATH', '').trim()
  if (basePath.includes('://')) basePath = ''
  const token = readEnv('VITE_GH_TOKEN', '') // only for write operations; leave blank for public read
  if (!owner || !repo) return null
  return { owner, repo, branch, basePath, token }
}

function ensureGithubSyncConfig() {
  let cfg = null
  try { cfg = JSON.parse(localStorage.getItem('githubSync') || 'null') } catch {}
  if (!cfg) {
    const envCfg = getConfigFromEnv()
    if (envCfg) {
      const { owner, repo, branch, basePath, token } = envCfg
      const storeCfg = { owner, repo, branch, basePath, // token deliberately excluded so user can still revoke
        // we do NOT store token automatically unless explicitly provided by env (opt-in)
        token: token || ''
      }
      localStorage.setItem('githubSync', JSON.stringify(storeCfg))
      return storeCfg
    }
    return null
  }
  return cfg
}

function buildPaths(cfg) {
  const prefixPath = cfg.basePath ? cfg.basePath.replace(/^\//,'').replace(/\/$/,'') + '/' : ''
  const pagesBase = `https://${cfg.owner}.github.io/${cfg.repo}/` + prefixPath
  const rawBase = `https://raw.githubusercontent.com/${cfg.owner}/${cfg.repo}/${cfg.branch}/` + prefixPath
  return { pagesBase, rawBase }
}

async function fetchJsonPreferPages(paths, file) {
  const urlPages = paths.pagesBase + file
  const urlRaw = paths.rawBase + file
  // Add cache busting
  const bust = (u) => u + (u.includes('?') ? '&' : '?') + 't=' + Date.now()
  try {
    const r = await fetch(bust(urlPages))
    if (r.ok) return await r.json()
  } catch {}
  try {
    const r2 = await fetch(bust(urlRaw))
    if (r2.ok) return await r2.json()
  } catch {}
  throw new Error('Remote fetch failed for ' + file)
}

// Attempt to load tree.json; if unavailable, try full-backup.json and unpack.
export async function bootstrapRemoteContent({ force = false } = {}) {
  const cfg = ensureGithubSyncConfig()
  if (!cfg) return { skipped: true, reason: 'No env or stored GitHub config' }
  // If docsIndex already exists and not forcing, skip
  if (!force && localStorage.getItem('docsIndex')) {
    return { skipped: true, reason: 'docsIndex already present' }
  }
  const paths = buildPaths(cfg)
  let hydrated = false
  try {
    const tree = await fetchJsonPreferPages(paths, 'tree.json')
    localStorage.setItem('docsIndex', JSON.stringify(tree))
    hydrated = true
  } catch (e) {
    // Fallback: full-backup.json (created by full sync) contains { index, users, docs }
    try {
      const backup = await fetchJsonPreferPages(paths, 'full-backup.json')
      if (backup && Array.isArray(backup.index)) {
        localStorage.setItem('docsIndex', JSON.stringify(backup.index))
        if (Array.isArray(backup.users)) {
          localStorage.setItem('usersData', JSON.stringify(backup.users))
        }
        if (Array.isArray(backup.docs)) {
          for (const d of backup.docs) {
            if (d && d.id) {
              localStorage.setItem('doc:' + d.id, JSON.stringify(d.data || { title: d.title || 'Untitled', content: '<p></p>' }))
            }
          }
        }
        hydrated = true
      } else {
        return { skipped: true, reason: 'tree.json & full-backup.json unavailable: ' + e.message }
      }
    } catch (e2) {
      return { skipped: true, reason: 'tree.json & full-backup.json fetch failed: ' + e2.message }
    }
  }
  // If we loaded only tree.json, optionally get users.json
  if (hydrated) {
    if (!localStorage.getItem('usersData')) {
      try {
        const users = await fetchJsonPreferPages(paths, 'users.json')
        if (Array.isArray(users)) localStorage.setItem('usersData', JSON.stringify(users))
      } catch {}
    }
    try { window.dispatchEvent(new CustomEvent('docs-index-updated')) } catch {}
    try { window.dispatchEvent(new CustomEvent('users-updated')) } catch {}
    return { skipped: false, hydrated: true }
  }
  return { skipped: true, reason: 'Hydration fell through unexpectedly' }
}

// Optional helper to lazy load a doc by ID if not yet in localStorage
export async function ensureDocLoaded(id) {
  const cfg = ensureGithubSyncConfig()
  if (!cfg) return false
  const key = 'doc:' + id
  if (localStorage.getItem(key)) return true
  const paths = buildPaths(cfg)
  try {
    const doc = await fetchJsonPreferPages(paths, `docs/${id}.json`)
    localStorage.setItem(key, JSON.stringify(doc))
    return true
  } catch {
    return false
  }
}
