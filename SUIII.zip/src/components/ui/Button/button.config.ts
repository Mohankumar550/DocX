// Normalization map for legacy + extended variants.
export function normalizeVariant(v: string): string {
  switch (v) {
    case 'contained': return 'contained';
    case 'outlined': return 'outlined';
    case 'soft': return 'soft';
    case 'tertiary': return 'tertiary';
    case 'solid': return 'contained'; // unify solid->contained
    case 'outline': return 'outlined';
    default: return v;
  }
}

export interface BuildButtonClassesOptions {
  variant: string;
  size: string;
  tone?: 'default' | 'error' | 'success' | 'warning';
  loading?: boolean;
  disabled?: boolean;
  fullWidth?: boolean;
  className?: string;
}

export function buildButtonClasses(opts: BuildButtonClassesOptions): string {
  const base = normalizeVariant(opts.variant);
  return [
    'dx-button',
    `dx-button--${base}`,
    `dx-button--${opts.size}`,
    opts.tone && opts.tone !== 'default' ? `dx-button--${opts.tone}` : '',
    opts.fullWidth ? 'dx-button--full' : '',
    (opts.disabled || opts.loading) ? 'dx-button--disabled' : '',
    opts.loading ? 'dx-button--loading' : '',
    opts.className || ''
  ].filter(Boolean).join(' ');
}
