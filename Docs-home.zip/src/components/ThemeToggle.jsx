import { useEffect, useState } from 'react'
import { Moon, Sun } from 'lucide-react'

export default function ThemeToggle(){
  const [dark, setDark] = useState(localStorage.getItem('theme') === 'dark')
  useEffect(()=>{
    const root = document.documentElement
    if (dark){ root.classList.add('dark'); localStorage.setItem('theme','dark') }
    else { root.classList.remove('dark'); localStorage.setItem('theme','light') }
  },[dark])
  return (
    <button className="flex items-center gap-2 px-2 py-1 rounded border border-borderLight dark:border-[#1F2937] hover:bg-[#F4F5F7] dark:hover:bg-[#101828] transition"
      onClick={()=>setDark(d=>!d)} title="Toggle theme">
      {dark ? <Sun className="w-4 h-4"/> : <Moon className="w-4 h-4"/>}
      <span className="text-sm">{dark ? 'Light' : 'Dark'}</span>
    </button>
  )
}
