import React from 'react';
import { useTheme } from '../../theming/useTheme';
import type { ThemeName } from '../../theming/themeManager';

// Group themes by prefix (corporate, saasy)
function groupThemes(themes: ThemeName[]): Record<string, ThemeName[]> {
  return themes.reduce<Record<string, ThemeName[]>>((acc, t) => {
    const g = t.split('-')[0];
    (acc[g] ||= []).push(t);
    return acc;
  }, {});
}

export const DXThemeSwitcher: React.FC<{ className?: string }> = ({ className }) => {
  const { theme, themes, setTheme } = useTheme();
  const grouped = groupThemes(themes);

  return (
    <div className={className} style={{ display:'flex', gap:'1rem', flexWrap:'wrap' }}>
      {Object.entries(grouped).map(([group, ids]) => (
        <div key={group} style={{ display:'flex', gap:'0.5rem' }} aria-label={`${group} theme modes`}>
          {ids.map(id => {
            const active = id === theme;
            const label = id.split('-')[1];
            return (
              <button
                key={id}
                type="button"
                onClick={() => setTheme(id)}
                aria-pressed={active}
                style={{
                  padding:'0.4rem 0.9rem',
                  borderRadius:'999px',
                  fontSize:'0.85rem',
                  fontWeight:500,
                  background: active ? 'var(--button-variants-contained-bg-default, var(--colors-primary-500))' : 'var(--surface-card, #f0f2f5)',
                  color: active ? 'var(--button-variants-contained-text-default, #fff)' : 'var(--colors-primary-500)',
                  border:'1px solid var(--colors-primary-500)',
                  transition:'background .2s,color .2s',
                  cursor:'pointer'
                }}
              >
                {group.charAt(0).toUpperCase() + group.slice(1)} {label.charAt(0).toUpperCase() + label.slice(1)}
              </button>
            );
          })}
        </div>
      ))}
    </div>
  );
};

export default DXThemeSwitcher;