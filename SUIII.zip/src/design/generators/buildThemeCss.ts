import { ThemeLoader } from '../services/ThemeLoader';
import { ThemeResolver } from '../services/ThemeResolver';
import { TokenMerger } from '../services/TokenMerger';
import { generateCssVariables, cssTextFromVars } from './generateCssVariables';
import sharedColors from '../../assets/styles/tokens/shared/colors.json';
import sharedTypography from '../../assets/styles/tokens/shared/typography.json';
import sharedSpacing from '../../assets/styles/tokens/shared/spacing.json';
import sharedRadius from '../../assets/styles/tokens/shared/radius.json';
import sharedShadow from '../../assets/styles/tokens/shared/shadow.json';
import sharedMotion from '../../assets/styles/tokens/shared/motion.json';
import sharedLayout from '../../assets/styles/tokens/shared/layout.json';
import sharedSemantic from '../../assets/styles/tokens/shared/semantic.json';

const loader = new ThemeLoader();
const merger = new TokenMerger();
const resolver = new ThemeResolver();

// Relax typing: treat each shared partial as a plain record and merge.
const shared = merger.merge(
  sharedColors as any,
  sharedTypography as any,
  sharedSpacing as any,
  sharedRadius as any,
  sharedShadow as any,
  sharedMotion as any,
  sharedLayout as any,
  sharedSemantic as any
);

export async function buildThemeCss(themeId: string): Promise<string> {
  const themeData = await loader.load(themeId);
  const node = { id: themeId, data: themeData, inherit: (themeData as any).inherit || [] };
  const resolved = resolver.resolve([node], shared as any);
  const { map } = generateCssVariables(resolved);
  return cssTextFromVars(map);
}
