import { topologicalSort } from '../algorithms/topologicalSort';
import { deepMerge } from '../algorithms/deepMerge';

interface ThemeNode { id: string; data: Record<string, any>; inherit: string[]; }

export class ThemeResolver {
  resolve(nodes: ThemeNode[], base: Record<string, any>): Record<string, any> {
    const idMap = new Map<string, ThemeNode>();
    for (const n of nodes) idMap.set(n.id, n);
    const edges: Array<[string,string]> = [];
    for (const n of nodes) {
      for (const parent of n.inherit) {
        edges.push([parent, n.id]);
      }
    }
    const order = topologicalSort(nodes.map(n => n.id), edges);
    let acc = deepMerge(base);
    for (const id of order) {
      const node = idMap.get(id)!;
      acc = deepMerge(acc, node.data);
    }
    // Resolve references
    acc = this.resolveRefs(acc);
    return acc;
  }

  private resolveRefs(obj: Record<string, any>): Record<string, any> {
    const REF = /\{([a-zA-Z0-9_.-]+)\}/;
    const getPath = (path: string): any => path.split('.').reduce((a, k) => (a ? a[k] : undefined), obj);
    const walk = (current: any): any => {
      if (Array.isArray(current)) return current.map(walk);
      if (current && typeof current === 'object') {
        const out: Record<string, any> = {};
        for (const k of Object.keys(current)) out[k] = walk(current[k]);
        return out;
      }
      if (typeof current === 'string') {
        const m = current.match(REF);
        if (m) {
          const resolved = getPath(m[1]);
          return resolved !== undefined ? walk(resolved) : current;
        }
      }
      return current;
    };
    return walk(obj);
  }
}
