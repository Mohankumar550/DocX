import { useEffect, useState } from 'react'
import { loadUsers, updateUser, getCurrentUser, setCurrentUser } from '../utils/users'

export default function UserProfilePanel({ open, onClose }) {
  const [users, setUsers] = useState(loadUsers())
  const [current, setCurrent] = useState(getCurrentUser())
  const [editing, setEditing] = useState({}) // username -> editing state
  const [drafts, setDrafts] = useState({}) // username -> {name,email}

  useEffect(()=>{
    const handleUsers = ()=>setUsers(loadUsers())
    const handleCurrent = ()=>setCurrent(getCurrentUser())
    window.addEventListener('users-updated', handleUsers)
    window.addEventListener('current-user-updated', handleCurrent)
    return ()=>{
      window.removeEventListener('users-updated', handleUsers)
      window.removeEventListener('current-user-updated', handleCurrent)
    }
  },[])

  if (!open) return null

  const beginEdit = (u) => {
    setEditing(e=>({...e,[u.username]:true}))
    setDrafts(d=>({...d,[u.username]:{ name: u.name || '', email: u.email || '' }}))
  }
  const cancelEdit = (u) => {
    setEditing(e=>{ const c={...e}; delete c[u.username]; return c })
    setDrafts(d=>{ const c={...d}; delete c[u.username]; return c })
  }
  const saveEdit = (u) => {
    const draft = drafts[u.username]
    const name = draft.name.trim() || 'Unnamed'
    const email = draft.email.trim()
    updateUser(u.username, { name, email })
    cancelEdit(u)
  }
  const makeCurrent = (u) => { setCurrentUser(u) }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end pointer-events-none">
      <div className="w-[420px] h-full bg-white dark:bg-[#0F172A] border-l border-borderLight dark:border-[#1F2937] shadow-xl pointer-events-auto flex flex-col">
        <div className="px-5 py-4 border-b border-borderLight dark:border-[#1F2937] flex items-center justify-between">
          <h2 className="text-lg font-semibold">Users</h2>
          <button onClick={onClose} className="text-sm px-2 py-1 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828]">Close</button>
        </div>
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {users.map(u => {
            const isEditing = editing[u.username]
            const draft = drafts[u.username] || {}
            return (
              <div key={u.username} className="border border-borderLight dark:border-[#1F2937] rounded p-3 bg-[#FDFDFE] dark:bg-[#101828]">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-medium text-sm">{u.username}</div>
                  {current?.username === u.username && <span className="text-[10px] px-1 py-0.5 rounded border border-atlassianBlue text-atlassianBlue">CURRENT</span>}
                </div>
                {isEditing ? (
                  <div className="space-y-2">
                    <input
                      className="w-full text-sm px-2 py-1 rounded border border-borderLight dark:border-[#1F2937] bg-white dark:bg-[#0F172A]"
                      value={draft.name}
                      placeholder="Name"
                      onChange={e=>setDrafts(d=>({...d,[u.username]:{...d[u.username],name:e.target.value}}))}
                    />
                    <input
                      className="w-full text-sm px-2 py-1 rounded border border-borderLight dark:border-[#1F2937] bg-white dark:bg-[#0F172A]"
                      value={draft.email}
                      placeholder="Email"
                      onChange={e=>setDrafts(d=>({...d,[u.username]:{...d[u.username],email:e.target.value}}))}
                    />
                    <div className="flex gap-2">
                      <button onClick={()=>saveEdit(u)} className="px-2 py-1 text-xs rounded bg-atlassianBlue text-white">Save</button>
                      <button onClick={()=>cancelEdit(u)} className="px-2 py-1 text-xs rounded border border-borderLight dark:border-[#1F2937]">Cancel</button>
                    </div>
                  </div>
                ) : (
                  <div className="text-xs space-y-1">
                    <div><span className="text-textSecondary dark:text-gray-400">Name:</span> {u.name || '—'}</div>
                    <div><span className="text-textSecondary dark:text-gray-400">Email:</span> {u.email || '—'}</div>
                    <div className="flex gap-2 mt-2">
                      <button onClick={()=>beginEdit(u)} className="px-2 py-1 text-xs rounded border border-borderLight dark:border-[#1F2937] hover:bg-[#EBECF0] dark:hover:bg-[#18263A]">Edit</button>
                      <button onClick={()=>makeCurrent(u)} className="px-2 py-1 text-xs rounded bg-[#F4F5F7] dark:bg-[#162032]">Set Current</button>
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
