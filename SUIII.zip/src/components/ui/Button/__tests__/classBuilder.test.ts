import { describe, it, expect } from 'vitest';
import { buildButtonClasses } from '../button.config';

describe('buildButtonClasses', () => {
	it('includes tone classes for success & warning', () => {
		const success = buildButtonClasses({ variant: 'contained', size: 'md', tone: 'success' });
		const warning = buildButtonClasses({ variant: 'outlined', size: 'sm', tone: 'warning' });
		expect(success).toMatch(/dx-button--success/);
		expect(warning).toMatch(/dx-button--warning/);
	});
});
