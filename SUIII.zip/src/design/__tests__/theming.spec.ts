import { describe, it, expect, beforeAll } from 'vitest';
import { listAvailableThemes, setTheme, loadSavedTheme } from '../../theming/themeManager';

// JSDOM already provides document; tests rely on style element injection.

describe('Theming system', () => {
  beforeAll(async () => {
    await loadSavedTheme();
  });

  it('lists available themes', () => {
    const themes = listAvailableThemes();
    expect(themes.length).toBeGreaterThanOrEqual(4);
    expect(themes).toContain('corporate-light');
    expect(themes).toContain('corporate-dark');
  });

  it('applies a theme and injects CSS variables', async () => {
    await setTheme('corporate-light');
    const styleEl = document.getElementById('theme-vars');
    expect(styleEl).toBeTruthy();
    const text = styleEl!.textContent || '';
    expect(text).toMatch(/--colors-primary-500: #3366FF;/); // corporate-light primary override
    expect(text).toMatch(/:root/);
  });

  it('switching theme replaces variables', async () => {
    await setTheme('corporate-light');
    const before = document.getElementById('theme-vars')!.textContent;
    await setTheme('corporate-dark');
    const after = document.getElementById('theme-vars')!.textContent;
    expect(before).not.toEqual(after);
    expect(after).toMatch(/--colors-primary-500: #2A7DFF;/); // dark primary 500
  });
});
