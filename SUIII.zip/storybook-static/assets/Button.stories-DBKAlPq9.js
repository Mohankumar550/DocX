import{j as e}from"./jsx-runtime-D_zvdyIk.js";import{D as a}from"./Button-BRfADTiw.js";import"./index-DMVOjPfi.js";const me={title:"Components/Button",component:a,tags:["autodocs"],args:{children:"Button",variant:"contained",size:"md",tone:"default",loading:!1,fullWidth:!1},parameters:{layout:"padded",docs:{description:{component:"DXButton is a polymorphic, accessible, theme-aware design system component. Use variant, tone, size and theme props to adapt appearance. Icon-only buttons require an aria-label."}}},argTypes:{children:{control:"text",description:"Button label content"},variant:{control:"select",options:["contained","outlined","soft","tertiary"],description:"Visual style variant"},size:{control:"radio",options:["sm","md","lg"],description:"Size scale"},tone:{control:"select",options:["default","error"],description:"Semantic tone mapping to color tokens"},theme:{control:"select",options:["light","dark","highcontrast"],description:"Optional theme override"},loading:{control:"boolean",description:"Loading state disables interaction"},fullWidth:{control:"boolean",description:"Stretch to container width"},iconLeft:{control:!1,description:"Leading icon element"},iconRight:{control:!1,description:"Trailing icon element"},as:{control:"text",description:"Polymorphic element type"},href:{control:"text",description:"Href when rendered as anchor"},debug:{control:"boolean",description:"Enable development diagnostics"},"aria-label":{control:"text",description:"Accessible label for icon-only usage"}}},o={},t={args:{variant:"contained"}},s={args:{variant:"outlined"}},n={args:{variant:"soft"}},i={args:{variant:"tertiary"}},c={render:r=>e.jsxs("div",{style:{display:"flex",gap:"0.75rem",flexWrap:"wrap"},children:[e.jsx(a,{...r,size:"sm",children:"Small"}),e.jsx(a,{...r,children:"Medium"}),e.jsx(a,{...r,size:"lg",children:"Large"})]})},d={args:{tone:"error",children:"Delete"}},l={args:{loading:!0,children:"Processing"}},p={args:{disabled:!0,children:"Disabled"}},m={args:{iconLeft:e.jsx("span",{"aria-hidden":!0,children:"🔥"}),iconRight:e.jsx("span",{"aria-hidden":!0,children:"➡️"}),children:"Hot Action"}},u={args:{iconLeft:e.jsx("span",{"aria-hidden":!0,children:"⭐"}),"aria-label":"Favourite"}},g={render:r=>e.jsxs("div",{style:{display:"flex",gap:"0.75rem",flexWrap:"wrap"},children:[e.jsx(a,{...r,theme:"light",children:"Light theme"}),e.jsx(a,{...r,theme:"dark",children:"Dark theme"}),e.jsx(a,{...r,theme:"highcontrast",children:"High Contrast"})]})},h={render:r=>e.jsxs("div",{style:{display:"flex",gap:"0.75rem",flexWrap:"wrap"},children:[e.jsx(a,{...r,variant:"contained",children:"Primary Action"}),e.jsx(a,{...r,variant:"outlined",children:"Secondary Action"})]})},y={args:{className:"u-accent-border",children:"Custom Styled"},parameters:{docs:{description:{story:"Example demonstrating consumer styling via className. Define .u-accent-border in your global or module CSS to customize border/color."}}}},f={args:{as:"a",href:"#docs",children:"Anchor Link"}};var x,S,v;o.parameters={...o.parameters,docs:{...(x=o.parameters)==null?void 0:x.docs,source:{originalSource:"{}",...(v=(S=o.parameters)==null?void 0:S.docs)==null?void 0:v.source}}};var D,b,B;t.parameters={...t.parameters,docs:{...(D=t.parameters)==null?void 0:D.docs,source:{originalSource:`{
  args: {
    variant: 'contained'
  }
}`,...(B=(b=t.parameters)==null?void 0:b.docs)==null?void 0:B.source}}};var X,L,j;s.parameters={...s.parameters,docs:{...(X=s.parameters)==null?void 0:X.docs,source:{originalSource:`{
  args: {
    variant: 'outlined'
  }
}`,...(j=(L=s.parameters)==null?void 0:L.docs)==null?void 0:j.source}}};var C,z,A;n.parameters={...n.parameters,docs:{...(C=n.parameters)==null?void 0:C.docs,source:{originalSource:`{
  args: {
    variant: 'soft'
  }
}`,...(A=(z=n.parameters)==null?void 0:z.docs)==null?void 0:A.source}}};var k,P,W;i.parameters={...i.parameters,docs:{...(k=i.parameters)==null?void 0:k.docs,source:{originalSource:`{
  args: {
    variant: 'tertiary'
  }
}`,...(W=(P=i.parameters)==null?void 0:P.docs)==null?void 0:W.source}}};var w,T,E;c.parameters={...c.parameters,docs:{...(w=c.parameters)==null?void 0:w.docs,source:{originalSource:`{
  render: (args: ButtonProps) => <div style={{
    display: 'flex',
    gap: '0.75rem',
    flexWrap: 'wrap'
  }}>\r
      <DXButton {...args} size="sm">Small</DXButton>\r
      <DXButton {...args}>Medium</DXButton>\r
      <DXButton {...args} size="lg">Large</DXButton>\r
    </div>
}`,...(E=(T=c.parameters)==null?void 0:T.docs)==null?void 0:E.source}}};var N,O,H;d.parameters={...d.parameters,docs:{...(N=d.parameters)==null?void 0:N.docs,source:{originalSource:`{
  args: {
    tone: 'error',
    children: 'Delete'
  }
}`,...(H=(O=d.parameters)==null?void 0:O.docs)==null?void 0:H.source}}};var I,R,F;l.parameters={...l.parameters,docs:{...(I=l.parameters)==null?void 0:I.docs,source:{originalSource:`{
  args: {
    loading: true,
    children: 'Processing'
  }
}`,...(F=(R=l.parameters)==null?void 0:R.docs)==null?void 0:F.source}}};var M,_,q;p.parameters={...p.parameters,docs:{...(M=p.parameters)==null?void 0:M.docs,source:{originalSource:`{
  args: {
    disabled: true,
    children: 'Disabled'
  }
}`,...(q=(_=p.parameters)==null?void 0:_.docs)==null?void 0:q.source}}};var U,V,G;m.parameters={...m.parameters,docs:{...(U=m.parameters)==null?void 0:U.docs,source:{originalSource:`{
  args: {
    iconLeft: <span aria-hidden>🔥</span>,
    iconRight: <span aria-hidden>➡️</span>,
    children: 'Hot Action'
  }
}`,...(G=(V=m.parameters)==null?void 0:V.docs)==null?void 0:G.source}}};var J,K,Q;u.parameters={...u.parameters,docs:{...(J=u.parameters)==null?void 0:J.docs,source:{originalSource:`{
  args: {
    iconLeft: <span aria-hidden>⭐</span>,
    'aria-label': 'Favourite'
  }
}`,...(Q=(K=u.parameters)==null?void 0:K.docs)==null?void 0:Q.source}}};var Y,Z,$;g.parameters={...g.parameters,docs:{...(Y=g.parameters)==null?void 0:Y.docs,source:{originalSource:`{
  render: (args: ButtonProps) => <div style={{
    display: 'flex',
    gap: '0.75rem',
    flexWrap: 'wrap'
  }}>\r
      <DXButton {...args} theme="light">Light theme</DXButton>\r
      <DXButton {...args} theme="dark">Dark theme</DXButton>\r
      <DXButton {...args} theme="highcontrast">High Contrast</DXButton>\r
    </div>
}`,...($=(Z=g.parameters)==null?void 0:Z.docs)==null?void 0:$.source}}};var ee,re,ae;h.parameters={...h.parameters,docs:{...(ee=h.parameters)==null?void 0:ee.docs,source:{originalSource:`{
  render: (args: ButtonProps) => <div style={{
    display: 'flex',
    gap: '0.75rem',
    flexWrap: 'wrap'
  }}>\r
      <DXButton {...args} variant="contained">Primary Action</DXButton>\r
      <DXButton {...args} variant="outlined">Secondary Action</DXButton>\r
    </div>
}`,...(ae=(re=h.parameters)==null?void 0:re.docs)==null?void 0:ae.source}}};var oe,te,se;y.parameters={...y.parameters,docs:{...(oe=y.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  args: {
    className: 'u-accent-border',
    children: 'Custom Styled'
  },
  parameters: {
    docs: {
      description: {
        story: 'Example demonstrating consumer styling via className. Define .u-accent-border in your global or module CSS to customize border/color.'
      }
    }
  }
}`,...(se=(te=y.parameters)==null?void 0:te.docs)==null?void 0:se.source}}};var ne,ie,ce;f.parameters={...f.parameters,docs:{...(ne=f.parameters)==null?void 0:ne.docs,source:{originalSource:`{
  args: {
    as: 'a',
    href: '#docs',
    children: 'Anchor Link'
  }
}`,...(ce=(ie=f.parameters)==null?void 0:ie.docs)==null?void 0:ce.source}}};const ue=["Default","Contained","Outlined","Soft","Tertiary","Sizes","ErrorTone","Loading","Disabled","WithIcons","IconOnly","Themes","PrimarySecondary","CustomClassName","AsLink"];export{f as AsLink,t as Contained,y as CustomClassName,o as Default,p as Disabled,d as ErrorTone,u as IconOnly,l as Loading,s as Outlined,h as PrimarySecondary,c as Sizes,n as Soft,i as Tertiary,g as Themes,m as WithIcons,ue as __namedExportsOrder,me as default};
