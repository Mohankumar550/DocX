import staticUsers from '../data/users.json'
import { markDirty } from './sync'

const USERS_KEY = 'usersData'

export function loadUsers() {
  const raw = localStorage.getItem(USERS_KEY)
  return raw ? JSON.parse(raw) : staticUsers
}

export function saveUsers(list){
  localStorage.setItem(USERS_KEY, JSON.stringify(list))
  try { window.dispatchEvent(new CustomEvent('users-updated')) } catch(e) { /* ignore */ }
  try { markDirty() } catch(e){ /* ignore */ }
}

export function updateUser(username, patch){
  const users = loadUsers()
  const idx = users.findIndex(u=>u.username===username)
  if (idx === -1) return false
  users[idx] = { ...users[idx], ...patch }
  saveUsers(users)
  return true
}

export function getCurrentUser(){
  const u = JSON.parse(localStorage.getItem('currentUser')||'null')
  return u
}

export function setCurrentUser(user){
  localStorage.setItem('currentUser', JSON.stringify(user))
  try { window.dispatchEvent(new CustomEvent('current-user-updated')) } catch(e){ /* ignore */ }
}
