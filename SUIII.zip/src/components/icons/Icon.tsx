import React from 'react';
import { getIconSvg } from './autoIconsRegistry';
import type { IconStyle } from './autoIconsRegistry';

export interface AutoIconProps {
  name: string; // file name without .svg
  style?: IconStyle; // outlined | solid | fontawesome
  size?: number; // pixel size square
  className?: string;
  title?: string;
  color?: string; // overrides currentColor
}

const FALLBACK_SVG = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M9 9l6 6M15 9l-6 6"/></svg>';

export const DXIcon: React.FC<AutoIconProps> = ({
  name,
  style = 'outlined',
  size = 24,
  className,
  title,
  color
}) => {
  let raw = getIconSvg(name, style) || FALLBACK_SVG;
  // Strip width/height attributes to allow responsive sizing.
  raw = raw.replace(/(width|height)="[^"]*"/g,'');
  // Force stroke="currentColor" so outlined icons (which often ship with hard-coded black) can inherit wrapper color.
  if(/stroke="/.test(raw)) {
    raw = raw.replace(/stroke="[^"]*"/g, 'stroke="currentColor"');
  } else {
    raw = raw.replace('<svg', '<svg stroke="currentColor"');
  }
  // For solid + fontawesome styles ensure fill currentColor if not specified, enabling color overrides.
  if(style === 'solid' || style === 'fontawesome') {
    // Replace existing non-none fills to currentColor; if none present add one.
    if(/fill="/.test(raw)) {
      raw = raw.replace(/fill="(?!none)[^"]*"/g,'fill="currentColor"');
    } else {
      raw = raw.replace('<svg', '<svg fill="currentColor"');
    }
  }
  // Wrap for size control.
  const wrapperStyle: React.CSSProperties = { width: size, height: size, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', color };
  return (
    <span
      role="img"
      aria-label={title || name}
      className={className}
      style={wrapperStyle}
      dangerouslySetInnerHTML={{ __html: raw }}
    />
  );
};

export default DXIcon;
