import React from 'react';
import type { ButtonProps } from './button.types';
import { buildButtonClasses } from './button.config';

/** Internal spinner (minimal – rely on CSS for animation) */
const Spinner: React.FC<{ className?: string; label?: string }> = ({ className, label }) => (
	<span className={className ? `${className} dx-button__spinner` : 'dx-button__spinner'} aria-hidden="true">
		{label && <span className="visually-hidden">{label}</span>}
	</span>
);

/**
 * DXButton – Accessible, polymorphic design-system button.
 * Provides variants, tones, size, theme override, loading & icon support.
 */
export const DXButton = React.forwardRef<
	HTMLButtonElement | HTMLAnchorElement | HTMLElement,
	ButtonProps
>(
	(
		{
			variant = 'contained',
			size = 'md',
			tone = 'default',
			theme,
			iconLeft,
			iconRight,
			loading = false,
			fullWidth = false,
			disabled,
			className,
			children,
			as = 'button',
			href,
			type = 'button',
			debug = false,
			style,
			onClick,
			onKeyDown,
			...rest
		},
		ref
	) => {
		const computedDisabled = disabled || loading;
		const isIconOnly = !children && (iconLeft || iconRight);
		let classes = buildButtonClasses({ variant, size, tone, loading, fullWidth, disabled: computedDisabled, className });
		if (isIconOnly) classes += ' dx-button--icon-only';

		// Dev diagnostics (guarded for tree-shaking) & accessibility warnings
		React.useEffect(() => {
			if (debug) {
				// eslint-disable-next-line no-console
				console.log('[DXButton] mount', { variant, size, tone, theme, loading, disabled: computedDisabled });
				if (isIconOnly && !rest['aria-label']) {
					// eslint-disable-next-line no-console
					console.warn('[DXButton] icon-only usage requires aria-label for accessibility');
				}
			}
		}, [debug, isIconOnly, rest, variant, size, tone, theme, loading, computedDisabled]);

		// Keyboard activation for polymorphic non-button elements
			const handleKeyDown: React.KeyboardEventHandler<HTMLElement> = (e) => {
				// Cast to any to support polymorphic element targets beyond HTMLButtonElement
				if (onKeyDown) onKeyDown(e as any);
			if (computedDisabled) return;
			const shouldActivate = (e.key === ' ' || e.key === 'Enter') && as !== 'button';
			if (shouldActivate && onClick) {
				e.preventDefault();
				const synthetic = new MouseEvent('click', { bubbles: true, cancelable: true });
				e.currentTarget.dispatchEvent(synthetic);
			}
		};

		const content = (
			<>
				{loading && <Spinner />}
				{iconLeft && (
					<span className="dx-button__icon dx-button__icon--left" aria-hidden="true">
						{iconLeft}
					</span>
				)}
				{/* Preserve original label prefix */}
				<span className="dx-button__label">DX {children}</span>
				{iconRight && (
					<span className="dx-button__icon dx-button__icon--right" aria-hidden="true">
						{iconRight}
					</span>
				)}
			</>
		);

		// Sanitize 'as' prop: treat empty string / invalid tag names as native button fallback.
		const asTag = typeof as === 'string' && as.trim() === '' ? 'button' : as;
		// Polymorphic branch for non-native button elements
		if (asTag !== 'button') {
			const Comp: any = asTag;
			const isAnchor = as === 'a';
			return (
				<Comp
					ref={ref}
					href={href}
					className={classes}
					style={style}
					data-variant={variant}
					data-size={size}
					data-tone={tone}
					data-theme={theme || undefined}
					aria-busy={loading || undefined}
					aria-disabled={computedDisabled || undefined}
					role={!isAnchor ? 'button' : undefined}
					tabIndex={computedDisabled ? -1 : rest.tabIndex}
					onClick={computedDisabled ? undefined : onClick}
					onKeyDown={handleKeyDown}
					{...rest}
				>
					{content}
				</Comp>
			);
		}

		return (
			<button
				ref={ref as React.Ref<HTMLButtonElement>}
				type={type}
				disabled={computedDisabled}
				className={classes}
				style={style}
				data-variant={variant}
				data-size={size}
				data-tone={tone}
				data-theme={theme || undefined}
				aria-busy={loading || undefined}
				onClick={onClick}
				onKeyDown={onKeyDown}
				{...rest}
			>
				{content}
			</button>
		);
	}
);

DXButton.displayName = 'DXButton';

export default DXButton;
