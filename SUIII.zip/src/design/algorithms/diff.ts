export interface DiffNode {
  path: string;
  type: 'added' | 'removed' | 'changed';
  before?: unknown;
  after?: unknown;
}

export function diffTokens(a: any, b: any, prefix: string[] = [], out: DiffNode[] = []): DiffNode[] {
  const aKeys = new Set(Object.keys(a || {}));
  const bKeys = new Set(Object.keys(b || {}));
  const all = new Set([...aKeys, ...bKeys]);
  for (const key of Array.from(all).sort()) {
    const nextPath = [...prefix, key];
    const aVal = a ? a[key] : undefined;
    const bVal = b ? b[key] : undefined;
    if (aVal === undefined && bVal !== undefined) {
      out.push({ path: nextPath.join('.'), type: 'added', after: bVal });
    } else if (aVal !== undefined && bVal === undefined) {
      out.push({ path: nextPath.join('.'), type: 'removed', before: aVal });
    } else if (isObject(aVal) && isObject(bVal)) {
      diffTokens(aVal, bVal, nextPath, out);
    } else if (aVal !== bVal) {
      out.push({ path: nextPath.join('.'), type: 'changed', before: aVal, after: bVal });
    }
  }
  return out;
}

function isObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}
