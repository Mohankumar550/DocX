import { describe, it, expect } from 'vitest';
import { buildThemeCss } from '../design/generators/buildThemeCss';

describe('themeManager pipeline (simplified)', () => {
  it('builds CSS for corporate-light', async () => {
    const css = await buildThemeCss('corporate-light');
    expect(css).toMatch(/--colors-primary-500/);
  });
});
