// Vitest environment types assumed; if missing add to tsconfig "types".
import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { DXInput } from '../Input';

describe('DXInput', () => {
  it('renders label and placeholder', () => {
    render(<DXInput label='Name' placeholder='Enter name' />);
    const input = screen.getByLabelText('Name') as HTMLInputElement;
    expect(input).toBeInTheDocument();
    expect(input.placeholder).toBe('Enter name');
  });

  it('applies required and aria-required', () => {
    render(<DXInput label='Name' required />);
    const input = screen.getByLabelText('Name');
    expect(input).toHaveAttribute('required');
    expect(input).toHaveAttribute('aria-required', 'true');
  });

  it('marks error state with aria-invalid', () => {
    render(<DXInput label='Name' status='error' defaultValue='Bad' />);
    const input = screen.getByLabelText('Name');
    expect(input).toHaveAttribute('aria-invalid', 'true');
  });
});
