declare module '*.svg?raw' {
  const content: string;
  export default content;
}

declare module '*.svg' {
  const content: string; // fallback, when imported as raw we still treat as string
  export default content;
}
