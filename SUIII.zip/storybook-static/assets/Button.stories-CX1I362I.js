import{j as t}from"./jsx-runtime-D_zvdyIk.js";import{D as e}from"./Button-BRfADTiw.js";import"./index-DMVOjPfi.js";const W={title:"UI/Button",component:e,parameters:{backgrounds:{default:"dark",values:[{name:"dark",value:"#0f1623"},{name:"light",value:"#ffffff"}]}},args:{variant:"contained",size:"md",tone:"default",children:"Button"},argTypes:{variant:{control:"select",options:["contained","outlined","soft","tertiary","ghost"]},size:{control:"inline-radio",options:["sm","md","lg"]},tone:{control:"select",options:["default","success","warning","error"]},fullWidth:{control:"boolean"},loading:{control:"boolean"},iconLeft:{control:!1},iconRight:{control:!1}}},a={render:r=>t.jsxs("div",{style:{display:"grid",gap:"1rem",gridTemplateColumns:"repeat(auto-fit,minmax(160px,1fr))"},children:[t.jsx(e,{...r,variant:"contained",children:"Contained"}),t.jsx(e,{...r,variant:"outlined",children:"Outlined"}),t.jsx(e,{...r,variant:"soft",children:"Soft"}),t.jsx(e,{...r,variant:"tertiary",children:"Tertiary"}),t.jsx(e,{...r,variant:"ghost",children:"Ghost"})]})},n={render:r=>t.jsxs("div",{style:{display:"grid",gap:"1rem",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))"},children:[t.jsx(e,{...r,tone:"error",variant:"contained",children:"Error Contained"}),t.jsx(e,{...r,tone:"success",variant:"soft",children:"Success Soft"}),t.jsx(e,{...r,tone:"warning",variant:"outlined",children:"Warning Outlined"}),t.jsx(e,{...r,tone:"success",variant:"contained",children:"Success Contained"}),t.jsx(e,{...r,tone:"warning",variant:"soft",children:"Warning Soft"})]})},i={render:r=>t.jsxs("div",{style:{display:"flex",gap:"1rem",flexWrap:"wrap"},children:[t.jsx(e,{...r,loading:!0,children:"Loading"}),t.jsx(e,{...r,disabled:!0,children:"Disabled"}),t.jsx(e,{...r,loading:!0,variant:"outlined",children:"Loading Outlined"})]})},o={render:r=>t.jsx("div",{style:{width:"420px"},children:t.jsx(e,{...r,fullWidth:!0,size:"lg",children:"Full Width Large"})})},s={render:r=>t.jsxs("div",{style:{display:"flex",gap:"1rem",flexWrap:"wrap",alignItems:"center"},children:[t.jsx(e,{...r,iconLeft:t.jsx("span",{"aria-hidden":!0,children:"🔥"}),iconRight:t.jsx("span",{"aria-hidden":!0,children:"➡️"}),children:"Icon Left/Right"}),t.jsx(e,{...r,variant:"soft",iconLeft:t.jsx("span",{"aria-hidden":!0,children:"⭐"}),"aria-label":"Star"})]})};var d,l,c;a.parameters={...a.parameters,docs:{...(d=a.parameters)==null?void 0:d.docs,source:{originalSource:`{
  render: args => <div style={{
    display: 'grid',
    gap: '1rem',
    gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))'
  }}>\r
      <DXButton {...args} variant="contained">Contained</DXButton>\r
      <DXButton {...args} variant="outlined">Outlined</DXButton>\r
      <DXButton {...args} variant="soft">Soft</DXButton>\r
      <DXButton {...args} variant="tertiary">Tertiary</DXButton>\r
      <DXButton {...args} variant="ghost">Ghost</DXButton>\r
    </div>
}`,...(c=(l=a.parameters)==null?void 0:l.docs)==null?void 0:c.source}}};var u,p,g;n.parameters={...n.parameters,docs:{...(u=n.parameters)==null?void 0:u.docs,source:{originalSource:`{
  render: args => <div style={{
    display: 'grid',
    gap: '1rem',
    gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))'
  }}>\r
      <DXButton {...args} tone="error" variant="contained">Error Contained</DXButton>\r
      <DXButton {...args} tone="success" variant="soft">Success Soft</DXButton>\r
      <DXButton {...args} tone="warning" variant="outlined">Warning Outlined</DXButton>\r
      <DXButton {...args} tone="success" variant="contained">Success Contained</DXButton>\r
      <DXButton {...args} tone="warning" variant="soft">Warning Soft</DXButton>\r
    </div>
}`,...(g=(p=n.parameters)==null?void 0:p.docs)==null?void 0:g.source}}};var m,f,h;i.parameters={...i.parameters,docs:{...(m=i.parameters)==null?void 0:m.docs,source:{originalSource:`{
  render: args => <div style={{
    display: 'flex',
    gap: '1rem',
    flexWrap: 'wrap'
  }}>\r
      <DXButton {...args} loading>Loading</DXButton>\r
      <DXButton {...args} disabled>Disabled</DXButton>\r
      <DXButton {...args} loading variant="outlined">Loading Outlined</DXButton>\r
    </div>
}`,...(h=(f=i.parameters)==null?void 0:f.docs)==null?void 0:h.source}}};var x,v,D;o.parameters={...o.parameters,docs:{...(x=o.parameters)==null?void 0:x.docs,source:{originalSource:`{
  render: args => <div style={{
    width: '420px'
  }}>\r
      <DXButton {...args} fullWidth size="lg">Full Width Large</DXButton>\r
    </div>
}`,...(D=(v=o.parameters)==null?void 0:v.docs)==null?void 0:D.source}}};var B,X,j;s.parameters={...s.parameters,docs:{...(B=s.parameters)==null?void 0:B.docs,source:{originalSource:`{
  render: args => <div style={{
    display: 'flex',
    gap: '1rem',
    flexWrap: 'wrap',
    alignItems: 'center'
  }}>\r
      <DXButton {...args} iconLeft={<span aria-hidden>🔥</span>} iconRight={<span aria-hidden>➡️</span>}>Icon Left/Right</DXButton>\r
      <DXButton {...args} variant="soft" iconLeft={<span aria-hidden>⭐</span>} aria-label="Star" />\r
    </div>
}`,...(j=(X=s.parameters)==null?void 0:X.docs)==null?void 0:j.source}}};const b=["Variants","Tones","DisabledLoading","FullWidth","Icons"];export{i as DisabledLoading,o as FullWidth,s as Icons,n as Tones,a as Variants,b as __namedExportsOrder,W as default};
