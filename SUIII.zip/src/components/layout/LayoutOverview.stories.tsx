import type { Meta, StoryObj } from '@storybook/react';
import { DXContainer } from './Container/Container';
import { DXGrid } from './Grid/Grid';
import { DXSection } from './Section/Section';
import { DXSurface } from './Surface/Surface';

const meta: Meta = {
  title: 'Layout/Overview',
  parameters: {
    docs: {
      description: {
        component: `# Layout System\n\nThe layout primitives provide consistent spacing, alignment, and responsive behavior.\n\n**Components**\n- **DXContainer**: Centers content and constrains width. Use \`fluid\` for full-width.\n- **DXGrid**: CSS Grid wrapper with customizable column count via \`columns\` prop.\n- **DXSection**: Vertical block with standardized padding for page segmentation.\n- **DXSurface**: Panel with background, border, and elevation variants (sm|md|lg).\n\n**Design Tokens Referenced**\n- Container: \`--layout-container-max-width\`, \`--layout-container-padding-x\`\n- Grid: \`--layout-grid-gap\`\n- Section: \`--layout-section-padding-y\`\n- Surface: \`--layout-surface-background\`, shadows, radius, spacing tokens.\n\n**Guidelines**\n- Nest \`DXGrid\` inside \`DXContainer\` for responsive pages.\n- Use \`DXSection\` to separate major page regions (hero, content, footer).\n- Elevation communicates hierarchy; prefer sm for subtle grouping, md/lg for modals or emphasis.\n- Avoid mixing custom inline padding that conflicts with token-driven spacing.\n\n**Advanced**\nComposite examples below show how primitives combine for real layouts.\n`
      }
    }
  }
};
export default meta;

export const CompositeExample: StoryObj = {
  name: 'Composite Example',
  render: () => (
    <DXSection>
      <DXContainer>
        <DXGrid columns={12} style={{ ['--layout-grid-gap' as any]: 'var(--spacing-4)' }}>
          <div style={{ gridColumn: 'span 12' }}>
            <DXSurface elevation="md" style={{ padding: 'var(--spacing-6)' }}>
              <h2 style={{ marginTop: 0 }}>Hero Block</h2>
              <p>Demonstrates a hero surface spanning full width within a constrained container.</p>
            </DXSurface>
          </div>
          {[1,2,3].map(i => (
            <div key={i} style={{ gridColumn: 'span 4' }}>
              <DXSurface elevation="sm">
                <strong>Card {i}</strong>
                <p style={{ fontSize: '0.85rem' }}>Grid card using 12 column layout (span 4).</p>
              </DXSurface>
            </div>
          ))}
          <div style={{ gridColumn: 'span 8' }}>
            <DXSurface elevation="lg">
              <strong>Main Content</strong>
              <p>Spans 8 columns—use larger elevation for primary interactive areas or focus blocks.</p>
            </DXSurface>
          </div>
          <div style={{ gridColumn: 'span 4' }}>
            <DXSurface elevation="sm">
              <strong>Sidebar</strong>
              <p>Ancillary actions or navigation.</p>
            </DXSurface>
          </div>
        </DXGrid>
      </DXContainer>
    </DXSection>
  )
};
