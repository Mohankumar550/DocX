import React from 'react';

export type DXCheckboxTone = 'default' | 'error';
export type DXCheckboxSize = 'sm' | 'md';

export interface DXCheckboxProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'onChange' | 'type'> {
  name?: string; // optional for single checkbox
  value?: string; // emitted value
  label: React.ReactNode;
  description?: React.ReactNode;
  checked?: boolean;
  defaultChecked?: boolean;
  disabled?: boolean;
  size?: DXCheckboxSize;
  tone?: DXCheckboxTone;
  indeterminate?: boolean; // visual state only
  onChange?: (checked: boolean, e: React.ChangeEvent<HTMLInputElement>) => void;
  id?: string;
  className?: string;
}

/** DXCheckbox – Accessible, styled checkbox with indeterminate support */
export const DXCheckbox: React.FC<DXCheckboxProps> = ({
  name,
  value,
  label,
  description,
  checked,
  defaultChecked,
  disabled,
  size = 'sm',
  tone = 'default',
  indeterminate = false,
  onChange,
  id,
  className,
  ...rest
}) => {
  const autoId = React.useId();
  const inputId = id || `dx-checkbox-${autoId}`;
  const ref = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (ref.current) {
      ref.current.indeterminate = indeterminate && !checked && !defaultChecked;
    }
  }, [indeterminate, checked, defaultChecked]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (onChange) onChange(e.target.checked, e);
  };

  let classes = `dx-checkbox dx-checkbox--${size}`;
  if (tone === 'error') classes += ' dx-checkbox--error';
  if (disabled) classes += ' dx-checkbox--disabled';
  if (className) classes += ` ${className}`;

  // data-state for styling indeterminate bar
  const stateAttr = indeterminate && !checked && !defaultChecked ? 'indeterminate' : undefined;

  return (
    <label className={classes} data-tone={tone} data-size={size}>
      <input
        ref={ref}
        id={inputId}
        className="dx-checkbox__input"
        type="checkbox"
        name={name}
        value={value}
        disabled={disabled}
        checked={checked}
        defaultChecked={defaultChecked}
        onChange={handleChange}
        aria-describedby={description ? `${inputId}-desc` : undefined}
        {...rest}
      />
      <span className="dx-checkbox__control" aria-hidden="true">
        <span className="dx-checkbox__check" data-state={stateAttr} />
      </span>
      <span className="dx-checkbox__text">
        <span className="dx-checkbox__label">{label}</span>
        {description && (
          <span id={`${inputId}-desc`} className="dx-checkbox__description">{description}</span>
        )}
      </span>
    </label>
  );
};

DXCheckbox.displayName = 'DXCheckbox';

export interface DXCheckboxOption { value: string; label: React.ReactNode; description?: React.ReactNode; disabled?: boolean; defaultChecked?: boolean; }
export interface DXCheckboxGroupProps {
  name: string;
  values?: string[]; // controlled selected values
  defaultValues?: string[]; // uncontrolled initial
  options: DXCheckboxOption[];
  onChange?: (values: string[]) => void;
  tone?: DXCheckboxTone;
  size?: DXCheckboxSize;
  disabled?: boolean;
  orientation?: 'vertical' | 'horizontal';
  className?: string;
  label?: React.ReactNode;
  description?: React.ReactNode;
}

/** DXCheckboxGroup – maps options to DXCheckbox instances supporting multi-select */
export const DXCheckboxGroup: React.FC<DXCheckboxGroupProps> = ({
  name,
  values,
  defaultValues = [],
  options,
  onChange,
  tone = 'default',
  size = 'sm',
  disabled,
  orientation = 'vertical',
  className,
  label,
  description
}) => {
  const [internalValues, setInternalValues] = React.useState<string[]>(defaultValues);
  const isControlled = values !== undefined;
  const current = isControlled ? values! : internalValues;
  const groupClasses = `dx-checkbox-group ${orientation === 'horizontal' ? 'dx-checkbox-group--horizontal' : ''}` + (className ? ` ${className}` : '');

  const toggle = (val: string) => {
    let next: string[];
    if (current.includes(val)) {
      next = current.filter(v => v !== val);
    } else {
      next = [...current, val];
    }
    if (!isControlled) setInternalValues(next);
    if (onChange) onChange(next);
  };

  return (
    <fieldset className={groupClasses} disabled={disabled} style={{ border: 0, padding: 0, margin: 0 }}>
      {label && <legend style={{ fontWeight: 600, fontSize: '0.85rem', marginBottom: '0.25rem' }}>{label}</legend>}
      {description && <div style={{ fontSize: '0.7rem', marginBottom: '0.5rem', color: 'var(--colors-text-secondary,#667085)' }}>{description}</div>}
      {options.map(opt => (
        <DXCheckbox
          key={opt.value}
          name={name}
          value={opt.value}
          label={opt.label}
          description={opt.description}
          size={size}
          tone={tone}
          disabled={disabled || opt.disabled}
          checked={current.includes(opt.value)}
          defaultChecked={opt.defaultChecked}
          onChange={() => toggle(opt.value)}
        />
      ))}
    </fieldset>
  );
};

DXCheckboxGroup.displayName = 'DXCheckboxGroup';

export default DXCheckbox;
