export function memo<T extends (...args: any[]) => any>(fn: T, ttlMs = 0) {
  let cache: { args: any[]; value: any; expires: number } | null = null;
  return (...args: Parameters<T>): ReturnType<T> => {
    const now = Date.now();
    if (cache && (ttlMs === 0 || cache.expires > now) && shallowEqual(cache.args, args)) {
      return cache.value;
    }
    const value = fn(...args);
    cache = { args, value, expires: now + ttlMs };
    return value;
  };
}

function shallowEqual(a: any[], b: any[]): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}
