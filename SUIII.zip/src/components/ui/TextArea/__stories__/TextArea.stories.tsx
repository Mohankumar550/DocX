import type { Meta, StoryObj } from '@storybook/react';
import { DXTextArea } from '../TextArea';

const meta: Meta<typeof DXTextArea> = {
  title: 'Components/TextArea',
  component: DXTextArea,
  tags: ['autodocs'],
  argTypes: {
    status: { control: { type: 'select', options: ['default','success','warning','error'] } },
    size: { control: { type: 'select', options: ['default','sm'] } },
    required: { control: 'boolean' },
    disabled: { control: 'boolean' },
    placeholder: { control: 'text' },
    label: { control: 'text' },
    description: { control: 'text' },
    rows: { control: { type: 'number' } },
    maxLength: { control: { type: 'number' } },
    showCount: { control: 'boolean' },
    onChange: { action: 'change' }
  },
  args: {
    label: 'Application Name',
    placeholder: 'Enter application details',
    description: 'This area captures multi-line details.',
    required: false,
    disabled: false,
    status: 'default',
    size: 'default',
    rows: 5,
    showCount: false
  }
};
export default meta;

type Story = StoryObj<typeof DXTextArea>;

export const Playground: Story = {};

export const StatesDefault: Story = {
  render: () => (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(300px,1fr))', gap:'1rem' }}>
      <DXTextArea label='Application Name' placeholder='Placeholder' />
      <DXTextArea label='Application Name' required placeholder='Required (empty)' />
      <DXTextArea label='Application Name' required defaultValue='Filled value' />
      <DXTextArea label='Application Name' status='success' defaultValue='Valid value' />
      <DXTextArea label='Application Name' status='warning' defaultValue='Needs review' />
      <DXTextArea label='Application Name' status='error' defaultValue='Bad value' />
      <DXTextArea label='Application Name' disabled placeholder='Disabled placeholder' />
      <DXTextArea label='Application Name' disabled defaultValue='Disabled filled content' />
      <DXTextArea label='Application Name' defaultValue='Character count example text' showCount maxLength={120} description='Shows dynamic count.' />
    </div>
  )
};

export const StatesSmall: Story = {
  render: () => (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(260px,1fr))', gap:'1rem' }}>
      <DXTextArea size='sm' label='App' placeholder='Placeholder' />
      <DXTextArea size='sm' label='App' required placeholder='Required (empty)' />
      <DXTextArea size='sm' label='App' required defaultValue='Filled value' />
      <DXTextArea size='sm' label='App' status='success' defaultValue='Valid' />
      <DXTextArea size='sm' label='App' status='warning' defaultValue='Check' />
      <DXTextArea size='sm' label='App' status='error' defaultValue='Error' />
      <DXTextArea size='sm' label='App' disabled placeholder='Disabled' />
      <DXTextArea size='sm' label='App' disabled defaultValue='Disabled value' />
    </div>
  )
};

export const FocusExample: Story = {
  render: () => (
    <div style={{ maxWidth:380 }}>
      <DXTextArea label='Focus Me' defaultValue='Tab into me' description='Use Tab key to view focus ring.' />
    </div>
  )
};

export const StatesVisualMatrix: Story = {
  render: () => (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:'1rem' }}>
      <DXTextArea label='Normal' placeholder='Placeholder' />
      <DXTextArea className='dx-textarea--simulate-hover' label='Hover (simulated)' placeholder='Placeholder' />
      <DXTextArea className='dx-textarea--simulate-focus' label='Focus (simulated)' defaultValue='Focused value' />
      <DXTextArea className='dx-textarea--simulate-focus-filled' label='Focus + Filled' defaultValue='Filled value' />
      <DXTextArea disabled label='Disabled' placeholder='Disabled' />
    </div>
  )
};
