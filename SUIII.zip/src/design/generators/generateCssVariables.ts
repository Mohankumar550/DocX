// Refactored: this generator now accepts an already merged token object.
// (Previous version used a monolithic theme.json). Keep backwards-compatible types minimal.
export interface GeneratedVariables {
  map: Record<string, string>;
  cssText: string;
}

const REF_REGEX = /^\{([a-zA-Z0-9_.-]+)\}$/;

type AnyRecord = Record<string, unknown>;

function isRecord(v: unknown): v is AnyRecord {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

function toKebab(input: string): string {
  return input
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    .replace(/_/g, '-')
    .toLowerCase();
}

function getValueFromPath(obj: AnyRecord, path: string): unknown {
  return path.split('.').reduce<unknown>((acc, key) => (isRecord(acc) ? acc[key] : undefined), obj);
}

// Attempt resolution first in current theme, then fall back to entire themes collection
function resolveValue(raw: unknown, theme: AnyRecord, allThemes: AnyRecord, visited: Set<string> = new Set()): string {
  if (typeof raw !== 'string') return String(raw);
  const match = raw.match(REF_REGEX);
  if (!match) return raw;
  const refPath = match[1];
  if (visited.has(refPath)) {
    console.warn(`Circular theme reference detected: ${refPath}`);
    return raw;
  }
  visited.add(refPath);

  // local first
  let resolved = getValueFromPath(theme, refPath);
  if (resolved === undefined) {
    // global theme-level reference (e.g. corporate-light.colors.neutral)
    resolved = getValueFromPath(allThemes, refPath);
  }
  if (resolved === undefined) {
    console.warn(`Theme reference not found: ${refPath}`);
    return raw; // keep original so failure is visible
  }
  return resolveValue(resolved, theme, allThemes, visited); // support nested refs
}

function flatten(obj: AnyRecord, theme: AnyRecord, allThemes: AnyRecord, prefix: string[] = [], out: Record<string, string> = {}): Record<string, string> {
  Object.entries(obj).forEach(([key, value]) => {
    const nextPath = [...prefix, toKebab(key)];
    if (isRecord(value)) {
      flatten(value, theme, allThemes, nextPath, out);
    } else {
      const varName = '--' + nextPath.join('-');
      out[varName] = resolveValue(value, theme, allThemes);
    }
  });
  return out;
}

export function generateCssVariables(mergedTokens: Record<string, unknown>, allThemes?: Record<string, unknown>): GeneratedVariables {
  const map = flatten(mergedTokens as AnyRecord, mergedTokens as AnyRecord, (allThemes || {}) as AnyRecord);
  const declarations = Object.entries(map).map(([k,v]) => `${k}: ${v};`).join('\n');
  return { map, cssText: `:root\n{\n${declarations}\n}` };
}

export function cssTextFromVars(vars: Record<string,string>): string {
  return ':root{\n' + Object.entries(vars).map(([k,v]) => `${k}: ${v};`).join('\n') + '\n}';
}
