export function topologicalSort(nodes: string[], edges: Array<[string, string]>): string[] {
  const incoming: Record<string, number> = {};
  const outgoing: Record<string, string[]> = {};
  for (const n of nodes) { incoming[n] = 0; outgoing[n] = []; }
  for (const [from, to] of edges) {
    if (!outgoing[from]) outgoing[from] = [];
    outgoing[from].push(to);
    incoming[to] = (incoming[to] ?? 0) + 1;
  }
  const queue: string[] = Object.keys(incoming).filter(k => incoming[k] === 0);
  const result: string[] = [];
  while (queue.length) {
    const n = queue.shift()!;
    result.push(n);
    for (const m of outgoing[n] || []) {
      incoming[m] -= 1;
      if (incoming[m] === 0) queue.push(m);
    }
  }
  if (result.length !== nodes.length) {
    throw new Error('Cycle detected in inheritance graph');
  }
  return result;
}
