const API = 'https://api.github.com'

function sanitizePath(p){
  // Remove protocol/domain if user pasted a full URL; keep only path after repo root
  if (!p) return ''
  try {
    if (/^https?:\/\//i.test(p)) {
      const u = new URL(p)
      p = u.pathname // e.g. /owner/repo/blob/main/sub/file.json or /owner/repo/sub/file.json
      // Strip leading /owner/repo(/blob/<branch>)?
      const parts = p.split('/').filter(Boolean)
      const idx = parts.findIndex(seg => seg === 'blob')
      if (idx !== -1 && parts.length > idx+1) {
        // remove owner, repo, blob, branch
        p = parts.slice(idx+2).join('/')
      } else if (parts.length >= 2) {
        p = parts.slice(2).join('/')
      }
    }
  } catch {}
  // No leading slash, collapse duplicate slashes
  p = p.replace(/^[\/]+/, '').replace(/\/+/g,'/')
  return p
}

async function getSha(owner, repo, path, token, branch){
  const cleanPath = sanitizePath(path)
  const res = await fetch(`${API}/repos/${owner}/${repo}/contents/${cleanPath.split('/').map(encodeURIComponent).join('/')}?ref=${branch}`, {
    headers: { Authorization: `token ${token}` }
  })
  if (res.status === 404) return null
  const json = await res.json()
  return json.sha
}

export async function saveJsonToGitHub(path, jsonObj) {
  const cfg = JSON.parse(localStorage.getItem('githubSync') || 'null')
  if (!cfg) return { ok:false, reason:'no-config' }
  const { owner, repo, branch='main', token, basePath='' } = cfg
  const baseClean = sanitizePath(basePath)
  const pathClean = sanitizePath(path)
  const full = baseClean ? `${baseClean}/${pathClean}` : pathClean

  const sha = await getSha(owner, repo, full, token, branch)
  const content = btoa(unescape(encodeURIComponent(JSON.stringify(jsonObj, null, 2))))
  const body = { message: `chore: autosave ${full}`, content, branch, sha: sha || undefined }

  const res = await fetch(`${API}/repos/${owner}/${repo}/contents/${full.split('/').map(encodeURIComponent).join('/')}`, {
    method: 'PUT',
    headers: {
      'Authorization': `token ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  })
  if (!res.ok) throw new Error(await res.text())
  return { ok:true }
}
