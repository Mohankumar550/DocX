// Auto-generated icon registry using Vite import.meta.glob.
// Provides maps for outlined, solid, and fontawesome social icons.

// NOTE: Uses raw SVG string imports so we can inject and control size via wrapping container.

const outlinedGlob = import.meta.glob('../../assets/icons/Outlined/*.svg', { as: 'raw', eager: true });
const solidGlob = import.meta.glob('../../assets/icons/Solid/*.svg', { as: 'raw', eager: true });
const fontAwesomeGlob = import.meta.glob('../../assets/icons/Solid/FontAwesome/*.svg', { as: 'raw', eager: true });

function normalize(map: Record<string, string>) {
  const out: Record<string, string> = {};
  for (const fullPath in map) {
    const file = fullPath.split('/').pop()!; // e.g. fi_activity.svg
    const name = file.replace(/\.svg$/,'');
    out[name] = map[fullPath];
  }
  return out;
}

export const outlinedIcons = normalize(outlinedGlob as Record<string,string>);
export const solidIcons = normalize(solidGlob as Record<string,string>);
export const fontAwesomeIcons = normalize(fontAwesomeGlob as Record<string,string>);

export type IconStyle = 'outlined' | 'solid' | 'fontawesome';

export function getIconNames(style: IconStyle): string[] {
  switch(style) {
    case 'outlined': return Object.keys(outlinedIcons).sort();
    case 'solid': return Object.keys(solidIcons).sort();
    case 'fontawesome': return Object.keys(fontAwesomeIcons).sort();
  }
}

export function getIconSvg(name: string, style: IconStyle): string | undefined {
  if (style === 'outlined') return outlinedIcons[name];
  if (style === 'solid') return solidIcons[name];
  if (style === 'fontawesome') return fontAwesomeIcons[name];
  return undefined;
}
