import { useContext } from 'react';
import { ThemeContext } from './ThemeContext';
import type { ThemeContextValue } from './ThemeContext';
import type { ThemeName } from './themeManager';

export interface UseThemeHook {
  theme: ThemeName;
  themes: ThemeName[];
  setTheme: (name: ThemeName) => void;
}

export function useTheme(): UseThemeHook {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within <ThemeProvider>');
  const { theme, themes, setThemeName } = ctx as ThemeContextValue; // explicit narrowing
  return { theme, themes, setTheme: setThemeName };
}
