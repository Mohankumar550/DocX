import React from 'react';

export type DXInputStatus = 'default' | 'success' | 'warning' | 'error';
export type DXInputSize = 'default' | 'sm';

export interface DXInputProps {
  label?: string;
  description?: string;
  required?: boolean;
  status?: DXInputStatus;
  size?: DXInputSize;
  disabled?: boolean;
  placeholder?: string;
  value?: string; // controlled
  defaultValue?: string; // uncontrolled
  onChange?: (value: string) => void;
  name?: string;
  id?: string;
  className?: string;
}

/** DXInput – accessible text input supporting status (success, warning, error), required, disabled and size variants */
export const DXInput: React.FC<DXInputProps> = ({
  label,
  description,
  required,
  status = 'default',
  size = 'default',
  disabled,
  placeholder,
  value,
  defaultValue,
  onChange,
  name,
  id,
  className
}) => {
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState<string>(defaultValue || '');
  const current = isControlled ? value! : internal;
  const inputId = id || React.useId();
  const descId = description ? inputId + '-desc' : undefined;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const next = e.target.value;
    if (!isControlled) setInternal(next);
    onChange?.(next);
  };

  const classes = [
    'dx-input',
    size === 'sm' && 'dx-input--sm',
    status !== 'default' && `dx-input--${status}`,
    disabled && 'dx-input--disabled',
    current && 'dx-input--filled',
    className
  ].filter(Boolean).join(' ');

  return (
    <div className={classes} data-status={status} data-filled={!!current}>
      {label && (
        <label htmlFor={inputId} className='dx-input__label'>
          <span>{label}</span>
          {required && <span className='dx-input__required' aria-hidden='true'>*</span>}
        </label>
      )}
      <div className='dx-input__field-wrapper'>
        <input
          id={inputId}
          name={name}
          type='text'
          className='dx-input__field'
          placeholder={placeholder}
          value={current}
          onChange={handleChange}
          required={required}
          aria-required={required || undefined}
          aria-invalid={status === 'error' ? true : undefined}
          aria-describedby={descId}
          disabled={disabled}
        />
        {/* future icon slot could be injected here */}
      </div>
      {description && (
        <div id={descId} className='dx-input__description'>
          {description}
        </div>
      )}
    </div>
  );
};

DXInput.displayName = 'DXInput';

export default DXInput;
