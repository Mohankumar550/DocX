import React from 'react';
import './Section.styles.css';

export const DXSection: React.FC<React.HTMLAttributes<HTMLElement>> = ({ className = '', ...rest }) => {
  return <section className={['layout-section', className].filter(Boolean).join(' ')} {...rest} />;
};
