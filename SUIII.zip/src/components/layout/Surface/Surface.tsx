import React from 'react';
import './Surface.styles.css';

export interface SurfaceProps extends React.HTMLAttributes<HTMLDivElement> {
  elevation?: 'sm' | 'md' | 'lg';
}

export const DXSurface: React.FC<SurfaceProps> = ({ elevation = 'sm', className = '', ...rest }) => {
  const classes = ['layout-surface', `layout-surface--${elevation}`, className].filter(Boolean).join(' ');
  return <div className={classes} {...rest} />;
};
