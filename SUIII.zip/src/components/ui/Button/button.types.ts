import React from 'react';

/** Visual style variants supported by the design system */
export type ButtonVariant = 'soft' | 'contained' | 'outlined' | 'tertiary' | 'ghost';
/** Size scale mapping to spacing & typography tokens */
export type ButtonSize = 'sm' | 'md' | 'lg';
/** Semantic tone (maps to color tokens) */
export type ButtonTone = 'default' | 'error' | 'success' | 'warning';
/** Theme namespace (maps to SCSS themes: light, dark, highcontrast) */
export type ButtonTheme = 'light' | 'dark' | 'highcontrast';

/** Internal options used solely for building class lists */
export interface InternalBuildOptions {
  variant: ButtonVariant;
  size: ButtonSize;
  tone: ButtonTone;
  theme?: ButtonTheme;
  iconLeft?: React.ReactNode;
  iconRight?: React.ReactNode;
  loading?: boolean;
  fullWidth?: boolean;
  className?: string;
  children?: React.ReactNode;
}

/**
 * Public props for the `DXButton` component.
 * Extends native button attributes and adds design-system concerns.
 */
export interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'type'> {
  /** Visual style variant */
  variant?: ButtonVariant;
  /** Size scale */
  size?: ButtonSize;
  /** Semantic tone intent */
  tone?: ButtonTone;
  /** Optional theme override (defaults to inherited) */
  theme?: ButtonTheme;
  /** Leading icon element */
  iconLeft?: React.ReactNode;
  /** Trailing icon element */
  iconRight?: React.ReactNode;
  /** Loading state (disables interaction & shows spinner) */
  loading?: boolean;
  /** Stretch to fill container width */
  fullWidth?: boolean;
  /** Polymorphic render element */
  as?: 'button' | 'a' | React.ElementType;
  /** Anchor href when rendered as <a> */
  href?: string;
  /** Button type when rendered as native button */
  type?: 'button' | 'submit' | 'reset';
  /** Accessible label when icon-only */
  'aria-label'?: string;
  /** Debug instrumentation (tree-shakable by dead code elimination) */
  debug?: boolean;
}
