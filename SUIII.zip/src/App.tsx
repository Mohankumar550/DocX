import { useState, useEffect } from 'react'
import { useTheme } from './theming/useTheme'
import { DXButton } from './components/ui/Button/Button'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import DXIcon from './components/icons/Icon';

// Styles consolidated via styles/design-system.scss imported in main.tsx

function App() {
  const [count, setCount] = useState(0)
  const { setTheme } = useTheme();
  useEffect(() => {
    // Force saasy-light theme for now (user preference)
    setTheme('saasy-light');
  }, [setTheme]);

  return (
    <>
      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Theming Demo</h1>
    {/* Theme is hard-coded to saasy-light; no switcher displayed */}
      <div className="card">
      <DXButton variant="outlined" size="md" onClick={() => setCount(c => c + 1)} iconLeft={<DXIcon name="fi_plus" style="outlined" size={16} color='var(--colors-primary-500)' />}>Count is {count}</DXButton>
        <p>
          Edit <code>src/App.tsx</code> and save to test HMR
        </p>
      </div>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </>
  )
}

export default App
