import { createHash } from 'crypto';

export function checksum(obj: unknown): string {
  const json = stableStringify(obj);
  return createHash('sha256').update(json).digest('hex').slice(0, 16);
}

export function stableStringify(value: unknown): string {
  if (Array.isArray(value)) {
    return '[' + value.map(v => stableStringify(v)).join(',') + ']';
  }
  if (value && typeof value === 'object') {
    const entries = Object.keys(value as any).sort().map(k => `${JSON.stringify(k)}:${stableStringify((value as any)[k])}`);
    return '{' + entries.join(',') + '}';
  }
  return JSON.stringify(value);
}
