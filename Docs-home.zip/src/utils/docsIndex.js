// Returns an array of nodes from root to the node with the given id
export function getPathToNode(tree, id, path = []) {
  for (const node of tree) {
    const newPath = [...path, node]
    if (node.id === id) return newPath
    if (node.children) {
      const res = getPathToNode(node.children, id, newPath)
      if (res) return res
    }
  }
  return null
}
import { markDirty } from './sync'
import staticIndex from '../data/docs/index.json'
const INDEX_KEY = 'docsIndex'

export function loadDocsIndex() {
  const local = localStorage.getItem(INDEX_KEY)
  return local ? JSON.parse(local) : staticToTree(staticIndex)
}
export function saveDocsIndex(tree) {
  localStorage.setItem(INDEX_KEY, JSON.stringify(tree))
  // notify listeners (breadcrumb, etc.)
  try { window.dispatchEvent(new CustomEvent('docs-index-updated')) } catch(e){ /* ignore in non-browser */ }
  try { markDirty() } catch(e){ /* ignore */ }
}
function staticToTree(arr) {
  return [{
    id: 'root',
    type: 'folder',
    title: 'Pages',
    children: arr.map(d => ({ id: d.id, type: 'doc', title: d.title, initial: d.initial || null }))
  }]
}
export const findNode = (tree, id) => {
  for (const node of tree) {
    if (node.id === id) return node
    if (node.children) {
      const f = findNode(node.children, id)
      if (f) return f
    }
  }
  return null
}
export function removeNode(tree, id) {
  for (let i=0;i<tree.length;i++){
    const n = tree[i]
    if (n.id === id){ tree.splice(i,1); return n }
    if (n.children){ const r = removeNode(n.children,id); if (r) return r }
  }
  return null
}
export function insertNode(tree, parentId, node, index = -1) {
  const parent = findNode(tree, parentId)
  if (!parent || parent.type !== 'folder') return false
  parent.children = parent.children || []
  if (index >= 0) parent.children.splice(index,0,node)
  else parent.children.push(node)
  return true
}

export function updateNodeTitle(tree, id, title) {
  const n = findNode(tree, id)
  if (!n) return false
  n.title = title
  return true
}
