import React, { useCallback } from 'react'
import {
  Bold, Italic, Underline, Strikethrough, List, ListOrdered,
  CheckSquare, Quote, Minus, Code, Link as LinkIcon,
  Undo2, Redo2, Image as ImageIcon, Table as TableIcon,
  Type, History as HistoryIcon, MessageSquareText, Search as SearchIcon
} from 'lucide-react'

const Btn = React.memo(function Btn({ on, active, title, children }) {
  return (
    <button title={title} onClick={on}
      className={`p-2 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828] transition ${active ? 'bg-[#EBECF0] dark:bg-[#101828]' : ''}`} type="button">
      {children}
    </button>
  )
})

export default function EditorToolbar({ editor }) {
  if (!editor) return null
  // Helper to focus then run chain builder
  const run = (chainFn) => () => { chainFn(editor.chain().focus()).run() }
  const promptLink = () => { const url = prompt('Enter URL'); if (url) editor.chain().focus().setLink({ href: url }).run() }
  const promptImage = () => { const url = prompt('Image URL or base64'); if (url) editor.chain().focus().setImage({ src: url }).run() }
  return (
    <div className="sticky top-14 z-30 bg-toolbarBg dark:bg-[#0B0F1A] border-b border-borderLight dark:border-[#1F2937] shadow-toolbar">
      <div className="max-w-5xl mx-auto flex items-center gap-1 px-3 h-11">
  <Btn title="Bold" on={run(chain=>chain.toggleBold())} active={editor.isActive('bold')}><Bold className="w-4 h-4"/></Btn>
  <Btn title="Italic" on={run(chain=>chain.toggleItalic())} active={editor.isActive('italic')}><Italic className="w-4 h-4"/></Btn>
  <Btn title="Underline" on={run(chain=>chain.toggleUnderline?.())} active={editor.isActive('underline')}><Underline className="w-4 h-4"/></Btn>
  <Btn title="Strike" on={run(chain=>chain.toggleStrike())} active={editor.isActive('strike')}><Strikethrough className="w-4 h-4"/></Btn>
        <span className="mx-2 w-px h-6 bg-borderLight dark:bg-[#1F2937]" />
  <Btn title="Heading" on={run(chain=>chain.toggleHeading({level:2}))} active={editor.isActive('heading',{level:2})}><Type className="w-4 h-4"/></Btn>
  <Btn title="Bulleted list" on={run(chain=>chain.toggleBulletList())} active={editor.isActive('bulletList')}><List className="w-4 h-4"/></Btn>
  <Btn title="Numbered list" on={run(chain=>chain.toggleOrderedList())} active={editor.isActive('orderedList')}><ListOrdered className="w-4 h-4"/></Btn>
  <Btn title="Checklist" on={run(chain=>chain.toggleTaskList())} active={editor.isActive('taskList')}><CheckSquare className="w-4 h-4"/></Btn>
  <Btn title="Quote" on={run(chain=>chain.toggleBlockquote())} active={editor.isActive('blockquote')}><Quote className="w-4 h-4"/></Btn>
  <Btn title="Rule" on={run(chain=>chain.setHorizontalRule())}><Minus className="w-4 h-4"/></Btn>
        <span className="mx-2 w-px h-6 bg-borderLight dark:bg-[#1F2937]" />
  <Btn title="Code block" on={run(chain=>chain.toggleCodeBlock())} active={editor.isActive('codeBlock')}><Code className="w-4 h-4"/></Btn>
  <Btn title="Link" on={promptLink} active={editor.isActive('link')}><LinkIcon className="w-4 h-4"/></Btn>
  <Btn title="Image" on={promptImage}><ImageIcon className="w-4 h-4"/></Btn>
  <Btn title="Insert table" on={run(chain=>chain.insertTable({rows:3,cols:4,withHeaderRow:true}))}><TableIcon className="w-4 h-4"/></Btn>
        {/* Table ops */}
  <Btn title="Add row" on={run(chain=>chain.addRowAfter())}><span className="text-xs">+Row</span></Btn>
  <Btn title="Del row" on={run(chain=>chain.deleteRow())}><span className="text-xs">-Row</span></Btn>
  <Btn title="Add col" on={run(chain=>chain.addColumnAfter())}><span className="text-xs">+Col</span></Btn>
  <Btn title="Del col" on={run(chain=>chain.deleteColumn())}><span className="text-xs">-Col</span></Btn>
  <Btn title="Del table" on={run(chain=>chain.deleteTable())}><span className="text-xs">XTbl</span></Btn>
        <span className="mx-2 w-px h-6 bg-borderLight dark:bg-[#1F2937]" />
  <Btn title="Search (Ctrl+K)" on={()=>window.dispatchEvent(new CustomEvent('open-search'))}><SearchIcon className="w-4 h-4"/></Btn>
  <Btn title="Comments" on={()=>window.dispatchEvent(new CustomEvent('open-comments'))}><MessageSquareText className="w-4 h-4"/></Btn>
  <Btn title="History" on={()=>window.dispatchEvent(new CustomEvent('open-history'))}><HistoryIcon className="w-4 h-4"/></Btn>
        <span className="mx-2 w-px h-6 bg-borderLight dark:bg-[#1F2937]" />
  <Btn title="Undo" on={run(chain=>chain.undo())}><Undo2 className="w-4 h-4"/></Btn>
  <Btn title="Redo" on={run(chain=>chain.redo())}><Redo2 className="w-4 h-4"/></Btn>
      </div>
    </div>
  )
}
