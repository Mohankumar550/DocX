import type { StorybookConfig } from '@storybook/react-vite';
// Explicit MDX indexer import not supported in current package; fallback to default docs handling.

const config: StorybookConfig = {
  stories: [
    '../src/components/**/*.stories.@(ts|tsx)'
  ],
  addons: [
    '@storybook/addon-essentials',
    '@storybook/addon-docs'
  ],
  docs: {
    autodocs: true
  },
  framework: {
    name: '@storybook/react-vite',
    options: {}
  }
};
export default config;
