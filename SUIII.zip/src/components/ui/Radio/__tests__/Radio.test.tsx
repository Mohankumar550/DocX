import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { DXRadioGroup } from '../Radio';

describe('DXRadioGroup', () => {
  it('renders options and selects default', () => {
    render(<DXRadioGroup name='t' defaultValue='b' options={[{ value: 'a', label: 'A' }, { value: 'b', label: 'B' }]} />);
    const b = screen.getByLabelText('B') as HTMLInputElement;
    expect(b.checked).toBe(true);
  });

  it('changes selection on click (uncontrolled)', () => {
    render(<DXRadioGroup name='t' defaultValue='a' options={[{ value: 'a', label: 'A' }, { value: 'b', label: 'B' }]} />);
    const b = screen.getByLabelText('B') as HTMLInputElement;
    fireEvent.click(b);
    expect(b.checked).toBe(true);
  });

  it('respects disabled option', () => {
    render(<DXRadioGroup name='t' defaultValue='a' options={[{ value: 'a', label: 'A' }, { value: 'b', label: 'B', disabled: true }]} />);
    const b = screen.getByLabelText('B') as HTMLInputElement;
    expect(b.disabled).toBe(true);
  });
});
