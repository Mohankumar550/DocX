export type PlainObject = Record<string, unknown>;

export function deepMerge<T extends PlainObject>(...sources: T[]): T {
  const result: PlainObject = {};
  for (const src of sources) {
    if (!src) continue;
    for (const key of Object.keys(src).sort()) {
      const value = src[key];
      if (value === null) {
        // explicit null removes key
        delete result[key];
        continue;
      }
      if (isPlainObject(value) && isPlainObject(result[key])) {
        result[key] = deepMerge(result[key] as PlainObject, value as PlainObject);
      } else if (isPlainObject(value)) {
        result[key] = deepMerge({}, value as PlainObject);
      } else {
        result[key] = value;
      }
    }
  }
  return result as T;
}

function isPlainObject(v: unknown): v is PlainObject {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}
