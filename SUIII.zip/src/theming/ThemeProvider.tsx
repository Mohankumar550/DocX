import React, { useEffect, useState, useCallback } from 'react';
import { loadSavedTheme, setTheme, listAvailableThemes, getCurrentTheme, type ThemeName } from './themeManager';
import { ThemeContext } from './ThemeContext';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const themes = listAvailableThemes();
  const defaultTheme: ThemeName = themes.includes('corporate-light') ? 'corporate-light' : themes[0];
  const [theme, setThemeState] = useState<ThemeName>(defaultTheme);
  const [loading, setLoading] = useState<boolean>(true);

  // Initial async load of saved or fallback theme
  useEffect(() => {
    let active = true;
    (async () => {
      const saved = await loadSavedTheme();
      if (active) setThemeState(saved);
      setLoading(false);
    })();
    return () => { active = false; };
  }, []);

  const setThemeName = useCallback(async (name: ThemeName) => {
    await setTheme(name); // ensure applyTheme completes
    const current = getCurrentTheme();
    if (current) setThemeState(current);
  }, []);

  // Keep state in sync if external code changes theme.
  useEffect(() => {
    const handler = () => {
      const current = getCurrentTheme();
      if (current && current !== theme) setThemeState(current);
    };
    window.addEventListener('theme:changed', handler);
    return () => window.removeEventListener('theme:changed', handler);
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setThemeName, themes }}>
      {loading ? null : children}
    </ThemeContext.Provider>
  );
};
