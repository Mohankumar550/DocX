import { loadDocsIndex } from './docsIndex'
import { loadUsers } from './users'

// Gather all doc contents stored individually under doc:<id>
function collectDocs(tree) {
  const docs = []
  const walk = (nodes) => {
    for (const n of nodes) {
      if (n.type === 'doc') {
        const payload = JSON.parse(localStorage.getItem(`doc:${n.id}`) || 'null')
        docs.push({ id: n.id, title: n.title, data: payload || null })
      }
      if (n.children) walk(n.children)
    }
  }
  walk(tree)
  return docs
}

export function exportData() {
  const index = loadDocsIndex()
  const users = loadUsers()
  const docs = collectDocs(index)
  return { version: 1, exportedAt: new Date().toISOString(), index, users, docs }
}

export function importData(blob) {
  if (!blob || typeof blob !== 'object') throw new Error('Invalid import payload')
  const { index, users, docs } = blob
  if (!Array.isArray(index) || !Array.isArray(users) || !Array.isArray(docs)) throw new Error('Missing sections in import payload')
  // Save index
  localStorage.setItem('docsIndex', JSON.stringify(index))
  // Save users
  localStorage.setItem('usersData', JSON.stringify(users))
  // Save docs
  for (const d of docs) {
    if (d && d.id) {
      localStorage.setItem(`doc:${d.id}`, JSON.stringify(d.data || { title: d.title || 'Untitled', content: '<p></p>' }))
    }
  }
  try { window.dispatchEvent(new CustomEvent('docs-index-updated')) } catch(e){ /* ignore */ }
  try { window.dispatchEvent(new CustomEvent('users-updated')) } catch(e){ /* ignore */ }
  return true
}
