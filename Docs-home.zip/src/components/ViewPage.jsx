import { useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { ensureDocLoaded } from '../utils/bootstrapGit.js'

export default function ViewPage() {
  const { id } = useParams()
  const [data,setData] = useState(()=> JSON.parse(localStorage.getItem(`doc:${id}`) || 'null') || { title:'Untitled', content:'<p>Loading…</p>' })

  useEffect(()=>{
    let cancelled = false
    async function load() {
      if (!localStorage.getItem(`doc:${id}`)) {
        await ensureDocLoaded(id)
      }
      const fresh = JSON.parse(localStorage.getItem(`doc:${id}`) || 'null')
      if (fresh && !cancelled) setData(fresh)
    }
    load()
    return ()=>{ cancelled = true }
  },[id])

  return (
    <div className="max-w-5xl mx-auto px-6 py-8">
      <h1 className="text-3xl font-semibold mb-6">{data.title || 'Untitled'}</h1>
      <article className="prose max-w-none bg-white dark:bg-[#0F172A] p-6 rounded border border-borderLight dark:border-[#1F2937]" dangerouslySetInnerHTML={{ __html: data.content || '<p>No content.</p>' }} />
    </div>
  )
}
