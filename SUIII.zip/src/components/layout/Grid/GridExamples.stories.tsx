import type { Meta, StoryObj } from '@storybook/react';
import { DXGrid } from './Grid';
import { DXSurface } from '../Surface/Surface';

interface Args { columns: number; gap: string; }

const meta: Meta<Args> = {
  title: 'Layout/Grid/Examples',
  args: { columns: 12, gap: 'var(--spacing-4)' },
  argTypes: {
    columns: { control: { type: 'range', min: 2, max: 16, step: 1 } },
    gap: { control: 'text' }
  },
  parameters: {
    docs: { description: { component: 'DXGrid sets CSS Grid columns via the columns prop and gap token.' } }
  }
};
export default meta;

type Story = StoryObj<Args>;

export const Responsive: Story = {
  render: (args) => (
    <DXGrid columns={args.columns} style={{ ['--layout-grid-gap' as any]: args.gap }}>
      {Array.from({ length: args.columns }).map((_, i) => (
        <DXSurface elevation="sm" key={i} style={{ gridColumn: 'span 1', textAlign: 'center', padding: 'var(--spacing-3)' }}>
          {i + 1}
        </DXSurface>
      ))}
    </DXGrid>
  )
};

export const Nesting: Story = {
  render: () => (
    <DXGrid columns={12} style={{ ['--layout-grid-gap' as any]: 'var(--spacing-5)' }}>
      <div style={{ gridColumn: 'span 8' }}>
        <DXGrid columns={4} style={{ ['--layout-grid-gap' as any]: 'var(--spacing-3)' }}>
          {Array.from({ length: 4 }).map((_, i) => (
            <DXSurface elevation="sm" key={i}>Inner {i + 1}</DXSurface>
          ))}
        </DXGrid>
      </div>
      <div style={{ gridColumn: 'span 4' }}>
        <DXSurface elevation="md">Sidebar block</DXSurface>
      </div>
    </DXGrid>
  ),
  parameters: { docs: { description: { story: 'Demonstrates nesting grids for complex layouts.' } } }
};
