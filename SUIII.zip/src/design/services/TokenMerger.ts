import { deepMerge } from '../algorithms/deepMerge';

export class TokenMerger {
  merge<T extends Record<string, any>>(...layers: T[]): T {
    return deepMerge(...layers);
  }
}
