export interface ThemeMeta {
  id: string;
  label: string;
  group: string; // corporate, minimal
  inherits?: string[];
}

export class ThemeRegistry {
  private themes: Map<string, ThemeMeta> = new Map();

  register(meta: ThemeMeta): void {
    this.themes.set(meta.id, meta);
  }

  get(id: string): ThemeMeta | undefined { return this.themes.get(id); }
  list(): ThemeMeta[] { return Array.from(this.themes.values()); }
}

export const themeRegistry = new ThemeRegistry();

// Pre-register known themes
['corporate-light','corporate-dark','saasy-light','saasy-dark'].forEach(id => {
  themeRegistry.register({ id, label: id.replace('-', ' '), group: id.split('-')[0] });
});
