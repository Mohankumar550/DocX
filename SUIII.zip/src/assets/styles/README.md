# Design System Styles

This directory centralizes all style artifacts (SCSS + JSON tokens) for the design system.

## Structure
```
assets/styles/
  design-system.scss         # Single entry point; import this once in app & Storybook
  base/
    _root.scss               # Global resets, element primitives, generic button baseline
    _app.scss                # Demo/app-only styles (logo animation, layout); removable in production
  components/
    _button.scss             # DXButton component variants, sizes, tones, loading/icon styling
  tokens/
    shared/                  # Cross-theme shared token JSON (colors, typography, spacing...)
    themes/                  # Theme-specific token JSON (corporate, saasy light/dark)
```

## Usage
Import the design system once at the application root (e.g. `main.tsx`) and in Storybook `.storybook/preview.ts`:
```ts
import './assets/styles/design-system.scss';
```
Theme tokens are loaded dynamically by `ThemeLoader` from `assets/styles/tokens/themes/<group>/<mode>.json`.
Shared tokens are statically imported by `themeManager.ts` from `assets/styles/tokens/shared/*`.

## Adding a New Theme
1. Create `assets/styles/tokens/themes/<group>/<light|dark>.json`.
2. Register the theme id (`<group>-light` / `<group>-dark`) in `ThemeRegistry.ts`.
3. Ensure inheritance (`"inherit": ["<group>-light"]`) for dark mode if sharing base tokens.

## Token Reference Syntax
Theme JSON supports referencing other token values using `{path.to.token}`. Resolution occurs in `ThemeResolver` after topological merge.

## SCSS Partial Guidelines
- `_root.scss`: No component classes; pure element-level and generic utility base.
- `_app.scss`: Only demo/ showcase rules—avoid shipping in library bundle.
- `_button.scss`: All selectors prefixed with `.dx-button` to prevent leakage.

## Future Extensions
- Add mixins for focus ring & motion transitions.
- Generate type-safe token accessors from JSON via a script.
- Provide a CSS custom property fallback layer for theming without JS.

## Conventions
- Use kebab-case for file names, snake-case for JSON keys only when necessary.
- Avoid hard-coded colors in SCSS; rely on CSS variables produced by token pipeline.

## Maintenance
After modifying token JSON, hot reload regenerates CSS variables. If variables appear stale, clear localStorage (the theme persistence key) and reload.
