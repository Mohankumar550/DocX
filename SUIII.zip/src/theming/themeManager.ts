import { generateCssVariables } from '../design/generators/generateCssVariables';
import { ThemeLoader } from '../design/services/ThemeLoader';
import { ThemeResolver } from '../design/services/ThemeResolver';
import { TokenMerger } from '../design/services/TokenMerger';
import { themeRegistry } from '../design/services/ThemeRegistry';
// Shared design tokens (moved to assets/styles/tokens/shared)
import colors from '../assets/styles/tokens/shared/colors.json';
import typography from '../assets/styles/tokens/shared/typography.json';
import spacing from '../assets/styles/tokens/shared/spacing.json';
import radius from '../assets/styles/tokens/shared/radius.json';
import shadow from '../assets/styles/tokens/shared/shadow.json';
import motion from '../assets/styles/tokens/shared/motion.json';
import layout from '../assets/styles/tokens/shared/layout.json';
import semantic from '../assets/styles/tokens/shared/semantic.json';

export type ThemeName = string; // theme IDs like 'corporate-light'

const THEME_STORAGE_KEY = 'app-theme';
const STYLE_ELEMENT_ID = 'theme-vars';

let currentTheme: ThemeName | null = null;
const loader = new ThemeLoader();
const resolver = new ThemeResolver();
const merger = new TokenMerger();
const sharedBase = merger.merge(colors as any, typography as any, spacing as any, radius as any, shadow as any, motion as any, layout as any, semantic as any);
let cachedVars: Record<string,string> | null = null;

interface ThemeNode { id: string; data: Record<string, any>; inherit: string[]; }

async function loadThemeChain(themeName: ThemeName): Promise<ThemeNode[]> {
  const visited = new Set<string>();
  const nodes: ThemeNode[] = [];
  async function dfs(id: string) {
    if (visited.has(id)) return; // prevents cycles
    visited.add(id);
    const data = await loader.load(id);
    const inherit: string[] = Array.isArray((data as any).inherit) ? (data as any).inherit : [];
    // load parents first so resolver order (after topo sort) is deterministic
    for (const parent of inherit) {
      await dfs(parent);
    }
    nodes.push({ id, data: data as any, inherit });
  }
  await dfs(themeName);
  return nodes;
}

function getStyleElement(): HTMLStyleElement {
  let el = document.getElementById(STYLE_ELEMENT_ID) as HTMLStyleElement | null;
  if (!el) {
    el = document.createElement('style');
    el.id = STYLE_ELEMENT_ID;
    document.head.appendChild(el);
  }
  return el;
}

export async function applyTheme(themeName: ThemeName): Promise<void> {
  // Load full inheritance chain (parents first) then resolve merge order by DAG
  const chain = await loadThemeChain(themeName);
  const merged = resolver.resolve(chain, sharedBase as any);
  const { map, cssText } = generateCssVariables(merged);
  const el = getStyleElement();
  el.textContent = cssText; // Replace entire block to drop removed vars
  currentTheme = themeName;
  localStorage.setItem(THEME_STORAGE_KEY, themeName);
  cachedVars = map;
}

export async function setTheme(themeName: ThemeName): Promise<ThemeName> {
  if (!listAvailableThemes().includes(themeName)) throw new Error(`Unknown theme '${themeName}'`);
  await applyTheme(themeName);
  dispatchEvent(new CustomEvent('theme:changed', { detail: { theme: themeName } }));
  return themeName;
}

export function getCurrentTheme(): ThemeName | null {
  return currentTheme;
}

export function listAvailableThemes(): ThemeName[] {
  return themeRegistry.list().map(t => t.id);
}

export async function loadSavedTheme(): Promise<ThemeName> {
  const saved = localStorage.getItem(THEME_STORAGE_KEY) as ThemeName | null;
  const available = listAvailableThemes();
  if (saved && available.includes(saved)) {
    await applyTheme(saved);
    return saved;
  }
  const prefersDark = typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches;
  const fallback: ThemeName = prefersDark
    ? (available.includes('corporate-dark') ? 'corporate-dark' : available[0])
    : (available.includes('corporate-light') ? 'corporate-light' : available[0]);
  await applyTheme(fallback);
  return fallback;
}

export function getCachedVariables(): Record<string,string> | null { return cachedVars; }
