export class TokenValidator {
  // Placeholder for real JSON Schema validation integration.
  validate(obj: unknown, context: string): void {
    if (!obj || typeof obj !== 'object') {
      throw new Error(`TokenValidator: ${context} is not an object`);
    }
  }
}
