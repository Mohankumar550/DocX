import React from 'react';

export interface DXSliderProps {
  min?: number;
  max?: number;
  step?: number;
  value?: number; // controlled
  defaultValue?: number; // uncontrolled
  disabled?: boolean;
  onChange?: (value: number) => void;
  showRangeLabels?: boolean;
  startLabel?: string;
  endLabel?: string;
  valueFormatter?: (v: number) => string;
  className?: string;
  id?: string;
  name?: string;
}

/** DXSlider – single value slider */
export const DXSlider: React.FC<DXSliderProps> = ({
  min = 0,
  max = 100,
  step = 1,
  value,
  defaultValue,
  disabled,
  onChange,
  showRangeLabels = true,
  startLabel,
  endLabel,
  valueFormatter = v => String(v),
  className,
  id,
  name
}) => {
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState<number>(defaultValue ?? min);
  const current = isControlled ? value! : internal;
  const sliderId = id || React.useId();
  const percent = ((current - min) / (max - min)) * 100;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const next = Number(e.target.value);
    if (!isControlled) setInternal(next);
    onChange?.(next);
  };

  const classes = `dx-slider${disabled ? ' dx-slider--disabled' : ''}${className ? ' ' + className : ''}`;

  return (
    <div className={classes} aria-disabled={disabled}>
      {showRangeLabels && (
        <div className='dx-slider__labels' aria-hidden='true'>
          <span>{startLabel ?? valueFormatter(min)}</span>
          <span>{endLabel ?? valueFormatter(max)}</span>
        </div>
      )}
      <div className='dx-slider__track-wrapper'>
        <div className='dx-slider__track' />
        <div className='dx-slider__range-highlight' style={{ width: percent + '%'}} />
        <div
          className='dx-slider__handle'
          style={{ left: percent + '%' }}
          tabIndex={disabled ? -1 : 0}
          role='slider'
          aria-valuemin={min}
          aria-valuemax={max}
          aria-valuenow={current}
          aria-disabled={disabled || undefined}
          aria-labelledby={sliderId + '-value'}
          onKeyDown={e => {
            if (disabled) return;
            let next = current;
            if (e.key === 'ArrowRight' || e.key === 'ArrowUp') next = Math.min(max, current + step);
            if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') next = Math.max(min, current - step);
            if (next !== current) {
              if (!isControlled) setInternal(next);
              onChange?.(next);
            }
          }}
        />
        <div id={sliderId + '-value'} className='dx-slider__value-tag' style={{ left: percent + '%' }} aria-live='off'>
          {valueFormatter(current)}
        </div>
        {/* hidden input for form compatibility */}
        <input
          type='range'
          className='dx-slider__input'
          min={min}
          max={max}
          step={step}
          value={current}
          disabled={disabled}
          onChange={handleChange}
          name={name}
          aria-hidden='true'
          tabIndex={-1}
        />
      </div>
    </div>
  );
};

DXSlider.displayName = 'DXSlider';

export interface DXRangeSliderProps {
  min?: number;
  max?: number;
  step?: number;
  values?: [number, number]; // controlled
  defaultValues?: [number, number]; // uncontrolled
  disabled?: boolean;
  onChange?: (values: [number, number]) => void;
  showRangeLabels?: boolean;
  startLabel?: string;
  endLabel?: string;
  valueFormatter?: (v: number) => string;
  className?: string;
  id?: string;
  name?: string; // base name - handles append -min/-max
}

/** DXRangeSlider – dual handle (min/max) slider */
export const DXRangeSlider: React.FC<DXRangeSliderProps> = ({
  min = 0,
  max = 10000,
  step = 100,
  values,
  defaultValues = [2000, 7500],
  disabled,
  onChange,
  showRangeLabels = true,
  startLabel,
  endLabel,
  valueFormatter = v => '$' + v.toLocaleString(),
  className,
  id,
  name
}) => {
  const isControlled = values !== undefined;
  const [internal, setInternal] = React.useState<[number, number]>(defaultValues);
  const current = isControlled ? values! : internal;
  const [minVal, maxVal] = current[0] <= current[1] ? current : [Math.min(...current), Math.max(...current)];
  const rangeId = id || React.useId();
  const leftPercent = ((minVal - min) / (max - min)) * 100;
  const rightPercent = ((maxVal - min) / (max - min)) * 100;
  const activeWidth = rightPercent - leftPercent;

  const update = (next: [number, number]) => {
    const ordered: [number, number] = next[0] <= next[1] ? next : [Math.min(...next), Math.max(...next)];
    if (!isControlled) setInternal(ordered);
    onChange?.(ordered);
  };

  const moveHandle = (index: 0 | 1, direction: 1 | -1) => {
    if (disabled) return;
    const base = index === 0 ? minVal : maxVal;
    let nextVal = base + direction * step;
    nextVal = Math.min(max, Math.max(min, nextVal));
    if (index === 0) update([nextVal, maxVal]);
    else update([minVal, nextVal]);
  };

  const classes = `dx-slider${disabled ? ' dx-slider--disabled' : ''}${className ? ' ' + className : ''}`;

  return (
    <div className={classes} aria-disabled={disabled}>
      {showRangeLabels && (
        <div className='dx-slider__labels' aria-hidden='true'>
          <span>{startLabel ?? valueFormatter(min)}</span>
          <span>{endLabel ?? valueFormatter(max)}</span>
        </div>
      )}
      <div className='dx-slider__track-wrapper'>
        <div className='dx-slider__track' />
        <div className='dx-slider__range-highlight' style={{ left: leftPercent + '%', width: activeWidth + '%' }} />
        <div
          className='dx-slider__handle'
          style={{ left: leftPercent + '%' }}
          tabIndex={disabled ? -1 : 0}
          role='slider'
          aria-valuemin={min}
          aria-valuemax={maxVal}
          aria-valuenow={minVal}
          aria-disabled={disabled || undefined}
          aria-labelledby={rangeId + '-min-tag'}
          onKeyDown={e => {
            if (e.key === 'ArrowRight' || e.key === 'ArrowUp') moveHandle(0, 1);
            if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') moveHandle(0, -1);
          }}
        />
        <div
          className='dx-slider__handle'
          style={{ left: rightPercent + '%' }}
          tabIndex={disabled ? -1 : 0}
          role='slider'
          aria-valuemin={minVal}
          aria-valuemax={max}
          aria-valuenow={maxVal}
          aria-disabled={disabled || undefined}
          aria-labelledby={rangeId + '-max-tag'}
          onKeyDown={e => {
            if (e.key === 'ArrowRight' || e.key === 'ArrowUp') moveHandle(1, 1);
            if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') moveHandle(1, -1);
          }}
        />
        <div id={rangeId + '-min-tag'} className='dx-slider__value-tag' style={{ left: leftPercent + '%' }}>{valueFormatter(minVal)}</div>
        <div id={rangeId + '-max-tag'} className='dx-slider__value-tag' style={{ left: rightPercent + '%' }}>{valueFormatter(maxVal)}</div>
        {/* Hidden input elements for form compatibility */}
        <input type='range' className='dx-slider__input' min={min} max={max} step={step} value={minVal} disabled={disabled} onChange={e => update([Number(e.target.value), maxVal])} name={name ? name + '-min' : undefined} aria-hidden='true' tabIndex={-1} />
        <input type='range' className='dx-slider__input' min={min} max={max} step={step} value={maxVal} disabled={disabled} onChange={e => update([minVal, Number(e.target.value)])} name={name ? name + '-max' : undefined} aria-hidden='true' tabIndex={-1} />
      </div>
    </div>
  );
};

DXRangeSlider.displayName = 'DXRangeSlider';

export default DXSlider;
