import React from 'react';
import './Grid.styles.css';

export interface GridProps extends React.HTMLAttributes<HTMLDivElement> {
  columns?: number;
}

export const DXGrid: React.FC<GridProps> = ({ columns = 12, className = '', style, ...rest }) => {
  const classes = ['layout-grid', className].filter(Boolean).join(' ');
  return <div className={classes} style={{ ...style, ['--layout-grid-columns' as any]: columns }} {...rest} />;
};
