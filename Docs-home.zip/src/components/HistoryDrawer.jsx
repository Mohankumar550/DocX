export default function HistoryDrawer({ open, onClose, history = [], onRestore }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 bg-black/30 z-50 flex">
      <div className="ml-auto w-[420px] h-full bg-white dark:bg-[#0B0F1A] border-l border-borderLight dark:border-[#1F2937] p-4 overflow-y-auto">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-semibold">Version history</h3>
          <button onClick={onClose} className="text-sm underline">Close</button>
        </div>
        {history.length === 0 && <div className="text-sm text-gray-500">No versions yet.</div>}
        {history.map((h, i) => (
          <div key={i} className="border border-borderLight dark:border-[#1F2937] rounded p-3 mb-3">
            <div className="text-xs text-gray-500 mb-2">
              {new Date(h.ts).toLocaleString()} • {h.user || 'Unknown'}
            </div>
            <div className="prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: h.content }} />
            <div className="mt-2">
              <button className="text-sm px-2 py-1 border rounded" onClick={()=>onRestore(h)}>Restore</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
