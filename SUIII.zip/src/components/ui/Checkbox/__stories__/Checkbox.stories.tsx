import type { Meta, StoryObj } from '@storybook/react';
import { DXCheckbox, DXCheckboxGroup } from '../Checkbox';
import type { DXCheckboxProps } from '../Checkbox';

const meta: Meta<DXCheckboxProps> = {
  title: 'Components/Checkbox',
  component: DXCheckbox,
  tags: ['autodocs'],
  args: { label: 'Accept', size: 'sm', tone: 'default' },
  parameters: {
    docs: {
      description: {
        component: 'DXCheckbox is an accessible custom checkbox supporting indeterminate and error tone. DXCheckboxGroup maps multiple options.'
      }
    }
  },
  argTypes: {
    size: { control: 'radio', options: ['sm', 'md'] },
    tone: { control: 'radio', options: ['default', 'error'] },
    disabled: { control: 'boolean' },
    label: { control: 'text' },
    description: { control: 'text' }
  }
};
export default meta;

type Story = StoryObj<DXCheckboxProps>;

export const Default: Story = { args: { label: 'Single Checkbox', defaultChecked: true } };

export const Sizes: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '1rem' }}>
      <DXCheckbox label='Small' size='sm' defaultChecked />
      <DXCheckbox label='Medium' size='md' />
    </div>
  )
};

export const ErrorTone: Story = {
  render: () => (
    <DXCheckboxGroup
      name='error-box'
      tone='error'
      defaultValues={['b']}
      label='Error Tone'
      description='When validation fails you can show error tone.'
      options={[{ value: 'a', label: 'Option A' }, { value: 'b', label: 'Option B' }, { value: 'c', label: 'Option C' }]}
    />
  )
};

export const DisabledStates: Story = {
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
      <DXCheckbox label='Checked Disabled' defaultChecked disabled />
      <DXCheckbox label='Unchecked Disabled' disabled />
    </div>
  )
};

export const Indeterminate: Story = {
  render: () => <DXCheckbox label='Partially Selected' indeterminate />
};

export const GroupExample: Story = {
  name: 'Group States (Checked / Unchecked / Disabled)',
  render: () => (
    <div style={{
      background: 'var(--surface-card,#F9FAFB)',
      padding: '1rem',
      borderRadius: 12,
      border: '1px dashed var(--colors-primary-300,#7EB0FF)',
      width: 320
    }}>
      <h4 style={{ margin: '0 0 .75rem', fontSize: '0.85rem', fontWeight: 600 }}>Checkboxes</h4>
      <DXCheckboxGroup
        name='checkbox-demo'
        defaultValues={['checked','checked-disabled']}
        options={[
          { value: 'checked', label: 'Checked' },
          { value: 'unchecked', label: 'Unchecked' },
          { value: 'unchecked-disabled', label: 'Unchecked Disabled', disabled: true },
          { value: 'checked-disabled', label: 'Unchecked Disabled', disabled: true }
        ]}
      />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Replicates screenshot states: Checked, Unchecked, Unchecked Disabled, Checked Disabled.'
      }
    }
  }
};

export const Horizontal: Story = {
  render: () => (
    <DXCheckboxGroup
      name='horizontal-box'
      orientation='horizontal'
      defaultValues={['b']}
      options={[
        { value: 'a', label: 'A' },
        { value: 'b', label: 'B' },
        { value: 'c', label: 'C', disabled: true }
      ]}
    />
  )
};
