const key = (id) => `history:${id}`
export function pushSnapshot(docId, snapshot){
  const arr = JSON.parse(localStorage.getItem(key(docId)) || '[]')
  arr.unshift({ ...snapshot, ts: Date.now() })
  localStorage.setItem(key(docId), JSON.stringify(arr.slice(0,50)))
}
export function getHistory(docId){
  return JSON.parse(localStorage.getItem(key(docId)) || '[]')
}
