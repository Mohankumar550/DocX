import type { Meta, StoryObj } from '@storybook/react';
import { getIconNames } from './autoIconsRegistry';
import DXIcon from './Icon';

const ICONS_DOC_MD = `# DX Icons

Auto-loaded SVG icons via import.meta.glob from these folders:

| Style | Path | Notes |
|-------|------|-------|
| outlined | src/assets/icons/Outlined | Stroke-based Feather-style glyphs |
| solid | src/assets/icons/Solid | Filled Hero-style glyphs |
| fontawesome | src/assets/icons/Solid/FontAwesome | Social brand icons |

## Basic Usage

\`<DXIcon name="folder" style="outlined" size={24} />\`

## Props
| Prop | Type | Default | Description |
|------|------|---------|-------------|
| name | string | (required) | File name without .svg (e.g. folder) |
| style | 'outlined' | 'outlined' | Icon style set |
| size | number | 24 | Square pixel size |
| className | string | (none) | Custom wrapper class |
| title | string | name | Accessible label; omit & wrap in aria-hidden for decorative |
| color | string | currentColor | Override stroke/fill color via wrapper |

## Examples

Inline sizing:
\`<DXIcon name="folder" size={16} /> <DXIcon name="folder" size={20} /> <DXIcon name="folder" size={32} />\`

Accent color:
\`<DXIcon name="star" style="solid" color="var(--colors-primary-500)" />\`

In a button:
\`<button class="dx-button"><span class="dx-button__icon"><DXIcon name="plus" size={16} /></span>Add Item</button>\`

Fallback (unknown name):
\`<DXIcon name="does-not-exist" />\` renders a generic square-X.

Accessibility decorative usage:
\`<span aria-hidden="true"><DXIcon name="info" /></span>\`

---
Add new icons by dropping an SVG file into a style folder. Avoid inline width/height; loader strips those attributes automatically.`;

const meta: Meta = {
  title: 'Icons/Documentation',
  parameters: {
    docs: {
      description: {
        component: ICONS_DOC_MD
      }
    }
  }
};
export default meta;

type Story = StoryObj;

function IconGrid({ style }: { style: 'outlined' | 'solid' | 'fontawesome' }) {
  const names = getIconNames(style);
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(110px,1fr))', gap: 12 }}>
      {names.map(n => (
        <div key={n} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, padding: 10, border: '1px solid var(--color-bg-emphasis,#e2e8f0)', borderRadius: 8, background: 'var(--color-bg-subtle,#f8fafc)' }}>
          <DXIcon name={n} style={style} size={32} />
          <code style={{ fontSize: 11 }}>{n}</code>
        </div>
      ))}
    </div>
  );
}

export const Overview: Story = {
  name: 'Overview',
  render: () => (
    <div style={{ padding: 24, fontFamily: 'Inter, system-ui, sans-serif' }}>
      <h2 style={{ marginTop: 0 }}>Icons – Auto Registry</h2>
      <p>The icons below are auto-imported via <code>import.meta.glob</code>. Add new SVG files into <code>src/assets/icons/Outlined</code>, <code>Solid</code>, or <code>Solid/FontAwesome</code> and they will appear automatically.</p>
      <div style={{ display:'flex', gap:'1rem', alignItems:'center', flexWrap:'wrap', marginBottom: '1.25rem' }}>
        <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
          <strong>Sizes</strong>
          <div style={{ display:'flex', gap:8, alignItems:'center' }}>
            <DXIcon name="folder" size={16} />
            <DXIcon name="folder" size={20} />
            <DXIcon name="folder" size={32} />
          </div>
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
          <strong>Color Override</strong>
          <DXIcon name="star" style="solid" size={28} color="var(--colors-primary-500)" />
        </div>
        <div style={{ display:'flex', flexDirection:'column', gap:4 }}>
          <strong>Fallback</strong>
          <DXIcon name="__missing__" size={28} />
        </div>
      </div>
      <h3>Outlined</h3>
      <IconGrid style="outlined" />
      <h3 style={{ marginTop: 32 }}>Solid</h3>
      <IconGrid style="solid" />
      <h3 style={{ marginTop: 32 }}>FontAwesome Social</h3>
      <IconGrid style="fontawesome" />
    </div>
  )
};
