import { useParams } from 'react-router-dom'
import { useEffect, useMemo, useState } from 'react'
import { EditorContent, useEditor } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Underline from '@tiptap/extension-underline'
import Link from '@tiptap/extension-link'
import Image from '@tiptap/extension-image'
import Highlight from '@tiptap/extension-highlight'
import TaskList from '@tiptap/extension-task-list'
import TaskItem from '@tiptap/extension-task-item'
import Table from '@tiptap/extension-table'
import TableRow from '@tiptap/extension-table-row'
import TableCell from '@tiptap/extension-table-cell'
import TableHeader from '@tiptap/extension-table-header'
import EditorToolbar from './EditorToolbar.jsx'
import { loadDocsIndex, getPathToNode, updateNodeTitle, saveDocsIndex } from '../utils/docsIndex'
import { BlockId } from '../extensions/BlockId'
import HistoryDrawer from './HistoryDrawer.jsx'
import CommentsSidebar from './CommentsSidebar.jsx'
import SearchModal from './SearchModal.jsx'
import UserProfilePanel from './UserProfilePanel.jsx'
import debounce from 'lodash.debounce'
import { pushSnapshot, getHistory } from '../utils/history'
import { saveJsonToGitHub } from '../utils/github'
import { ensureDocLoaded } from '../utils/bootstrapGit.js'

export default function EditorPage() {
  const { id } = useParams()
  const [title, setTitle] = useState('Page title')
  const [saving, setSaving] = useState(false)
  const [path, setPath] = useState([])
  const [showHistory, setShowHistory] = useState(false)
  const [showComments, setShowComments] = useState(false)
  const [showSearch, setShowSearch] = useState(false)
  const [showUserProfile, setShowUserProfile] = useState(false)
  const [activeBlockId, setActiveBlockId] = useState(null)
  const user = JSON.parse(localStorage.getItem('currentUser') || '{}')

  useEffect(()=>{
    const openH = ()=>setShowHistory(true)
    const openC = ()=>setShowComments(true)
    const openS = ()=>setShowSearch(true)
  const openU = ()=>setShowUserProfile(true)
    window.addEventListener('open-history', openH)
    window.addEventListener('open-comments', openC)
    window.addEventListener('open-search', openS)
  window.addEventListener('open-user-profile', openU)
    return ()=>{
      window.removeEventListener('open-history', openH)
      window.removeEventListener('open-comments', openC)
      window.removeEventListener('open-search', openS)
  window.removeEventListener('open-user-profile', openU)
    }
  },[])

  const initial = useMemo(() => {
    const local = localStorage.getItem(`doc:${id}`)
    if (local) {
      const x = JSON.parse(local)
      setTitle(x.title || 'Page title')
      return x
    }
    // If not found locally, we will attempt remote lazy load then fallback.
    const idx = loadDocsIndex()
    const doc = findDoc(idx, id)
    const init = doc?.initial || { content: '<p>Start writing…</p>' }
    setTitle(doc?.title || 'Page title')
    return init
  }, [id])

  // Lazy remote fetch if doc not in localStorage.
  useEffect(() => {
    let cancelled = false
    async function loadRemote() {
      if (localStorage.getItem(`doc:${id}`)) return
      const ok = await ensureDocLoaded(id)
      if (ok && !cancelled) {
        const data = JSON.parse(localStorage.getItem(`doc:${id}`) || 'null')
        if (data) {
          setTitle(data.title || 'Page title')
          // Replace editor content if already mounted.
          if (editor && data.content) editor.commands.setContent(data.content, false)
        }
      }
    }
    loadRemote()
    return () => { cancelled = true }
  }, [id])

  // Update breadcrumb path when id changes OR tree updates
  useEffect(() => {
    const compute = () => {
      const idx = loadDocsIndex()
      const p = getPathToNode(idx, id)
      setPath(p || [])
    }
    compute()
    window.addEventListener('docs-index-updated', compute)
    return () => window.removeEventListener('docs-index-updated', compute)
  }, [id])

  const autosyncGitHub = debounce(async (payload)=>{
    try{
      const path = `${id}.json`
      await saveJsonToGitHub(path, payload)
    }catch(e){ /* ignore */ }
  }, 1500)

  const editor = useEditor({
    extensions: [
      StarterKit.configure({ history: true }),
      Underline,
      BlockId,
      Link.configure({ openOnClick: true, autolink: true }),
      Image, Highlight, TaskList, TaskItem,
      Table.configure({ resizable: false }), TableRow, TableHeader, TableCell
    ],
    content: initial.content,
    onSelectionUpdate: ({ editor }) => {
      const dom = editor.view.domAtPos(editor.state.selection.anchor)
      const block = dom.node.closest?.('[data-block-id]')
      setActiveBlockId(block?.getAttribute?.('data-block-id') || null)
    },
    onUpdate: ({ editor }) => {
      const body = editor.getHTML()
      const payload = { title, content: body, updatedAt: new Date().toISOString(), lastEditedBy: user.name || 'Unknown' }
      setSaving(true)
      localStorage.setItem(`doc:${id}`, JSON.stringify(payload))
      debouncedSaved()
      autosyncGitHub(payload)
    }
  }, [id])

  const debouncedSaved = debounce(()=>setSaving(false), 400)

  // Sync editor title to docs index (debounced)
  useEffect(()=>{
    const sync = debounce((t)=>{
      const tree = loadDocsIndex()
      if (updateNodeTitle(tree, id, t)) saveDocsIndex(tree)
    }, 500)
    sync(title)
    return ()=>sync.cancel()
  },[title,id])

  useEffect(()=>{
    const int = setInterval(()=>{
      const data = JSON.parse(localStorage.getItem(`doc:${id}`) || 'null')
      if (data) pushSnapshot(id, { user: data.lastEditedBy, content: data.content, title: data.title })
    }, 60000)
    return ()=>clearInterval(int)
  },[id])

  const history = getHistory(id)

  const publish = () => {
    const data = JSON.parse(localStorage.getItem(`doc:${id}`))
    pushSnapshot(id, { user: user.name || 'Unknown', content: data.content, title: data.title })
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = `${data.title || 'document'}.json`; a.click()
  }

  const restore = (snap) => {
    editor?.commands.setContent(snap.content, false)
    setTitle(snap.title || title)
    setShowHistory(false)
  }

  return (
    <>
      <EditorToolbar editor={editor} />
      <div className="max-w-5xl mx-auto px-6 py-6">
        <nav className="text-sm mb-2 text-textSecondary dark:text-gray-300 flex items-center flex-wrap gap-1">
          <span className="text-atlassianBlue cursor-pointer">DocX</span>
          <span className="px-1">/</span>
          {path.length === 0 && (
            <>
              <span className="text-atlassianBlue cursor-pointer">Pages</span>
              <span className="px-1">/</span>
              <span>{title || 'Page'}</span>
            </>
          )}
          {path.filter(n=>n.id!=='root').map((node, idx, arr) => (
            <span key={node.id} className={
              idx === arr.length - 1
                ? ''
                : 'text-atlassianBlue cursor-pointer hover:underline'
            }>
              {node.title || 'Untitled'}
              {idx < arr.length - 1 && <span className="px-1">/</span>}
            </span>
          ))}
          <span className="ml-3 inline-block text-[10px] px-1.5 py-0.5 border border-borderLight rounded">DRAFT</span>
        </nav>
        <input className="w-full text-[28px] font-semibold placeholder:text-[#A5ADBA] bg-transparent outline-none mb-1 dark:text-white"
          value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Page title" />
        <div className="text-xs text-textSecondary dark:text-gray-400 mb-3">
          Last edited by {user?.name || 'Unknown'} • {saving ? 'Saving…' : 'Saved'}
        </div>
        <div className="editor-surface p-6 dark:bg-[#0F172A] dark:border-[#1F2937]">
          <EditorContent editor={editor} className="prose max-w-none dark:prose-invert" />
        </div>
      </div>
      <div className="sticky bottom-0 bg-white dark:bg-[#0B0F1A] border-t border-borderLight dark:border-[#1F2937] h-12 flex items-center">
        <div className="max-w-5xl mx-auto w-full px-6 flex items-center justify-between">
          <div className="text-xs text-textSecondary dark:text-gray-400">{saving ? 'Saving…' : 'Ready to go'}</div>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1.5 text-sm rounded border border-borderLight hover:bg-[#F4F5F7] dark:hover:bg-[#101828] transition">Close</button>
            <button onClick={publish} className="px-3 py-1.5 text-sm rounded bg-atlassianBlue text-white hover:brightness-110 transition">Publish</button>
          </div>
        </div>
      </div>
      <HistoryDrawer open={showHistory} onClose={()=>setShowHistory(false)} history={history} onRestore={restore} />
      <CommentsSidebar open={showComments} onClose={()=>setShowComments(false)} docId={id} activeBlockId={activeBlockId} user={user} />
      <SearchModal open={showSearch} onClose={()=>setShowSearch(false)} />
    </>
  )
}

function findDoc(tree, id){
  for (const n of tree){
    if (n.type==='doc' && n.id===id) return n
    if (n.children){ const f = findDoc(n.children,id); if (f) return f }
  }
  return null
}
