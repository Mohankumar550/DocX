import { useState } from 'react'
import users from './data/users.json'
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const [u, setU] = useState('')
  const [p, setP] = useState('')
  const nav = useNavigate()

  const login = () => {
    const found = users.find(x => x.username === u && x.password === p)
    if (!found) return alert('Invalid credentials')
    localStorage.setItem('currentUser', JSON.stringify(found))
    nav('/')
  }

  return (
    <div className="h-screen flex items-center justify-center bg-[#F4F5F7] dark:bg-[#0B0F1A]">
      <div className="bg-white dark:bg-[#0F172A] rounded shadow-lg p-6 w-80 border border-borderLight dark:border-[#1F2937]">
        <h2 className="text-center text-lg font-semibold mb-4">Login</h2>
        <input className="w-full border border-borderLight dark:border-[#1F2937] rounded px-3 py-2 mb-3 bg-white dark:bg-[#0B0F1A]" placeholder="username" value={u} onChange={e=>setU(e.target.value)} />
        <input className="w-full border border-borderLight dark:border-[#1F2937] rounded px-3 py-2 mb-4 bg-white dark:bg-[#0B0F1A]" placeholder="password" type="password" value={p} onChange={e=>setP(e.target.value)} />
        <button onClick={login} className="w-full bg-atlassianBlue text-white py-2 rounded hover:brightness-110">Login</button>
      </div>
    </div>
  )
}
