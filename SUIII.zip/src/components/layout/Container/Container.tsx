import React from 'react';
import './Container.styles.css';

export interface ContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  fluid?: boolean;
}

export const DXContainer: React.FC<ContainerProps> = ({ fluid = false, className = '', ...rest }) => {
  const classes = ['layout-container', fluid ? 'layout-container--fluid' : '', className].filter(Boolean).join(' ');
  return <div className={classes} {...rest} />;
};
