import React, { useEffect, useState } from 'react'
import { X, CloudUpload, RefreshCcw } from 'lucide-react'
import { performFileSync } from '../utils/sync'

function loadConfig(){
  return JSON.parse(localStorage.getItem('githubSync') || 'null') || { owner:'', repo:'', branch:'main', token:'', basePath:'' }
}

export default function GitSyncPanel({ open, onClose }) {
  const [cfg,setCfg]=useState(loadConfig())
  const [saving,setSaving]=useState(false)
  const [syncing,setSyncing]=useState(false)
  const [result,setResult]=useState(null)
  useEffect(()=>{ if(open){ setCfg(loadConfig()); setResult(null) } },[open])
  if(!open) return null
  const validate = () => {
    // Prevent full URLs in basePath
    if (/^https?:\/\//i.test(cfg.basePath.trim())) {
      return 'Base Path must be a relative folder inside the repo (not a full URL).'
    }
    return null
  }
  const save = () => {
    const err = validate()
    if (err) { alert(err); return }
    setSaving(true)
    // sanitize basePath
    const basePath = cfg.basePath.trim().replace(/^\/+/, '').replace(/\/+$/, '')
    const stored = { ...cfg, basePath }
    localStorage.setItem('githubSync', JSON.stringify(stored))
    setCfg(stored)
    setTimeout(()=>setSaving(false),300)
  }
  const fileSync = async () => {
    setSyncing(true); setResult(null)
    const out = await performFileSync()
    setResult(out)
    setSyncing(false)
  }
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-end">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-[520px] h-full bg-white dark:bg-[#0F172A] border-l border-borderLight dark:border-[#1F2937] flex flex-col">
        <div className="px-5 py-4 border-b border-borderLight dark:border-[#1F2937] flex items-center justify-between">
          <h2 className="text-lg font-semibold">GitHub Sync Configuration</h2>
          <button onClick={onClose} className="p-2 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828]"><X className="w-5 h-5"/></button>
        </div>
        <div className="px-5 py-4 flex-1 overflow-y-auto space-y-4 text-sm">
          <div className="grid grid-cols-2 gap-4">
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium">Owner</span>
              <input value={cfg.owner} onChange={e=>setCfg(c=>({...c,owner:e.target.value}))} className="bg-[#F4F5F7] dark:bg-[#101828] rounded px-2 py-1 outline-none"/>
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium">Repo</span>
              <input value={cfg.repo} onChange={e=>setCfg(c=>({...c,repo:e.target.value}))} className="bg-[#F4F5F7] dark:bg-[#101828] rounded px-2 py-1 outline-none"/>
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium">Branch</span>
              <input value={cfg.branch} onChange={e=>setCfg(c=>({...c,branch:e.target.value}))} className="bg-[#F4F5F7] dark:bg-[#101828] rounded px-2 py-1 outline-none"/>
            </label>
            <label className="flex flex-col gap-1">
              <span className="text-xs font-medium">Base Path (optional)</span>
              <input value={cfg.basePath} placeholder="e.g. data" onChange={e=>setCfg(c=>({...c,basePath:e.target.value}))} className="bg-[#F4F5F7] dark:bg-[#101828] rounded px-2 py-1 outline-none"/>
              {/^https?:\/\//i.test(cfg.basePath.trim()) && <span className="text-[10px] text-red-600">Remove protocol/host; use only relative folder name.</span>}
            </label>
            <label className="col-span-2 flex flex-col gap-1">
              <span className="text-xs font-medium">Personal Access Token</span>
              <input type="password" value={cfg.token} onChange={e=>setCfg(c=>({...c,token:e.target.value}))} className="bg-[#F4F5F7] dark:bg-[#101828] rounded px-2 py-1 outline-none"/>
              <span className="text-[10px] text-textSecondary dark:text-gray-400">Use a fine-grained token with only contents:write permission; rotate if exposed.</span>
            </label>
          </div>
          <div className="flex gap-2">
            <button onClick={save} disabled={saving} className="px-3 py-1.5 text-sm rounded border border-borderLight dark:border-[#1F2937] bg-white dark:bg-[#0F172A] hover:bg-[#EBECF0] dark:hover:bg-[#101828]">{saving?'Saving…':'Save Config'}</button>
            <button onClick={fileSync} disabled={syncing || !cfg.token || !cfg.owner || !cfg.repo} className="px-3 py-1.5 text-sm rounded bg-atlassianBlue text-white flex items-center gap-2 disabled:opacity-50"><CloudUpload className="w-4 h-4"/>{syncing?'Syncing…':'Sync Files'}</button>
            <button onClick={()=>setCfg(loadConfig())} className="px-3 py-1.5 text-sm rounded border border-borderLight dark:border-[#1F2937] flex items-center gap-1"><RefreshCcw className="w-4 h-4"/>Reload</button>
          </div>
          {result && (
            <div className="mt-3 text-xs">
              {result.ok ? (
                <div className="text-green-600">All files synced. Last sync: {new Date(result.meta.lastSync).toLocaleString()}</div>
              ) : (
                <div className="text-red-600">Partial errors ({result.errors.length}). Unsynced changes remain.</div>
              )}
              {!!result.errors?.length && (
                <ul className="mt-2 list-disc pl-5 space-y-1">
                  {result.errors.slice(0,10).map(e=> <li key={e.path}><span className="font-mono">{e.path}</span>: {e.error}</li>)}
                  {result.errors.length>10 && <li>… {result.errors.length-10} more</li>}
                </ul>
              )}
            </div>
          )}
          <div className="mt-4 text-[10px] text-textSecondary dark:text-gray-400 leading-relaxed">
            <p><strong>Note:</strong> This pushes JSON to your repository. GitHub Pages can serve them at <code>https://&lt;owner&gt;.github.io/&lt;repo&gt;/tree.json</code>. Use cache-busting query parameters if you need immediate latest content.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
