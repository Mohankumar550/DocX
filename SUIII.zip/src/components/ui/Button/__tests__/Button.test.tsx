import { describe, it, expect, vi, afterEach } from 'vitest';
import '@testing-library/jest-dom/vitest';
import { render, screen, cleanup } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { DXButton } from '../Button';

afterEach(() => cleanup());

describe('DXButton', () => {
  it('renders label content', () => {
    render(<DXButton>Click Me</DXButton>);
    expect(screen.getByText(/DX Click Me/)).toBeInTheDocument();
  });

  it('applies loading state and disables', async () => {
    const fn = vi.fn();
    render(<DXButton loading onClick={fn}>Load</DXButton>);
    const btn = screen.getByRole('button', { name: /DX Load/i });
    expect(btn).toHaveAttribute('aria-busy', 'true');
    await userEvent.click(btn);
    expect(fn).not.toHaveBeenCalled();
  });

  it('supports icon-only with aria-label', () => {
    render(<DXButton iconLeft={<span>*</span>} aria-label="Star" />);
    expect(screen.getByLabelText('Star')).toBeInTheDocument();
  });

  it('fires click when enabled', async () => {
    const fn = vi.fn();
    render(<DXButton onClick={fn}>Tap</DXButton>);
    await userEvent.click(screen.getByRole('button', { name: /DX Tap/i }));
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('keyboard activates polymorphic anchor', async () => {
    const fn = vi.fn();
    render(<DXButton as="a" href="#" onClick={fn}>Link</DXButton>);
    const anchor = screen.getByRole('link', { name: /DX Link/i });
    anchor.focus();
    await userEvent.keyboard('{Enter}');
    expect(fn).toHaveBeenCalledTimes(1);
  });
});

// Duplicate test file intentionally cleared; canonical tests live in __tests__/Button.test.tsx
export {};
