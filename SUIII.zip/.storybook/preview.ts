import type { Preview } from '@storybook/react';
import React, { useEffect, useState } from 'react';
import { setTheme, listAvailableThemes, loadSavedTheme } from '../src/theming/themeManager';
// Global & component styles (ensure design system CSS + variables are present in Storybook)
import '../src/assets/styles/main.scss';

// Available theme IDs (e.g. corporate-light, saasy-dark)
const themeIds = listAvailableThemes();
// Derive families and modes to build a dual segmented toolbar
const families = Array.from(new Set(themeIds.map(id => id.split('-')[0])));
const modes = Array.from(new Set(themeIds.map(id => id.split('-')[1])));
const defaultFamily = families[0];
const defaultMode = modes.includes('light') ? 'light' : modes[0];

export const globalTypes = {
  themeFamily: {
    name: 'Theme Family',
    description: 'Select theme family',
    defaultValue: defaultFamily,
    toolbar: {
      icon: 'sidebar',
      items: families.map(f => ({ value: f, title: f.charAt(0).toUpperCase() + f.slice(1) }))
    }
  },
  themeMode: {
    name: 'Mode',
    description: 'Select theme mode',
    defaultValue: defaultMode,
    toolbar: {
      icon: 'lightning',
      items: modes.map(m => ({ value: m, title: m.charAt(0).toUpperCase() + m.slice(1) }))
    }
  }
};

function composeTheme(family: string, mode: string): string {
  const candidate = `${family}-${mode}`;
  if (themeIds.includes(candidate)) return candidate;
  // Fallback precedence: same family any mode -> any family same mode -> first theme
  const sameFamily = themeIds.find(t => t.startsWith(family + '-'));
  if (sameFamily) return sameFamily;
  const sameMode = themeIds.find(t => t.endsWith('-' + mode));
  if (sameMode) return sameMode;
  return themeIds[0];
}

const withTheme = (Story: any, context: any) => {
  const family = context.globals.themeFamily || defaultFamily;
  const mode = context.globals.themeMode || defaultMode;
  const active = composeTheme(family, mode);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let mounted = true;
    (async () => {
      await setTheme(active);
      if (mounted) setReady(true);
    })();
    return () => { mounted = false; };
  }, [active]);
  if (!ready) return React.createElement('div', { style: { padding: '1rem', fontFamily: 'sans-serif', opacity: 0.6 } }, 'Loading theme…');
  return React.createElement(Story);
};

const preview: Preview = {
  decorators: [withTheme],
  parameters: {
    controls: { matchers: { color: /(background|color)$/i, date: /Date$/ } }
  }
};

// Pre-load saved (or fallback) theme before stories mount to reduce FOUC
(async () => { await loadSavedTheme(); })();

export default preview;
