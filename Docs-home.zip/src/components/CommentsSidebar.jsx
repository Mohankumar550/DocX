import { getComments, addComment } from '../utils/comments'
import { useEffect, useMemo, useState } from 'react'

export default function CommentsSidebar({ open, onClose, docId, activeBlockId, user }) {
  const [map, setMap] = useState({})
  const [text, setText] = useState('')
  useEffect(()=>{ setMap(getComments(docId)) },[docId, open])
  const list = useMemo(()=> (activeBlockId ? (map[activeBlockId] || []) : []), [map, activeBlockId])
  const submit = () => {
    if (!activeBlockId || !text.trim()) return
    addComment(docId, activeBlockId, { user: user?.name || 'Unknown', text })
    setMap(getComments(docId)); setText('')
  }
  if (!open) return null
  return (
    <div className="fixed right-0 top-14 bottom-0 w-[360px] bg-white dark:bg-[#0B0F1A] border-l border-borderLight dark:border-[#1F2937] z-40 p-3">
      <div className="flex items-center justify-between mb-2">
        <h3 className="font-semibold">Comments</h3>
        <button className="text-sm underline" onClick={onClose}>Close</button>
      </div>
      {!activeBlockId && <div className="text-sm text-gray-500">Place the caret in a block to comment.</div>}
      {activeBlockId && (
        <>
          <div className="text-xs text-gray-500 mb-2">Block: {activeBlockId}</div>
          <div className="space-y-3 mb-3">
            {list.map(c=>(
              <div key={c.id} className="border border-borderLight dark:border-[#1F2937] rounded p-2">
                <div className="text-xs text-gray-500">{c.user} • {new Date(c.ts).toLocaleString()}</div>
                <div className="text-sm mt-1">{c.text}</div>
              </div>
            ))}
          </div>
          <textarea className="w-full border rounded p-2 text-sm" rows="3" value={text} onChange={e=>setText(e.target.value)} placeholder="Add a comment..." />
          <div className="mt-2">
            <button onClick={submit} className="px-3 py-1.5 text-sm rounded bg-atlassianBlue text-white">Comment</button>
          </div>
        </>
      )}
    </div>
  )
}
