import { useState } from 'react'
import { NavLink } from 'react-router-dom'
import { Folder, ChevronDown, ChevronRight, FileText, Trash, Plus, Pencil } from 'lucide-react'

export default function SidebarItem({ node, depth=0, onDragStart, onDrop, onDragOver, onDelete, onCreateDoc, onCreateFolder, onRename }) {
  const [open, setOpen] = useState(true)
  const [editing, setEditing] = useState(false)
  const [tempTitle, setTempTitle] = useState(node.title)
  const pad = 8 + depth*12
  if (node.type === 'folder') {
    return (
      <div className="select-none">
        <div
          className="group flex items-center gap-2 px-3 py-2 text-sm text-textSecondary dark:text-gray-300 hover:bg-white dark:hover:bg-[#0F172A] cursor-pointer rounded"
          style={{paddingLeft: pad}}
          draggable onDragStart={(e)=>onDragStart(e,node)} onDragOver={(e)=>onDragOver(e,node)} onDrop={(e)=>onDrop(e,node)}
          onClick={()=>setOpen(o=>!o)}
        >
          {open ? <ChevronDown className="w-4 h-4"/> : <ChevronRight className="w-4 h-4"/>}
          <Folder className="w-4 h-4"/>
          {editing ? (
            <input
              autoFocus
              value={tempTitle}
              onChange={(e)=>setTempTitle(e.target.value)}
              onBlur={()=>{ setEditing(false); if(tempTitle.trim() && tempTitle!==node.title) onRename?.(node.id, tempTitle.trim()) }}
              onKeyDown={(e)=>{ if(e.key==='Enter'){ e.preventDefault(); e.currentTarget.blur() } if(e.key==='Escape'){ setEditing(false); setTempTitle(node.title) }} }
              className="flex-1 bg-transparent outline-none text-textSecondary dark:text-gray-300 text-sm"
            />
          ) : (
            <span onDoubleClick={()=>setEditing(true)} className="truncate flex-1">{node.title}</span>
          )}
          {node.id !== 'root' && (
            <button title="Delete" onClick={(e)=>{e.stopPropagation(); onDelete?.(node.id)}}
              className="opacity-0 group-hover:opacity-100 transition p-1 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828]">
              <Trash className="w-3.5 h-3.5" />
            </button>
          )}
          {/* Create buttons */}
          <div className="flex gap-1 ml-1 opacity-0 group-hover:opacity-100 transition">
            <button title="New page" onClick={(e)=>{e.stopPropagation(); onCreateDoc?.(node.id)}} className="p-1 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828]"><Plus className="w-3.5 h-3.5"/></button>
            <button title="New folder" onClick={(e)=>{e.stopPropagation(); onCreateFolder?.(node.id)}} className="p-1 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828]"><Folder className="w-3.5 h-3.5"/></button>
            <button title="Rename" onClick={(e)=>{e.stopPropagation(); setEditing(true)}} className="p-1 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828]"><Pencil className="w-3.5 h-3.5"/></button>
          </div>
        </div>
        {open && node.children?.map(child => (
          <SidebarItem key={child.id} node={child} depth={depth+1} onDragStart={onDragStart} onDragOver={onDragOver} onDrop={onDrop} onDelete={onDelete} onCreateDoc={onCreateDoc} onCreateFolder={onCreateFolder} onRename={onRename} />
        ))}
      </div>
    )
  }
  return (
    <NavLink to={`/docs/${node.id}`}
      draggable onDragStart={(e)=>onDragStart(e,node)} onDragOver={(e)=>onDragOver(e,node)} onDrop={(e)=>onDrop(e,node)}
      className={({isActive}) =>
        `group flex items-center gap-2 px-3 py-2 rounded text-sm hover:bg-white dark:hover:bg-[#0F172A] transition ${
          isActive ? 'bg-white dark:bg-[#0F172A] shadow-sm' : 'text-textSecondary dark:text-gray-300'
        }`
      } style={{paddingLeft: pad}}>
      <FileText className="w-4 h-4"/>
      {editing ? (
        <input
          autoFocus
          value={tempTitle}
          onChange={(e)=>setTempTitle(e.target.value)}
          onBlur={()=>{ setEditing(false); if(tempTitle.trim() && tempTitle!==node.title) onRename?.(node.id, tempTitle.trim()) }}
          onKeyDown={(e)=>{ if(e.key==='Enter'){ e.preventDefault(); e.currentTarget.blur() } if(e.key==='Escape'){ setEditing(false); setTempTitle(node.title) }} }
          className="flex-1 bg-transparent outline-none text-sm"
        />
      ) : (
        <span onDoubleClick={()=>setEditing(true)} className="truncate flex-1">{node.title}</span>
      )}
      <button title="Delete" onClick={(e)=>{e.preventDefault(); onDelete?.(node.id)}}
        className="opacity-0 group-hover:opacity-100 transition p-1 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828]">
        <Trash className="w-3.5 h-3.5" />
      </button>
      <div className="flex gap-1 ml-1 opacity-0 group-hover:opacity-100 transition">
        <button title="Rename" onClick={(e)=>{e.preventDefault(); setEditing(true)}} className="p-1 rounded hover:bg-[#EBECF0] dark:hover:bg-[#101828]"><Pencil className="w-3.5 h-3.5"/></button>
      </div>
    </NavLink>
  )
}
