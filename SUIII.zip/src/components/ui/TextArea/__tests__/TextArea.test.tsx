import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { DXTextArea } from '../TextArea';

describe('DXTextArea', () => {
  it('renders label and placeholder', () => {
    render(<DXTextArea label='Details' placeholder='Enter details' />);
    const area = screen.getByLabelText('Details') as HTMLTextAreaElement;
    expect(area).toBeInTheDocument();
    expect(area.placeholder).toBe('Enter details');
  });
  it('applies required attributes', () => {
    render(<DXTextArea label='Details' required />);
    const area = screen.getByLabelText('Details');
    expect(area).toHaveAttribute('required');
    expect(area).toHaveAttribute('aria-required', 'true');
  });
  it('marks error state with aria-invalid', () => {
    render(<DXTextArea label='Details' status='error' defaultValue='Bad' />);
    const area = screen.getByLabelText('Details');
    expect(area).toHaveAttribute('aria-invalid', 'true');
  });
});
