import { Plus, FolderPlus, Trash } from 'lucide-react'
import { loadDocsIndex, saveDocsIndex, insertNode, removeNode, findNode, updateNodeTitle } from '../utils/docsIndex'
import SidebarItem from './SidebarItem'
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import DeleteConfirmModal from './DeleteConfirmModal'

export default function Sidebar() {
  const [tree, setTree] = useState(loadDocsIndex())
  // listen for external index updates (e.g., title changes from editor)
  useEffect(()=>{
    const refresh = ()=> setTree([...loadDocsIndex()])
    window.addEventListener('docs-index-updated', refresh)
    return ()=> window.removeEventListener('docs-index-updated', refresh)
  },[])
  const nav = useNavigate()
  const rootId = tree[0].id
  const persist = (next) => { setTree([...next]); saveDocsIndex(next) }
  const [deleteTarget, setDeleteTarget] = useState(null)
  const [deleteOpen, setDeleteOpen] = useState(false)

  // Refresh tree when external updates occur (e.g., editor title rename)
  useEffect(()=>{
    const refresh = () => setTree(loadDocsIndex())
    window.addEventListener('docs-index-updated', refresh)
    return ()=>window.removeEventListener('docs-index-updated', refresh)
  },[])

  const createDoc = (parentId = rootId) => {
    const id = 'doc-' + Date.now()
    const node = { id, type: 'doc', title: 'Untitled Page', initial: { content: '<p>Start writing…</p>' } }
    const next = structuredClone(tree)
    insertNode(next, parentId, node)
    persist(next)
    localStorage.setItem(`doc:${id}`, JSON.stringify({ title: node.title, content: node.initial.content }))
    nav(`/docs/${id}`)
  }
  const createFolder = (parentId = rootId) => {
    const id = 'folder-' + Date.now()
    const node = { id, type: 'folder', title: 'New Folder', children: [] }
    const next = structuredClone(tree)
    insertNode(next, parentId, node)
    persist(next)
  }
  const renameNode = (id, title) => {
    const next = structuredClone(tree)
    const clean = title.trim() || (findNode(next,id)?.type === 'folder' ? 'New Folder' : 'Untitled Page')
    if (updateNodeTitle(next, id, clean)) {
      persist(next)
      const node = findNode(next, id)
      if (node?.type === 'doc') {
        const data = JSON.parse(localStorage.getItem(`doc:${id}`) || '{}')
        localStorage.setItem(`doc:${id}`, JSON.stringify({ ...data, title: clean }))
      }
    }
  }

  const collectDocs = (node) => {
    const list = []
    const walk = (n) => {
      if (n.type === 'doc') list.push(n)
      if (n.children) n.children.forEach(walk)
    }
    walk(node)
    return list
  }
  const openDelete = (nodeId) => {
    const node = findNode(tree, nodeId)
    if (!node || node.id === rootId) return
    setDeleteTarget(node)
    setDeleteOpen(true)
  }
  const confirmDelete = () => {
    if (!deleteTarget) return
    const next = structuredClone(tree)
    const removed = removeNode(next, deleteTarget.id)
    if (removed){
      // remove localStorage entries
      collectDocs(removed).forEach(d => localStorage.removeItem(`doc:${d.id}`))
      persist(next)
    }
    setDeleteOpen(false)
    setDeleteTarget(null)
  }

  let dragNode = null
  const onDragStart = (e, node) => { dragNode = node; e.dataTransfer.effectAllowed='move' }
  const onDragOver = (e) => { e.preventDefault(); e.dataTransfer.dropEffect='move' }
  const onDrop = (e, target) => {
    e.preventDefault()
    if (!dragNode || dragNode.id === target.id) return
    const next = structuredClone(tree)
    const moved = removeNode(next, dragNode.id)
    if (!moved) return
    if (target.type === 'folder') {
      // move into folder
      insertNode(next, target.id, moved)
    } else {
      // place after target within its parent
      const stack=[{parent:null,list:next}]
      while(stack.length){
        const {parent,list}=stack.pop()
        for(let i=0;i<list.length;i++){
          const n=list[i]
          if(n.id===target.id){
            if(parent){
              const idx = parent.children.findIndex(c=>c.id===target.id)
              parent.children.splice(idx+1,0,moved)
            } else {
              list.splice(i+1,0,moved)
            }
            persist(next); return
          }
          if(n.children) stack.push({parent:n,list:n.children})
        }
      }
    }
    persist(next)
  }

  return (
    <aside className="w-64 bg-sidebarBg dark:bg-[#0B1220] border-r border-borderLight dark:border-[#1F2937] min-h-[calc(100vh-56px)]">
      <div className="px-3 py-2 text-xs font-semibold text-textSecondary dark:text-gray-400 uppercase tracking-wide">Pages</div>
      <div className="px-3 pb-2 flex gap-2">
        <button onClick={createDoc} className="flex-1 flex items-center gap-2 bg-white dark:bg-[#0F172A] border border-borderLight dark:border-[#1F2937] rounded px-3 py-2 text-sm hover:shadow transition">
          <Plus className="w-4 h-4"/> New page
        </button>
        <button onClick={createFolder} className="px-3 py-2 bg-white dark:bg-[#0F172A] border border-borderLight dark:border-[#1F2937] rounded text-sm hover:shadow transition" title="New folder">
          <FolderPlus className="w-4 h-4"/>
        </button>
      </div>
      <div className="px-3 py-2 text-xs font-semibold text-textSecondary dark:text-gray-400 uppercase tracking-wide">Page tree</div>
      <nav className="px-1 overflow-y-auto max-h-[calc(100vh-56px-110px)] pb-4">
        {tree.map(node => (
          <SidebarItem
            key={node.id}
            node={node}
            onDragStart={onDragStart}
            onDragOver={onDragOver}
            onDrop={onDrop}
            onDelete={openDelete}
            onCreateDoc={createDoc}
            onCreateFolder={createFolder}
            onRename={renameNode}
          />
        ))}
      </nav>
      <DeleteConfirmModal
        open={deleteOpen}
        onClose={()=>{setDeleteOpen(false); setDeleteTarget(null)}}
        target={deleteTarget}
        docs={deleteTarget ? collectDocs(deleteTarget) : []}
        onConfirm={confirmDelete}
      />
    </aside>
  )
}
