import React from 'react';

export type DXTextAreaStatus = 'default' | 'success' | 'warning' | 'error';
export type DXTextAreaSize = 'default' | 'sm';

export interface DXTextAreaProps {
  label?: string;
  description?: string;
  required?: boolean;
  status?: DXTextAreaStatus;
  size?: DXTextAreaSize;
  disabled?: boolean;
  placeholder?: string;
  value?: string; // controlled
  defaultValue?: string; // uncontrolled
  onChange?: (value: string) => void;
  name?: string;
  id?: string;
  rows?: number;
  maxLength?: number;
  showCount?: boolean;
  className?: string;
}

/** DXTextArea – multiline input with status states, character count and accessibility */
export const DXTextArea: React.FC<DXTextAreaProps> = ({
  label,
  description,
  required,
  status = 'default',
  size = 'default',
  disabled,
  placeholder,
  value,
  defaultValue,
  onChange,
  name,
  id,
  rows = 5,
  maxLength,
  showCount = false,
  className
}) => {
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState<string>(defaultValue || '');
  const current = isControlled ? value! : internal;
  const areaId = id || React.useId();
  const descId = description ? areaId + '-desc' : undefined;
  const countId = showCount ? areaId + '-count' : undefined;

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    let next = e.target.value;
    if (maxLength !== undefined) next = next.slice(0, maxLength);
    if (!isControlled) setInternal(next);
    onChange?.(next);
  };

  const classes = [
    'dx-textarea',
    size === 'sm' && 'dx-textarea--sm',
    status !== 'default' && `dx-textarea--${status}`,
    disabled && 'dx-textarea--disabled',
    current && 'dx-textarea--filled',
    className
  ].filter(Boolean).join(' ');

  const countText = showCount && maxLength ? `${current.length}/${maxLength}` : showCount ? `${current.length}` : undefined;

  return (
    <div className={classes} data-status={status} data-filled={!!current}>
      {label && (
        <label htmlFor={areaId} className='dx-textarea__label'>
          <span>{label}</span>
          {required && <span className='dx-textarea__required' aria-hidden='true'>*</span>}
        </label>
      )}
      <div className='dx-textarea__field-wrapper'>
        <textarea
          id={areaId}
          name={name}
          className='dx-textarea__field'
          placeholder={placeholder}
          value={current}
          onChange={handleChange}
          required={required}
          aria-required={required || undefined}
          aria-invalid={status === 'error' ? true : undefined}
          aria-describedby={[descId, countId].filter(Boolean).join(' ') || undefined}
          disabled={disabled}
          rows={rows}
          maxLength={maxLength}
        />
      </div>
      {description && (
        <div id={descId} className='dx-textarea__description'>
          {description}
        </div>
      )}
      {countText && (
        <div id={countId} className='dx-textarea__count' aria-live='polite'>
          {countText}
        </div>
      )}
    </div>
  );
};

DXTextArea.displayName = 'DXTextArea';

export default DXTextArea;
