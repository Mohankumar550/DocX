import { Routes, Route, Navigate } from 'react-router-dom'
import TopNav from './components/TopNav.jsx'
import Sidebar from './components/Sidebar.jsx'
import EditorPage from './components/EditorPage.jsx'
import ViewPage from './components/ViewPage.jsx'
import UsersPanel from './components/UsersPanel.jsx'
import BackupPanel from './components/BackupPanel.jsx'
import { useEffect, useState } from 'react'
import GitSyncPanel from './components/GitSyncPanel.jsx'

function isLoggedIn(){ return !!localStorage.getItem('currentUser') }

export default function App() {
  const [showUsers, setShowUsers] = useState(false)
  const [showBackup, setShowBackup] = useState(false)
  const [showGitSync, setShowGitSync] = useState(false)
  useEffect(()=>{
    const openUsers = ()=>setShowUsers(true)
    const openBackup = ()=>setShowBackup(true)
    const openGit = ()=>setShowGitSync(true)
    window.addEventListener('open-users', openUsers)
    window.addEventListener('open-backup', openBackup)
    window.addEventListener('open-git-sync', openGit)
    return ()=>{
      window.removeEventListener('open-users', openUsers)
      window.removeEventListener('open-backup', openBackup)
      window.removeEventListener('open-git-sync', openGit)
    }
  },[])
  return (
    <div className="min-h-screen text-textPrimary dark:text-white">
      <TopNav />
      <div className="flex">
        <Sidebar />
        <div className="flex-1 min-h-[calc(100vh-56px)] bg-[#FAFBFC] dark:bg-[#0B0F1A]">
          <Routes>
            <Route path="/" element={<Navigate to="/docs/demo" replace />} />
            <Route path="/docs/:id" element={isLoggedIn() ? <EditorPage /> : <Navigate to="/login" />} />
            <Route path="/view/:id" element={isLoggedIn() ? <ViewPage /> : <Navigate to="/login" />} />
          </Routes>
        </div>
      </div>
  <UsersPanel open={showUsers} onClose={()=>setShowUsers(false)} />
  <BackupPanel open={showBackup} onClose={()=>setShowBackup(false)} />
  <GitSyncPanel open={showGitSync} onClose={()=>setShowGitSync(false)} />
    </div>
  )
}
