import { Search, HelpCircle, UserRound, Users, Database, CloudCog } from 'lucide-react'
import ThemeToggle from './ThemeToggle'
import { performSync, getSyncMeta } from '../utils/sync'
import { useEffect, useState } from 'react'

export default function TopNav() {
  const [status,setStatus]=useState('idle')
  const [meta,setMeta]=useState(getSyncMeta())
  useEffect(()=>{
    const refresh=()=>setMeta(getSyncMeta())
    window.addEventListener('docs-index-updated',refresh)
    window.addEventListener('users-updated',refresh)
    window.addEventListener('open-comments',refresh)
    return ()=>{
      window.removeEventListener('docs-index-updated',refresh)
      window.removeEventListener('users-updated',refresh)
      window.removeEventListener('open-comments',refresh)
    }
  },[])
  const syncNow = async () => {
    setStatus('syncing')
    const res = await performSync()
    if(res.ok){ setStatus('ok'); setMeta(res.meta); setTimeout(()=>setStatus('idle'),2000) }
    else { setStatus('error'); setTimeout(()=>setStatus('idle'),4000) }
  }
  return (
    <header className="h-14 bg-white dark:bg-[#0B0F1A] border-b border-borderLight dark:border-[#1F2937] flex items-center justify-between px-4">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded bg-atlassianBlue"></div>
        <div className="text-sm font-semibold">DocX</div>
      </div>
      <div className="flex items-center gap-3">
        <ThemeToggle />
  <Search className="w-5 h-5 cursor-pointer text-textSecondary dark:text-gray-300" onClick={()=>window.dispatchEvent(new CustomEvent('open-search'))} />
  <Users className="w-5 h-5 cursor-pointer text-textSecondary dark:text-gray-300" onClick={()=>window.dispatchEvent(new CustomEvent('open-users'))} />
  <Database className="w-5 h-5 cursor-pointer text-textSecondary dark:text-gray-300" onClick={()=>window.dispatchEvent(new CustomEvent('open-backup'))} />
  <CloudCog className="w-5 h-5 cursor-pointer text-textSecondary dark:text-gray-300" onClick={()=>window.dispatchEvent(new CustomEvent('open-git-sync'))} />
        <button onClick={syncNow}
          className="text-xs px-2 py-1 rounded border border-borderLight dark:border-[#1F2937] hover:bg-[#F4F5F7] dark:hover:bg-[#101828]">
          {status==='syncing' ? 'Syncing…' : status==='error' ? 'Sync Error' : 'Sync'}
        </button>
        <span className="text-[10px] text-textSecondary dark:text-gray-400">
          {meta.lastSync ? 'Last: '+new Date(meta.lastSync).toLocaleTimeString()+(meta.dirty?' • Unsynced changes':'') : 'Never synced'}
        </span>
        <HelpCircle className="w-5 h-5 cursor-pointer text-textSecondary dark:text-gray-300" />
        <div className="w-8 h-8 rounded-full bg-[#DFE1E6] dark:bg-[#1F2937] flex items-center justify-center cursor-pointer" onClick={()=>window.dispatchEvent(new CustomEvent('open-user-profile'))}>
          <UserRound className="w-5 h-5 text-textSecondary dark:text-gray-300" />
        </div>
      </div>
    </header>
  )
}
