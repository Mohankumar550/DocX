import type { Meta, StoryObj } from '@storybook/react';
import DXIcon from './Icon';

const COLOR_TOKENS = [
  'var(--colors-primary-500)',
  'var(--colors-primary-600)',
  'var(--colors-alert-danger-500)',
  'var(--colors-alert-success-500)',
  'var(--colors-alert-warning-500)'
];

interface Args {
  name: string;
  style: 'outlined' | 'solid' | 'fontawesome';
  size: number;
  color: string;
}

const meta: Meta<Args> = {
  title: 'Icons/Colors',
  args: {
    name: 'fi_star',
    style: 'outlined',
    size: 48,
    color: 'var(--colors-primary-500)'
  },
  argTypes: {
    name: { control: 'text', description: 'Icon file name (without .svg)' },
    style: { control: 'radio', options: ['outlined', 'solid', 'fontawesome'], description: 'Icon style set' },
    size: { control: { type: 'range', min: 12, max: 128, step: 4 }, description: 'Pixel size (square)' },
    color: { control: 'select', options: COLOR_TOKENS.concat(['currentColor']), description: 'Stroke/Fill color (applies via wrapper span color)' }
  },
  parameters: {
    docs: {
      description: {
        component: `# Icon Colors\n\nDemonstrates applying design tokens to icon stroke/fill via the \`color\` prop. Solid + fontawesome styles auto-add \`fill=currentColor\` when missing. \n\nSelect a predefined token or use \`currentColor\` to inherit from surrounding text.`
      }
    }
  }
};
export default meta;

type Story = StoryObj<Args>;

export const Playground: Story = {
  render: (args) => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display:'flex', alignItems:'center', gap:'1rem' }}>
        <DXIcon name={args.name} style={args.style} size={args.size} color={args.color} />
        <code style={{ fontSize:12 }}>{args.color}</code>
      </div>
      <hr />
      <div>
        <strong>Token Swatches</strong>
        <div style={{ display:'flex', flexWrap:'wrap', gap:'0.75rem', marginTop:'0.75rem' }}>
          {COLOR_TOKENS.map(token => (
            <div key={token} style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4, width:90 }}>
              <DXIcon name={args.name} style={args.style} size={32} color={token} />
              <code style={{ fontSize:10 }}>{token.replace('var(--','').replace(')','')}</code>
            </div>
          ))}
        </div>
      </div>
      <div>
        <strong>Inherit currentColor</strong>
        <p style={{ color:'var(--colors-alert-success-500)', display:'flex', alignItems:'center', gap:8 }}>
          <DXIcon name={args.name} style={args.style} size={24} />
          Icon inherits parent text color.
        </p>
      </div>
      <div>
        <strong>Button Icon Colors</strong>
        <p style={{ fontSize:12 }}>Use icon color to match button tone or rely on inheritance (outlined/tertiary buttons set text color which icons follow).</p>
        <div style={{ display:'flex', gap:'1rem', flexWrap:'wrap' }}>
          {['contained','outlined','soft','tertiary'].map(variant => (
            <button key={variant} className={`dx-button dx-button--${variant}`} style={{ padding:'0.5rem 0.9rem' }}>
              <span className="dx-button__icon dx-button__icon--left" aria-hidden>
                <DXIcon name="fi_folder" style="outlined" size={16} />
              </span>
              {variant}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
};

export const SemanticExamples: Story = {
  name: 'Semantic Tokens',
  render: () => (
    <div style={{ display:'flex', gap:'1.25rem', flexWrap:'wrap' }}>
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
        <DXIcon name="fi_check-circle" style="outlined" size={36} color="var(--colors-alert-success-500)" />
        <code style={{ fontSize:10 }}>success-500</code>
      </div>
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
        <DXIcon name="fi_alert-triangle" style="outlined" size={36} color="var(--colors-alert-warning-500)" />
        <code style={{ fontSize:10 }}>warning-500</code>
      </div>
      <div style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:4 }}>
        <DXIcon name="fi_x-octagon" style="outlined" size={36} color="var(--colors-alert-danger-500)" />
        <code style={{ fontSize:10 }}>danger-500</code>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Mapping icons to semantic alert token colors for status indications.'
      }
    }
  }
};
