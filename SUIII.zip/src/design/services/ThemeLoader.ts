import type { PlainObject } from '../algorithms/deepMerge';
import { TokenValidator } from './TokenValidator';

const validator = new TokenValidator();

export class ThemeLoader {
  private cache = new Map<string, PlainObject>();

  async load(themeId: string): Promise<PlainObject> {
    if (this.cache.has(themeId)) return this.cache.get(themeId)!;
    const [group, modeMaybe] = themeId.split('-');
    const mode = modeMaybe === 'dark' ? 'dark' : 'light';
    // Only allow configured groups
    if (!['corporate','saasy'].includes(group)) {
      throw new Error(`Unknown theme group '${group}' (only corporate, saasy retained)`);
    }
  // Dynamic theme token import from assets/styles (centralized token location)
  // NOTE: Path is relative to this service file. Adjust if directory structure changes.
  const data = await import(`../../assets/styles/tokens/themes/${group}/${mode}.json`);
    validator.validate(data, themeId);
    this.cache.set(themeId, data.default as PlainObject);
    return data.default as PlainObject;
  }
}
