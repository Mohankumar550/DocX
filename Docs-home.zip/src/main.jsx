import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import './index.css'
import App from './App.jsx'
import Login from './Login.jsx'
import { bootstrapRemoteContent } from './utils/bootstrapGit.js'

// Global Ctrl/Cmd+K opens search
window.addEventListener('keydown', (e)=>{
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase()==='k') {
    e.preventDefault()
    window.dispatchEvent(new CustomEvent('open-search'))
  }
})

// Attempt remote bootstrap (GitHub Pages or raw) before mounting the app.
// This lets a fresh browser (or incognito) hydrate from the repo if localStorage is empty.
// NOTE: Token is NEVER embedded here; writes still require user configuring it (panel or env var).
async function mount() {
  try {
    await bootstrapRemoteContent({ force: false })
  } catch (e) {
    console.warn('Remote bootstrap skipped:', e)
  }
  const Root = () => (
    <BrowserRouter basename={import.meta.env.BASE_URL || '/'}>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/*" element={<App />} />
      </Routes>
    </BrowserRouter>
  )
  ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode><Root /></React.StrictMode>
  )
}

// Top-level await supported in Vite; just call.
mount()
