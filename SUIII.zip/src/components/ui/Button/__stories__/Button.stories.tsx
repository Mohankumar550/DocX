import type { Meta, StoryObj } from '@storybook/react';
import { DXButton } from '../Button';
import type { ButtonProps } from '../button.types';
import DXAutoIcon from '../../../icons/Icon';

const meta: Meta<ButtonProps> = {
  title: 'Components/Button',
  component: DXButton,
  tags: ['autodocs'],
  args: {
    children: 'Button',
    variant: 'contained',
    size: 'md',
    tone: 'default',
    loading: false,
    fullWidth: false
  },
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'DXButton is a polymorphic, accessible, theme-aware design system component. Use variant, tone, size and theme props to adapt appearance. Icon-only buttons require an aria-label.'
      }
    }
  },
  argTypes: {
    children: { control: 'text', description: 'Button label content' },
    variant: {
      control: 'select',
      options: ['contained', 'outlined', 'soft', 'tertiary'],
      description: 'Visual style variant'
    },
    size: {
      control: 'radio',
      options: ['sm', 'md', 'lg'],
      description: 'Size scale'
    },
    tone: {
      control: 'select',
      options: ['default', 'error'],
      description: 'Semantic tone mapping to color tokens'
    },
    theme: {
      control: 'select',
      options: ['light', 'dark', 'highcontrast'],
      description: 'Optional theme override'
    },
    loading: { control: 'boolean', description: 'Loading state disables interaction' },
    fullWidth: { control: 'boolean', description: 'Stretch to container width' },
    iconLeft: { control: false, description: 'Leading icon element' },
    iconRight: { control: false, description: 'Trailing icon element' },
    as: { control: 'text', description: 'Polymorphic element type' },
    href: { control: 'text', description: 'Href when rendered as anchor' },
    debug: { control: 'boolean', description: 'Enable development diagnostics' },
    'aria-label': { control: 'text', description: 'Accessible label for icon-only usage' }
  }
};
export default meta;

type Story = StoryObj<ButtonProps>;

export const Default: Story = {};
export const Contained: Story = { args: { variant: 'contained' } };
export const Outlined: Story = { args: { variant: 'outlined' } };
export const Soft: Story = { args: { variant: 'soft' } };
export const Tertiary: Story = { args: { variant: 'tertiary' } };

export const Sizes: Story = {
  render: (args: ButtonProps) => (
    <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
      <DXButton {...args} size="sm">Small</DXButton>
      <DXButton {...args}>Medium</DXButton>
      <DXButton {...args} size="lg">Large</DXButton>
    </div>
  )
};

export const ErrorTone: Story = { args: { tone: 'error', children: 'Delete' } };
export const Loading: Story = { args: { loading: true, children: 'Processing' } };
export const Disabled: Story = { args: { disabled: true, children: 'Disabled' } };

export const WithIcons: Story = {
  name: 'With DXAutoIcon (Left & Right)',
  args: {
    children: 'Hot Action',
    // Provide icon elements directly using DXAutoIcon – outlined feather variants
    iconLeft: <DXAutoIcon name="fi_fire" style="outlined" size={16} aria-hidden />,
    iconRight: <DXAutoIcon name="fi_arrow-right" style="outlined" size={16} aria-hidden />
  },
  parameters: {
    docs: {
      description: {
        story: 'Uses the DXAutoIcon component for left and right icons. Icons are passed as React elements to iconLeft/iconRight.'
      }
    }
  }
};

export const IconOnly: Story = {
  name: 'Icon Only (DXAutoIcon)',
  args: {
    iconLeft: <DXAutoIcon name="star" style="solid" size={18} aria-hidden />,
    'aria-label': 'Favourite'
  },
  parameters: {
    docs: {
      description: {
        story: 'Icon-only button using DXAutoIcon (solid style). Must provide aria-label for accessibility.'
      }
    }
  }
};

export const WithSingleLeftIcon: Story = {
  name: 'Left Icon + Label',
  args: {
    iconLeft: <DXAutoIcon name="fi_folder" style="outlined" size={16} aria-hidden />,
    children: 'Open Folder'
  },
  parameters: {
    docs: {
      description: {
        story: 'Common pattern: a leading folder icon before descriptive label.'
      }
    }
  }
};

export const WithSingleRightIcon: Story = {
  name: 'Label + Right Icon',
  args: {
    iconRight: <DXAutoIcon name="fi_arrow-right" style="outlined" size={16} aria-hidden />,
    children: 'Continue'
  },
  parameters: {
    docs: {
      description: {
        story: 'Trailing icon indicating forward navigation/action.'
      }
    }
  }
};

export const Themes: Story = {
  render: (args: ButtonProps) => (
    <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
      <DXButton {...args} theme="light">Light theme</DXButton>
      <DXButton {...args} theme="dark">Dark theme</DXButton>
      <DXButton {...args} theme="highcontrast">High Contrast</DXButton>
    </div>
  )
};

export const PrimarySecondary: Story = {
  render: (args: ButtonProps) => (
    <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
      <DXButton {...args} variant="contained">Primary Action</DXButton>
      <DXButton {...args} variant="outlined">Secondary Action</DXButton>
    </div>
  )
};

export const CustomClassName: Story = {
  args: {
    className: 'u-accent-border',
    children: 'Custom Styled'
  },
  parameters: {
    docs: {
      description: {
        story: 'Example demonstrating consumer styling via className. Define .u-accent-border in your global or module CSS to customize border/color.'
      }
    }
  }
};

export const AsLink: Story = {
  args: {
    as: 'a',
    href: '#docs',
    children: 'Anchor Link'
  }
};
